#!/usr/bin/env python3
"""
centralizer_fq_exact.py — Centralizer dimension for diagonal A_k over F_q.
Computes the centralizer of B_i = H_0^{-1} H_i using exact Gaussian
elimination over F_p and column-major vectorization.

Usage:
    python3 centralizer_fq_exact.py

Requirements: numpy, galois (>=0.4.11)
"""
import numpy as np
import galois
import time

# ============================================================
# Parameters
# ============================================================
p = 31
e = 5
n = 4 * e          # 20
schedule = [(0,1), (1,2), (2,3), (3,4), (0,4)]

# ============================================================
# Field setup
# ============================================================
GFp = galois.GF(p)
GF = galois.GF(p**e)
alpha = GF.primitive_element

# Frobenius matrices: F_a[i,j] = (alpha^{p^a})^j component i
frob_mats = []
for a in range(e):
    F = np.zeros((e, e), dtype=int)
    fa = alpha ** (p**a)
    for i in range(e):
        F[:, i] = np.array((fa ** i).vector(), dtype=int) % p
    frob_mats.append(F % p)

# Multiplication tensor: mult[i,m,n] = (alpha^m * alpha^n) component i
mult = np.zeros((e, e, e), dtype=int)
for m in range(e):
    for n2 in range(e):
        mult[:, m, n2] = np.array(((alpha**m) * (alpha**n2)).vector(), dtype=int) % p

# Regular representation: reg[:,:,k] = matrix for multiplication by alpha^k
reg = np.zeros((e, e, e), dtype=int)
for k in range(e):
    ak = alpha ** k
    for j in range(e):
        reg[:, j, k] = np.array((ak * (alpha ** j)).vector(), dtype=int) % p


# ============================================================
# Utility functions
# ============================================================
def fq_to_matrix(fq_el, reg, e, p):
    """Convert F_q element to e x e matrix over F_p (regular rep)."""
    vec = np.array(fq_el.vector(), dtype=int) % p
    M = np.zeros((e, e), dtype=np.int64)
    for k in range(e):
        if vec[k] != 0:
            M = (M + int(vec[k]) * reg[:, :, k]) % p
    return M


def mod_inv_mat(M, p):
    """Matrix inverse mod p via Gaussian elimination."""
    n = M.shape[0]
    aug = np.hstack([np.array(M, dtype=np.int64) % p,
                     np.eye(n, dtype=np.int64)]) % p
    for col in range(n):
        pivot = -1
        for row in range(col, n):
            if aug[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            raise ValueError("Not invertible")
        if pivot != col:
            aug[[col, pivot]] = aug[[pivot, col]]
        inv_val = pow(int(aug[col, col]), -1, p)
        aug[col] = (aug[col] * inv_val) % p
        for row in range(n):
            if row != col and aug[row, col] % p != 0:
                aug[row] = (aug[row] - aug[row, col] * aug[col]) % p
    return aug[:, n:] % p


def mat_rank_exact(M, p):
    """Exact rank over F_p via Gaussian elimination."""
    M = np.array(M, dtype=np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        if pivot != rank:
            M[[rank, pivot]] = M[[pivot, rank]]
        inv_val = pow(int(M[rank, col]), -1, p)
        M[rank] = (M[rank] * inv_val) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
    return rank


def build_hessians(p, e, schedule, A_k_list, frob_mats, mult, reg, GF, max_j=1):
    """Build 4e x 4e Hessian matrices with A_k entries over F_q."""
    n_vars = 4 * e
    hessians = []
    for k in range(5):
        a_k, b_k = schedule[k]
        F_a = frob_mats[a_k % e]
        F_b = frob_mats[b_k % e]
        for j in range(max_j):
            B = (F_a.T @ mult[j] @ F_b) % p
            H = np.zeros((n_vars, n_vars), dtype=int)
            for i in range(1, 5):
                for l in range(1, 5):
                    a_il_mat = fq_to_matrix(A_k_list[k][i, l], reg, e, p)
                    a_li_mat = fq_to_matrix(A_k_list[k][l, i], reg, e, p)
                    block = (a_il_mat @ B + a_li_mat.T @ B.T) % p
                    H[(i-1)*e:i*e, (l-1)*e:l*e] = (
                        H[(i-1)*e:i*e, (l-1)*e:l*e] + block) % p
            hessians.append(H % p)
    return hessians


def build_block_hessians(p, e, schedule, A_k_list, block_idx,
                          frob_mats, mult, reg, GF):
    """Build e x e Hessian matrices for a single 5x1 block."""
    hessians = []
    for k in range(5):
        a_k, b_k = schedule[k]
        F_a = frob_mats[a_k % e]
        F_b = frob_mats[b_k % e]
        M_ii = fq_to_matrix(A_k_list[k][block_idx, block_idx], reg, e, p)
        for j in range(e):
            B = (F_a.T @ mult[j] @ F_b) % p
            H = (M_ii @ B + M_ii.T @ B.T) % p
            hessians.append(H % p)
    return hessians


def compute_centralizer(matrices, n, p, label=""):
    """
    Compute centralizer {X : X B_i = B_i X for all i}.
    Uses exact row reduction over F_p and COLUMN-MAJOR vectorization.
    """
    I_n = np.eye(n, dtype=int)
    constraints = []
    for Mi in matrices:
        C = (np.kron(Mi.T, I_n) - np.kron(I_n, Mi)) % p
        constraints.append(C)
    M_comm = np.vstack(constraints) % p

    # Exact row reduction via galois
    M_gf = GFp(M_comm)
    M_rr = M_gf.row_reduce()
    M_rr = np.array(M_rr, dtype=np.int64) % p

    n_cols = M_comm.shape[1]
    pivots = []
    for row in range(M_rr.shape[0]):
        for col in range(n_cols):
            if M_rr[row, col] != 0:
                pivots.append(col)
                break
    free_cols = [c for c in range(n_cols) if c not in pivots]

    null_vecs = []
    for fc in free_cols:
        vec = np.zeros(n_cols, dtype=np.int64)
        vec[fc] = 1
        for i, pc in enumerate(pivots):
            vec[pc] = (-M_rr[i, fc]) % p
        null_vecs.append(vec)

    # CRITICAL: column-major reshape
    comm_mats = [v.reshape((n, n), order='F') % p for v in null_vecs]

    # Verify commutation
    max_err = 0
    for X in comm_mats:
        for Mi in matrices[:5]:
            err = np.sum(np.abs((X @ Mi - Mi @ X) % p))
            max_err = max(max_err, err)
    print(f"{label}: dim={len(comm_mats)}, commutation error={max_err}")
    return comm_mats


# ============================================================
# Main experiment
# ============================================================
def main():
    t0 = time.time()
    print("=" * 60)
    print(f"Centralizer — A_k over F_q = GF({p}^{e})")
    print(f"e={e}, p={p}, n={n}")
    print("=" * 60)

    # Generate A_k with entries in F_q
    rng = np.random.default_rng(42)
    A_secret = []
    for k in range(5):
        A = GF(np.zeros((5, 5), dtype=int))
        A[0, 0] = GF(0)
        for i in range(1, 5):
            A[i, i] = alpha ** int(rng.integers(0, p**e - 1))
        for i in range(1, 5):
            A[0, i] = alpha ** int(rng.integers(0, p**e - 1))
            A[i, 0] = alpha ** int(rng.integers(0, p**e - 1))
        A_secret.append(A)

    # Show A_k matrices (diagonal structure only)
    print("\nA_k diagonal entries (as powers of alpha):")
    # Build power lookup table
    power_map = {}
    for pw in range(min(p**e, 100000)):
        power_map[int(alpha ** pw)] = pw
    for k in range(5):
        diags = []
        for i in range(1, 5):
            v = int(A_secret[k][i, i])
            pw = power_map.get(v, -1)
            diags.append(f"a^{pw}" if pw >= 0 else "?")
        print(f"  A_{k} diag: [{', '.join(diags)}]")

    # Build Hessians (j=0 only for speed)
    hessians = build_hessians(p, e, schedule, A_secret,
                               frob_mats, mult, reg, GF, max_j=1)
    print(f"\n{len(hessians)} Hessians ({n}x{n})")

    # Block structure
    H0 = hessians[0]
    print("\nBlock structure (Hessian 0):")
    for bi in range(4):
        for bj in range(4):
            block = H0[bi*e:(bi+1)*e, bj*e:(bj+1)*e]
            norm = int(np.sum(np.abs(block)))
            status = "empty" if norm == 0 else f"norm={norm}"
            print(f"  ({bi},{bj}): {status}")

    # Secret centralizer
    print("\n--- Secret basis ---")
    comm_sec = compute_centralizer(hessians, n, p, "Secret")

    # Public key
    print("\n--- Public key ---")
    rng_s = np.random.default_rng(99)
    while True:
        S = rng_s.integers(0, p, size=(n, n))
        if mat_rank_exact(S.copy(), p) == n:
            break
    S_inv = mod_inv_mat(S, p)
    pub = [(S.T @ H @ S) % p for H in hessians]

    # H_0 (random combination)
    rng_att = np.random.default_rng(123)
    H0_p = None
    for attempt in range(500):
        coeffs = rng_att.integers(0, p, size=len(pub))
        H0_p = sum(int(c) * H for c, H in zip(coeffs, pub)) % p
        if mat_rank_exact(H0_p.copy(), p) == n:
            break
    H0_p_inv = mod_inv_mat(H0_p, p)
    A_pub = [(H0_p_inv @ H) % p for H in pub]

    # Public centralizer
    print("\n--- Public basis (B_i = H_0^{-1} H_i) ---")
    comm_pub = compute_centralizer(A_pub, n, p, "Public")

    # Summary
    print(f"\n{'='*60}")
    print(f"SUMMARY")
    print(f"{'='*60}")
    print(f"  Secret: dim={len(comm_sec)}")
    print(f"  Public: dim={len(comm_pub)}")
    print(f"  (Generic expected: dim=1)")

    print(f"\nTotal time: {time.time()-t0:.1f}s")

    # Return for interactive use
    return {
        'p': p, 'e': e, 'n': n, 'schedule': schedule,
        'A_secret': A_secret, 'hessians': hessians,
        'comm_sec': comm_sec, 'comm_pub': comm_pub,
        'frob_mats': frob_mats, 'mult': mult, 'reg': reg,
        'GF': GF, 'alpha': alpha,
    }


if __name__ == "__main__":
    results = main()
