#!/usr/bin/env python3
"""
Experiments on the full Weil-descent systems for SALAD (diagonal) vs UFOs (dense).

Two systems:
1. Forgery (relaxed): after cancelling 2 blocks, e equations in 5e variables
2. Key recovery: 5e equations in 4e variables (planted instances)

Measures Macaulay ranks at degrees 2, 3, 4, 5 and compares diagonal vs dense.
"""

import galois
import numpy as np
from itertools import combinations
import time
import sys

# ============================================================
# Field setup and Frobenius matrices
# ============================================================

def setup_field(p, e):
    """Create GF(p^e) and precompute Frobenius matrices and multiplication table."""
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    prim_poly = GF.irreducible_poly
    
    # Frobenius matrix F_a: column j = vector(alpha^(j * p^a))
    # alpha^(j*p^a) = (alpha^j)^(p^a) = apply Frobenius a times to alpha^j
    def frob_matrix(a):
        F = np.zeros((e, e), dtype=np.int64)
        for j in range(e):
            val = alpha ** (j * (p ** a))
            vec = np.array(val.vector(), dtype=np.int64)[::-1]  # [coeff of 1, alpha, ...]
            F[:, j] = vec
        return F % p
    
    # Multiplication structure constants: mu[i,j,m] = coeff of alpha^m in alpha^i * alpha^j
    # This is the same as the multiplication table
    mu = np.zeros((e, e, e), dtype=np.int64)
    for i in range(e):
        for j in range(e):
            prod = (alpha ** i) * (alpha ** j)
            vec = np.array(prod.vector(), dtype=np.int64)[::-1]
            mu[i, j, :] = vec
    
    return GF, alpha, mu, frob_matrix

# ============================================================
# System construction by evaluation
# ============================================================

def make_eval_forgery(GF, alpha, schedule, cancel_pair, coeffs, diagonal=True):
    """
    Create evaluation function for the forgery system (relaxed, no line restriction).
    Returns a function: x_vec (5e ints) -> output_vec (e ints, coordinates of F(x) in F_q)
    
    The equation is: sum_{k in residual} P_k(X) = h
    where P_k(X) = sum_i c_{k,i} * X_i^{p^{a_k}+p^{b_k}} (diagonal)
    or    P_k(X) = X^{[a_k]} A_k X^{[b_k]} = sum_{i,j} A_k[i,j] X_i^{[a_k]} X_j^{[b_k]} (dense)
    """
    p = GF.characteristic
    e = GF.degree
    residual = [k for k in range(5) if k not in cancel_pair]
    
    def eval_func(x_vec):
        # Reconstruct X = (X_0, ..., X_4) in F_q^5
        X = []
        for i in range(5):
            Xi = GF(0)
            for j in range(e):
                if x_vec[i*e + j] != 0:
                    Xi += GF(int(x_vec[i*e + j])) * (alpha ** j)
            X.append(Xi)
        
        result = GF(0)
        for k in residual:
            a_k, b_k = schedule[k]
            if diagonal:
                for i in range(5):
                    val = X[i] ** (p ** a_k) * X[i] ** (p ** b_k)
                    result += GF(int(coeffs[k, i])) * val
            else:
                # Dense: P_k(X) = X^{[a_k]} A_k X^{[b_k]} = sum_{i,j} A_k[i,j] X_i^[a_k] X_j^[b_k]
                for i in range(5):
                    for j in range(5):
                        if coeffs[k, i, j] != 0:
                            val = X[i] ** (p ** a_k) * X[j] ** (p ** b_k)
                            result += GF(int(coeffs[k, i, j])) * val
        
        # Return coordinates of result in F_q
        vec = np.array(result.vector(), dtype=np.int64)[::-1]
        return vec % p
    
    return eval_func

def make_eval_keyrecovery(GF, alpha, schedule, coeffs, diagonal=True):
    """
    Create evaluation function for key recovery.
    System: P_k(X) = 0 for k=0,...,4, with X_0 = 1.
    Variables: X_1, ..., X_4 (4e variables over F_p).
    Equations: 5e (5 equations over F_q, each giving e equations over F_p).
    
    For planted instances, coeffs are constructed so that a known Lambda satisfies P_k(Lambda) = 0.
    """
    p = GF.characteristic
    e = GF.degree
    
    def eval_func(x_vec):
        # X_0 = 1, X_1..X_4 from x_vec
        X = [GF(1)]  # X_0 = 1
        for i in range(1, 5):
            Xi = GF(0)
            for j in range(e):
                if x_vec[(i-1)*e + j] != 0:
                    Xi += GF(int(x_vec[(i-1)*e + j])) * (alpha ** j)
            X.append(Xi)
        
        # 5 equations, each gives e coordinates
        output = np.zeros(5 * e, dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            val = GF(0)
            if diagonal:
                for i in range(5):
                    val += GF(int(coeffs[k, i])) * (X[i] ** (p ** a_k) * X[i] ** (p ** b_k))
            else:
                for i in range(5):
                    for j in range(5):
                        if coeffs[k, i, j] != 0:
                            val += GF(int(coeffs[k, i, j])) * (X[i] ** (p ** a_k) * X[j] ** (p ** b_k))
            
            vec = np.array(val.vector(), dtype=np.int64)[::-1]
            output[k*e:(k+1)*e] = vec % p
        
        return output
    
    return eval_func

# ============================================================
# Quadratic system extraction by evaluation
# ============================================================

def extract_quadratic_system(eval_func, n_vars, n_eqs, p):
    """
    Extract the quadratic system (constant + linear + quadratic terms) by evaluation.
    Uses the robust formula:
      c = f(0)
      L_j = (f(e_j) - f(-e_j)) / 2
      Q_jj = (f(e_j) + f(-e_j) - 2c) / 2
      Q_ij = f(e_i + e_j) - f(e_i) - f(e_j) + c
    """
    inv2 = pow(2, p - 2, p)
    
    # Constant term
    c = eval_func(np.zeros(n_vars, dtype=np.int64)) % p
    
    # Cache f(e_j) and f(-e_j)
    f_pos = np.zeros((n_vars, n_eqs), dtype=np.int64)
    f_neg = np.zeros((n_vars, n_eqs), dtype=np.int64)
    
    for j in range(n_vars):
        e_j = np.zeros(n_vars, dtype=np.int64)
        e_j[j] = 1
        neg_e_j = np.zeros(n_vars, dtype=np.int64)
        neg_e_j[j] = p - 1
        
        f_pos[j] = eval_func(e_j) % p
        f_neg[j] = eval_func(neg_e_j) % p
    
    # Linear terms: L_j = (f(e_j) - f(-e_j)) * inv2 mod p
    L = np.zeros((n_eqs, n_vars), dtype=np.int64)
    Q_diag = np.zeros((n_eqs, n_vars), dtype=np.int64)
    for j in range(n_vars):
        L[:, j] = ((f_pos[j] - f_neg[j]) * inv2) % p
        Q_diag[:, j] = ((f_pos[j] + f_neg[j] - 2 * c) * inv2) % p
    
    # Off-diagonal quadratic terms
    # Store as dict: (i, j) -> row vector of n_eqs
    Q_off = {}
    for i in range(n_vars):
        for j in range(i + 1, n_vars):
            e_ij = np.zeros(n_vars, dtype=np.int64)
            e_ij[i] = 1
            e_ij[j] = 1
            f_ij = eval_func(e_ij) % p
            Q_off[(i, j)] = (f_ij - f_pos[i] - f_pos[j] + c) % p
    
    return c, L, Q_diag, Q_off

# ============================================================
# Macaulay matrix construction and rank computation
# ============================================================

def generate_monomials(n, max_deg):
    """Generate all monomials of degree <= max_deg as tuples (exponents)."""
    monos = []
    def gen(idx, remaining, current):
        if idx == n:
            monos.append(tuple(current))
            return
        for d in range(remaining + 1):
            current.append(d)
            gen(idx + 1, remaining - d, current)
            current.pop()
    gen(0, max_deg, [])
    return monos

def monomial_degree(mono):
    return sum(mono)

def build_macaulay_matrix(c, L, Q_diag, Q_off, n_vars, n_eqs, p, degree):
    """
    Build the Macaulay matrix at given degree.
    Rows: for each equation f_i and each monomial m of degree <= degree-2, row = m * f_i
    Columns: all monomials of degree <= degree
    """
    from math import comb
    
    # Generate all monomials up to 'degree'
    all_monos = generate_monomials(n_vars, degree)
    n_cols = len(all_monos)
    mono_to_idx = {m: i for i, m in enumerate(all_monos)}
    
    # Generate multiplier monomials (degree <= degree - 2)
    if degree < 2:
        multipliers = [tuple([0] * n_vars)]
    else:
        multipliers = generate_monomials(n_vars, degree - 2)
    
    n_rows = n_eqs * len(multipliers)
    
    print(f"  Macaulay d={degree}: {n_rows} rows x {n_cols} cols", end="", flush=True)
    
    # Build matrix as list of (row, col, value) for sparse construction
    # For each equation i and multiplier mono_m:
    #   row = i * len(multipliers) + m_idx
    #   The polynomial is mono_m * f_i
    #   f_i = c_i + sum_j L[i,j] * x_j + sum_j Q_diag[i,j] * x_j^2 + sum_{j<k} Q_off[(j,k)][i] * x_j * x_k
    
    # For efficiency, multiply monomials and find their indices
    rows = []
    cols = []
    vals = []
    
    for eq_idx in range(n_eqs):
        for m_idx, m_mono in enumerate(multipliers):
            row = eq_idx * len(multipliers) + m_idx
            # Compute m_mono * f_i
            # Constant term: c[eq_idx] * m_mono -> contributes to m_mono itself
            if c[eq_idx] != 0:
                col = mono_to_idx.get(m_mono)
                if col is not None:
                    rows.append(row)
                    cols.append(col)
                    vals.append(int(c[eq_idx]) % p)
            
            # Linear terms: L[eq_idx, j] * x_j * m_mono
            for j in range(n_vars):
                if L[eq_idx, j] != 0:
                    new_mono = list(m_mono)
                    new_mono[j] += 1
                    new_mono = tuple(new_mono)
                    col = mono_to_idx.get(new_mono)
                    if col is not None:
                        rows.append(row)
                        cols.append(col)
                        vals.append(int(L[eq_idx, j]) % p)
            
            # Diagonal quadratic: Q_diag[eq_idx, j] * x_j^2 * m_mono
            for j in range(n_vars):
                if Q_diag[eq_idx, j] != 0:
                    new_mono = list(m_mono)
                    new_mono[j] += 2
                    new_mono = tuple(new_mono)
                    col = mono_to_idx.get(new_mono)
                    if col is not None:
                        rows.append(row)
                        cols.append(col)
                        vals.append(int(Q_diag[eq_idx, j]) % p)
            
            # Off-diagonal: Q_off[(j, k)][eq_idx] * x_j * x_k * m_mono
            for (j, k), q_vals in Q_off.items():
                if q_vals[eq_idx] != 0:
                    new_mono = list(m_mono)
                    new_mono[j] += 1
                    new_mono[k] += 1
                    new_mono = tuple(new_mono)
                    col = mono_to_idx.get(new_mono)
                    if col is not None:
                        rows.append(row)
                        cols.append(col)
                        vals.append(int(q_vals[eq_idx]) % p)
    
    print(f" ({len(rows)} nonzeros)", end="", flush=True)
    
    # Build dense matrix (or sparse if too large)
    if n_cols <= 5000:
        M = np.zeros((n_rows, n_cols), dtype=np.int64)
        for r, c_col, v in zip(rows, cols, vals):
            M[r, c_col] = (M[r, c_col] + v) % p
        print(" -> dense", flush=True)
        return M, n_rows, n_cols
    else:
        # Use scipy sparse
        from scipy.sparse import csr_matrix
        M = csr_matrix((vals, (rows, cols)), shape=(n_rows, n_cols), dtype=np.int64)
        M = M % p
        print(" -> sparse", flush=True)
        return M, n_rows, n_cols

def rank_mod_p(M, p):
    """Compute rank of matrix M over F_p using Gaussian elimination."""
    if hasattr(M, 'toarray'):
        M = M.toarray()
    M = M.copy().astype(np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        # Find pivot
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        # Swap
        M[[rank, pivot]] = M[[pivot, rank]]
        # Eliminate
        inv_val = pow(int(M[rank, col]), p - 2, p)
        M[rank] = (M[rank] * inv_val) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
    return rank

# ============================================================
# Coefficient generation
# ============================================================

def gen_forgery_coeffs(GF, schedule, cancel_pair, diagonal=True, seed=42):
    """Generate random coefficients for the forgery system."""
    import random
    rng = random.Random(seed)
    p = GF.characteristic
    
    if diagonal:
        # coeffs[k, i] for k=0..4, i=0..4
        coeffs = np.zeros((5, 5), dtype=np.int64)
        for k in range(5):
            for i in range(5):
                coeffs[k, i] = rng.randrange(1, p)
        return coeffs
    else:
        # Dense: coeffs[k, i, j] for k=0..4, i=0..4, j=0..4
        coeffs = np.zeros((5, 5, 5), dtype=np.int64)
        for k in range(5):
            for i in range(5):
                for j in range(5):
                    coeffs[k, i, j] = rng.randrange(1, p)
        return coeffs

def gen_keyrecovery_coeffs(GF, alpha, schedule, diagonal=True, seed=42):
    """
    Generate planted key recovery instance.
    Choose Lambda = (1, L1, L2, L3, L4), then construct A_k so that P_k(Lambda) = 0.
    """
    import random
    rng = random.Random(seed)
    p = GF.characteristic
    
    # Choose random Lambda
    Lambda = [GF(1)]
    for i in range(4):
        Lambda.append(GF(rng.randrange(1, p**GF.degree)))
    
    if diagonal:
        # coeffs[k, i]: choose c_{k,1},...,c_{k,4} randomly, set c_{k,0} so that sum_i c_{k,i} * Lambda_i^{p^{a_k}+p^{b_k}} = 0
        coeffs = np.zeros((5, 5), dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            total = GF(0)
            for i in range(1, 5):
                coeffs[k, i] = rng.randrange(1, p)
                val = Lambda[i] ** (p ** a_k) * Lambda[i] ** (p ** b_k)
                total += GF(int(coeffs[k, i])) * val
            # c_{k,0} * Lambda_0^{p^{a_k}+p^{b_k}} = -total
            # Lambda_0 = 1, so c_{k,0} = -total
            coeffs[k, 0] = int((-total) % p)
        return coeffs, Lambda
    else:
        # Dense: choose A_k[i,j] for (i,j) != (0,0) randomly, set A_k[0,0] so that P_k(Lambda) = 0
        coeffs = np.zeros((5, 5, 5), dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            total = GF(0)
            for i in range(5):
                for j in range(5):
                    if i == 0 and j == 0:
                        continue
                    coeffs[k, i, j] = rng.randrange(1, p)
                    val = Lambda[i] ** (p ** a_k) * Lambda[j] ** (p ** b_k)
                    total += GF(int(coeffs[k, i, j])) * val
            # A_k[0,0] * Lambda_0^{a_k} * Lambda_0^{b_k} = -total
            # Lambda_0 = 1, so A_k[0,0] = -total
            coeffs[k, 0, 0] = int((-total) % p)
        return coeffs, Lambda

# ============================================================
# Validation
# ============================================================

def validate_system(eval_func, c, L, Q_diag, Q_off, n_vars, n_eqs, p, n_tests=3):
    """Validate the extracted system on random points."""
    import random
    rng = random.Random(123)
    max_err = 0
    for _ in range(n_tests):
        x = np.array([rng.randrange(0, p) for _ in range(n_vars)], dtype=np.int64)
        f_exact = eval_func(x) % p
        f_approx = c.copy()
        f_approx = (f_approx + L @ x) % p
        # Quadratic terms
        for j in range(n_vars):
            if Q_diag[:, j].any():
                f_approx = (f_approx + Q_diag[:, j] * x[j] * x[j]) % p
        for (i, j), q_vals in Q_off.items():
            f_approx = (f_approx + q_vals * x[i] * x[j]) % p
        err = np.max(np.abs((f_exact - f_approx) % p))
        max_err = max(max_err, err)
    return max_err

# ============================================================
# Main experiments
# ============================================================

def run_forgery_experiment(p, e, schedule, cancel_pair, diagonal, max_degree=4):
    """Run forgery experiment: e eqs in 5e vars."""
    print(f"\n{'='*60}")
    label = "SALAD (diagonal)" if diagonal else "UFOs (dense)"
    print(f"FORGERY: p={p}, e={e}, {label}")
    print(f"  Schedule: {schedule}")
    print(f"  Cancel pair: {cancel_pair}")
    print(f"  System: {e} eqs in {5*e} vars")
    print(f"{'='*60}")
    
    t0 = time.time()
    GF, alpha, mu, frob_matrix = setup_field(p, e)
    print(f"  Field setup: {time.time()-t0:.1f}s")
    
    # Generate coefficients
    t0 = time.time()
    coeffs = gen_forgery_coeffs(GF, schedule, cancel_pair, diagonal, seed=42)
    print(f"  Coeff generation: {time.time()-t0:.1f}s")
    
    # Create evaluation function
    eval_func = make_eval_forgery(GF, alpha, schedule, cancel_pair, coeffs, diagonal)
    
    # Extract quadratic system
    n_vars = 5 * e
    n_eqs = e
    t0 = time.time()
    c, L, Q_diag, Q_off = extract_quadratic_system(eval_func, n_vars, n_eqs, p)
    print(f"  System extraction: {time.time()-t0:.1f}s ({n_vars} vars, {n_eqs} eqs, {len(Q_off)} off-diag terms)")
    
    # Validate
    err = validate_system(eval_func, c, L, Q_diag, Q_off, n_vars, n_eqs, p)
    print(f"  Validation error: {err}")
    assert err == 0, f"Validation failed with error {err}"
    
    # Build Macaulay matrices and compute ranks
    results = {}
    for d in range(2, max_degree + 1):
        t0 = time.time()
        M, n_rows, n_cols = build_macaulay_matrix(c, L, Q_diag, Q_off, n_vars, n_eqs, p, d)
        if n_cols <= 5000:
            rank = rank_mod_p(M, p)
        else:
            print(f"  (too large for dense rank, skipping)", flush=True)
            rank = -1
        elapsed = time.time() - t0
        expected_rank = min(n_rows, n_cols)
        deficiency = expected_rank - rank if rank >= 0 else -1
        results[d] = (n_rows, n_cols, rank, deficiency)
        print(f"  Rank: {rank}/{expected_rank} (deficiency: {deficiency}) [{elapsed:.1f}s]")
    
    return results

def run_keyrecovery_experiment(p, e, schedule, diagonal, max_degree=4):
    """Run key recovery experiment: 5e eqs in 4e vars."""
    print(f"\n{'='*60}")
    label = "SALAD (diagonal)" if diagonal else "UFOs (dense)"
    print(f"KEY RECOVERY: p={p}, e={e}, {label}")
    print(f"  Schedule: {schedule}")
    print(f"  System: {5*e} eqs in {4*e} vars")
    print(f"{'='*60}")
    
    t0 = time.time()
    GF, alpha, mu, frob_matrix = setup_field(p, e)
    print(f"  Field setup: {time.time()-t0:.1f}s")
    
    # Generate planted instance
    t0 = time.time()
    coeffs, Lambda = gen_keyrecovery_coeffs(GF, alpha, schedule, diagonal, seed=42)
    print(f"  Planted instance: {time.time()-t0:.1f}s")
    
    # Verify planted solution
    t0 = time.time()
    eval_func = make_eval_keyrecovery(GF, alpha, schedule, coeffs, diagonal)
    
    # Check that Lambda satisfies the equations
    lambda_vec = np.zeros(4 * e, dtype=np.int64)
    for i in range(1, 5):
        vec = np.array(Lambda[i].vector(), dtype=np.int64)[::-1]
        lambda_vec[(i-1)*e:i*e] = vec
    check = eval_func(lambda_vec) % p
    assert np.max(check) == 0, f"Planted solution doesn't satisfy equations: max={np.max(check)}"
    print(f"  Planted solution verified: {time.time()-t0:.1f}s")
    
    # Extract quadratic system
    n_vars = 4 * e
    n_eqs = 5 * e
    t0 = time.time()
    c, L, Q_diag, Q_off = extract_quadratic_system(eval_func, n_vars, n_eqs, p)
    print(f"  System extraction: {time.time()-t0:.1f}s ({n_vars} vars, {n_eqs} eqs, {len(Q_off)} off-diag terms)")
    
    # Validate
    err = validate_system(eval_func, c, L, Q_diag, Q_off, n_vars, n_eqs, p)
    print(f"  Validation error: {err}")
    assert err == 0, f"Validation failed with error {err}"
    
    # Build Macaulay matrices and compute ranks
    results = {}
    for d in range(2, max_degree + 1):
        t0 = time.time()
        M, n_rows, n_cols = build_macaulay_matrix(c, L, Q_diag, Q_off, n_vars, n_eqs, p, d)
        if n_cols <= 8000:
            rank = rank_mod_p(M, p)
        else:
            print(f"  (too large for dense rank, skipping)", flush=True)
            rank = -1
        elapsed = time.time() - t0
        expected_rank = min(n_rows, n_cols)
        deficiency = expected_rank - rank if rank >= 0 else -1
        results[d] = (n_rows, n_cols, rank, deficiency)
        print(f"  Rank: {rank}/{expected_rank} (deficiency: {deficiency}) [{elapsed:.1f}s]")
    
    return results

# ============================================================
# Run all experiments
# ============================================================

if __name__ == "__main__":
    # Schedules
    SCHEDULE_CONSEC = [(0,1), (1,2), (2,3), (3,4), (4,5)]
    SCHEDULE_UFOS = [(0,9), (7,54), (13,29), (15,37), (35,47)]
    
    # For e=5: use modulo 5 schedule
    SCHEDULE_MOD5 = [(0,1), (1,2), (2,3), (3,4), (4,0)]
    # For e=7: use modulo 7 schedule  
    SCHEDULE_MOD7 = [(0,1), (1,3), (2,5), (3,0), (4,2)]
    
    cancel_pair = (0, 1)  # Cancel first two blocks
    
    all_results = {}
    
    # === Forgery experiments ===
    for p, e, sched, label in [
        (3, 5, SCHEDULE_MOD5, "mod5"),
        (3, 7, SCHEDULE_MOD7, "mod7"),
        (31, 5, SCHEDULE_MOD5, "mod5"),
        (31, 7, SCHEDULE_MOD7, "mod7"),
    ]:
        for diagonal in [True, False]:
            key = f"forgery_p{p}_e{e}_{label}_{'diag' if diagonal else 'dense'}"
            try:
                results = run_forgery_experiment(p, e, sched, cancel_pair, diagonal, max_degree=4)
                all_results[key] = results
            except Exception as ex:
                print(f"  ERROR: {ex}")
                all_results[key] = f"ERROR: {ex}"
    
    # === Key recovery experiments ===
    for p, e, sched, label in [
        (3, 5, SCHEDULE_MOD5, "mod5"),
        (3, 7, SCHEDULE_MOD7, "mod7"),
        (31, 5, SCHEDULE_MOD5, "mod5"),
        (31, 7, SCHEDULE_MOD7, "mod7"),
    ]:
        for diagonal in [True, False]:
            key = f"keyrec_p{p}_e{e}_{label}_{'diag' if diagonal else 'dense'}"
            try:
                results = run_keyrecovery_experiment(p, e, sched, diagonal, max_degree=4)
                all_results[key] = results
            except Exception as ex:
                print(f"  ERROR: {ex}")
                all_results[key] = f"ERROR: {ex}"
    
    # === Summary ===
    print(f"\n\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    
    print("\n--- FORGERY (e eqs in 5e vars) ---")
    print(f"{'Config':<45} {'d=2':>20} {'d=3':>20} {'d=4':>20}")
    for key, results in all_results.items():
        if not key.startswith("forgery"):
            continue
        if isinstance(results, str):
            print(f"{key:<45} {results}")
            continue
        row = f"{key:<45}"
        for d in [2, 3, 4]:
            if d in results:
                n_rows, n_cols, rank, defic = results[d]
                row += f" {rank}/{min(n_rows,n_cols)} (def={defic})".rjust(20)
            else:
                row += f" {'N/A':>20}"
        print(row)
    
    print("\n--- KEY RECOVERY (5e eqs in 4e vars) ---")
    print(f"{'Config':<45} {'d=2':>20} {'d=3':>20} {'d=4':>20}")
    for key, results in all_results.items():
        if not key.startswith("keyrec"):
            continue
        if isinstance(results, str):
            print(f"{key:<45} {results}")
            continue
        row = f"{key:<45}"
        for d in [2, 3, 4]:
            if d in results:
                n_rows, n_cols, rank, defic = results[d]
                row += f" {rank}/{min(n_rows,n_cols)} (def={defic})".rjust(20)
            else:
                row += f" {'N/A':>20}"
        print(row)
    
    # Compare diagonal vs dense
    print("\n--- DIAGONAL vs DENSE comparison ---")
    for prefix in ["forgery", "keyrec"]:
        for p, e, label in [(3, 5, "mod5"), (3, 7, "mod7"), (31, 5, "mod5"), (31, 7, "mod7")]:
            diag_key = f"{prefix}_p{p}_e{e}_{label}_diag"
            dense_key = f"{prefix}_p{p}_e{e}_{label}_dense"
            if diag_key in all_results and dense_key in all_results:
                if isinstance(all_results[diag_key], str) or isinstance(all_results[dense_key], str):
                    continue
                print(f"\n  {prefix} p={p} e={e} {label}:")
                for d in [2, 3, 4]:
                    if d in all_results[diag_key] and d in all_results[dense_key]:
                        _, _, r_diag, def_diag = all_results[diag_key][d]
                        _, _, r_dense, def_dense = all_results[dense_key][d]
                        match = "MATCH" if def_diag == def_dense else "DIFFER"
                        print(f"    d={d}: diag def={def_diag}, dense def={def_dense} -> {match}")
