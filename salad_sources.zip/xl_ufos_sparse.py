"""
Optimized: Gram matrix via scipy.sparse for UFOs Level I.

Strategy:
1. Precompute ALL distinct Frobenius vectors (done once, ~10s)
2. For each triplet: build Q, build sparse C, compute G = C^T @ C, rank(G)
3. Test 3 representative triplets for e=61
"""

import numpy as np
import scipy.sparse as sp
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def precompute_frobenius(GF, p, e, all_exps):
    """Precompute phi_a(alpha^j) for all distinct exponents a."""
    frob_cache = {}
    for a in all_exps:
        frob_exp = pow(p, a, p**e - 1)
        prim = GF.primitive_element
        alpha_frob = prim ** frob_exp
        vecs = []
        current = GF(1)
        for j in range(e):
            vecs.append(current)
            current = current * alpha_frob
        frob_cache[a] = vecs
    return frob_cache

def build_Q_fast(GF, p, e, terms, frob_cache):
    """Build Q using precomputed Frobenius vectors."""
    n_pairs = e * (e + 1) // 2
    U = np.zeros((e, n_pairs), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            field_elem = GF(0)
            for a, b, c_int in terms:
                fa = frob_cache[a][k]
                fb = frob_cache[b][l]
                field_elem = field_elem + GF(c_int) * (fa * fb)
            vec = np.array(field_elem.vector(), dtype=np.int64)
            U[:, idx] = vec[::-1]
            idx += 1
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            Q[:, k, l] = U[:, idx]
            Q[:, l, k] = U[:, idx]
            idx += 1
    return Q

def build_sparse_C(Q, e, p):
    """Build constraint matrix C as a scipy sparse matrix."""
    n_cols = e * e
    cubic_mons = list(combinations_with_replacement(range(e), 3))
    n_rows = len(cubic_mons)
    
    rows = []
    cols = []
    data = []
    
    for row_idx, (a, b, c) in enumerate(cubic_mons):
        if a == b == c:
            for i in range(e):
                val = int(Q[i, a, a])
                if val != 0:
                    rows.append(row_idx)
                    cols.append(i * e + a)
                    data.append(val)
        elif a == b:
            for i in range(e):
                v1 = (2 * int(Q[i, a, c])) % p
                v2 = int(Q[i, a, a])
                if v1 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + a)
                    data.append(v1)
                if v2 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + c)
                    data.append(v2)
        elif b == c:
            for i in range(e):
                v1 = (2 * int(Q[i, a, b])) % p
                v2 = int(Q[i, b, b])
                if v1 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + b)
                    data.append(v1)
                if v2 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + a)
                    data.append(v2)
        else:
            for i in range(e):
                v1 = (2 * int(Q[i, b, c])) % p
                v2 = (2 * int(Q[i, a, c])) % p
                v3 = (2 * int(Q[i, a, b])) % p
                if v1 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + a)
                    data.append(v1)
                if v2 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + b)
                    data.append(v2)
                if v3 != 0:
                    rows.append(row_idx)
                    cols.append(i * e + c)
                    data.append(v3)
    
    C = sp.csr_matrix((data, (rows, cols)), shape=(n_rows, n_cols), dtype=np.int32)
    return C

def gauss_elim_rank(M, p):
    """Compute rank of M mod p."""
    M = M.copy().astype(np.int64) % p
    n_rows, n_cols = M.shape
    rank = 0
    for col in range(min(n_rows, n_cols)):
        if rank >= n_rows:
            break
        col_slice = M[rank:, col] % p
        nonzero = np.where(col_slice != 0)[0]
        if len(nonzero) == 0:
            continue
        pivot_idx = nonzero[0] + rank
        if pivot_idx != rank:
            M[[rank, pivot_idx]] = M[[pivot_idx, rank]]
        inv_val = pow(int(M[rank, col]), p-2, p)
        M[rank] = (M[rank] * inv_val) % p
        factors = M[:, col].copy()
        factors[rank] = 0
        mask = factors != 0
        if np.any(mask):
            M[mask] = (M[mask] - factors[mask, np.newaxis] * M[rank]) % p
        rank += 1
    return rank

# === Validation: e=7, p=31, consecutive ===
print("="*80)
print("VALIDATION: e=7, p=31, consecutive schedule")
print("="*80)

p, e = 31, 7
GF = galois.GF(p**e)
schedule = [(0,1),(1,2),(2,3),(3,4),(4,5)]
cancel = (0, 1)
residual = [schedule[k] for k in range(5) if k not in cancel]

all_exps = set()
for a, b in schedule:
    all_exps.add(a)
    all_exps.add(b)
frob_cache = precompute_frobenius(GF, p, e, all_exps)
print(f"Frobenius vectors precomputed for exponents: {sorted(all_exps)}")

rng = random.Random(42)
x0_int = rng.randint(1, p**e - 1)
x0 = GF(x0_int)
rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
terms = []
for a, b in residual:
    c_int = int(GF(rng_c.randint(1, p**e - 1)))
    terms.append((a, b, c_int))

t0 = time.time()
Q = build_Q_fast(GF, p, e, terms, frob_cache)
print(f"Q built in {time.time()-t0:.1f}s")

t1 = time.time()
C_sparse = build_sparse_C(Q, e, p)
print(f"Sparse C built in {time.time()-t1:.1f}s, shape: {C_sparse.shape}, nnz: {C_sparse.nnz}")

t2 = time.time()
G = (C_sparse.T @ C_sparse).toarray().astype(np.int64) % p
print(f"Gram matrix computed in {time.time()-t2:.1f}s, shape: {G.shape}")

t3 = time.time()
rank = gauss_elim_rank(G, p)
print(f"Rank computed in {time.time()-t3:.1f}s")
print(f"C rank (via Gram): {rank}/{e*e}")
print(f"Syzygy dim: {e*e - rank}")
print(f"D_lin@3: {'YES' if rank < e*e else 'no'}")

# === Real UFOs Level I: p=31, e=61 ===
print("\n" + "="*80)
print("REAL UFOs Level I: p=31, e=61")
print("="*80)

p, e = 31, 61
ufos_schedule = [(0,9),(7,54),(13,29),(15,37),(35,47)]
GF = galois.GF(p**e)

all_exps_61 = set()
for a, b in ufos_schedule:
    all_exps_61.add(a)
    all_exps_61.add(b)
print(f"Distinct exponents: {sorted(all_exps_61)}")

t0 = time.time()
frob_cache_61 = precompute_frobenius(GF, p, e, all_exps_61)
print(f"Frobenius vectors precomputed in {time.time()-t0:.1f}s")

# Test 3 representative triplets
test_triplets = [(0,1), (0,2), (1,2)]
all_results = []

for cancel in test_triplets:
    residual = [ufos_schedule[k] for k in range(5) if k not in cancel]
    print(f"\n--- Cancel {cancel}, residual: {residual} ---")
    
    rng = random.Random(42)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
    terms = []
    for a, b in residual:
        c_int = int(GF(rng_c.randint(1, p**e - 1)))
        terms.append((a, b, c_int))
    
    t0 = time.time()
    Q = build_Q_fast(GF, p, e, terms, frob_cache_61)
    t_q = time.time() - t0
    print(f"  Q built in {t_q:.1f}s")
    
    t1 = time.time()
    C_sparse = build_sparse_C(Q, e, p)
    t_c = time.time() - t1
    print(f"  Sparse C built in {t_c:.1f}s, nnz: {C_sparse.nnz}")
    
    t2 = time.time()
    G = (C_sparse.T @ C_sparse).toarray().astype(np.int64) % p
    t_g = time.time() - t2
    print(f"  Gram matrix in {t_g:.1f}s")
    
    t3 = time.time()
    rank = gauss_elim_rank(G, p)
    t_r = time.time() - t3
    
    syz_dim = e*e - rank
    dlin = rank < e*e
    
    print(f"  Rank in {t_r:.1f}s: C rank={rank}/{e*e}, syz={syz_dim}, D_lin@3={'YES' if dlin else 'no'}")
    all_results.append((cancel, rank, syz_dim, dlin))

print(f"\n{'='*80}")
print("SUMMARY: UFOs Level I (p=31, e=61)")
print(f"{'='*80}")
for cancel, rank, syz, dlin in all_results:
    print(f"  Cancel {cancel}: rank={rank}/{e*e}, syz={syz}, D_lin@3={'YES' if dlin else 'no'}")
