"""
Measure degree of regularity for the Weil descent of the 3-term residual
forgery equation: sum_r c_r * x^(p^{a_r} + p^{b_r}) = h  over F_{p^e}

Weil descent gives e quadratic equations in e variables over F_p:
  Q_i(x_0,...,x_{e-1}) = h_i  for i = 0,...,e-1

We build the Macaulay matrix at each degree d, INCLUDING constant terms,
and measure rank, falls, and solving degree.
"""

import numpy as np
import galois
from itertools import combinations_with_replacement
import random, sys, time

def frobenius_matrix(GF, p, e, a):
    prim = GF.primitive_element
    M = np.zeros((e, e), dtype=np.int64)
    for j in range(e):
        exp = (j * (p ** a)) % (p**e - 1)
        val = prim ** exp
        M[:, j] = np.array(val.vector(), dtype=np.int64)
    return M

def vec_to_int(v, p, e):
    val = 0
    for i in range(e):
        val += int(v[i]) * (p ** i)
    return val

def build_mult_table(GF, p, e):
    mult_table = np.zeros((e, e, e), dtype=np.int64)
    for j in range(e):
        for k in range(e):
            v1 = np.zeros(e, dtype=np.int64); v1[j] = 1
            v2 = np.zeros(e, dtype=np.int64); v2[k] = 1
            e1 = GF(vec_to_int(v1, p, e))
            e2 = GF(vec_to_int(v2, p, e))
            prod = e1 * e2
            mult_table[j, k, :] = np.array(prod.vector(), dtype=np.int64)
    return mult_table

def build_system(GF, p, e, terms, mult_table):
    """
    Build the quadratic system: e equations in e variables.
    Returns: Q (e x e x e quadratic coeffs), h_vec (e constants)
    """
    frob_cache = {}
    for a, b, c_int in terms:
        if a not in frob_cache:
            frob_cache[a] = frobenius_matrix(GF, p, e, a)
        if b not in frob_cache:
            frob_cache[b] = frobenius_matrix(GF, p, e, b)
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    for a, b, c_int in terms:
        Fa = frob_cache[a]; Fb = frob_cache[b]
        c = GF(c_int)
        c_vec = np.array(c.vector(), dtype=np.int64)
        for i in range(e):
            for j in range(e):
                for k in range(e):
                    Q[i, j, k] += int(c_vec[i]) * int(Fa[i, j]) * int(Fb[i, k]) * int(mult_table[j, k, i])
                    Q[i, j, k] %= p
    Q = (Q + Q.transpose(0, 2, 1)) // 2
    Q = Q % p
    
    # h vector (random target)
    h = GF(random.randint(0, p**e - 1))
    h_vec = np.array(h.vector(), dtype=np.int64)
    
    return Q, h_vec

def build_macaulay(Q, h_vec, e, d):
    """
    Build Macaulay matrix at degree d.
    Rows: e * C(e + d - 2, d - 2) (equations * monomials of degree d-2)
    Columns: C(e + d, d) (all monomials of degree <= d)
    
    Each row corresponds to: (equation_i * monomial_m)
    = Q[i,j,k] * x_j * x_k * m  +  (-h_i) * m
    
    The constant term -h_i is included when m has degree 0 (i.e., d=2).
    For d > 2, the constant term multiplied by m gives a degree-(d-2) term.
    """
    n = e
    
    # All monomials of degree <= d
    all_mons = []
    for deg in range(d + 1):
        for combo in combinations_with_replacement(range(n), deg):
            all_mons.append(combo)
    n_cols = len(all_mons)
    mon_idx = {m: i for i, m in enumerate(all_mons)}
    
    if d < 2:
        return np.zeros((0, n_cols)), n_cols
    
    # Multiplier monomials of degree d-2
    mult_mons = list(combinations_with_replacement(range(n), d - 2))
    n_rows = e * len(mult_mons)
    M = np.zeros((n_rows, n_cols), dtype=np.float64)
    
    row = 0
    for eq_idx in range(e):
        for mult in mult_mons:
            # Quadratic part: Q[eq_idx, j, k] * x_j * x_k * mult
            for j in range(n):
                for k in range(n):
                    coeff = int(Q[eq_idx, j, k])
                    if coeff != 0:
                        prod = tuple(sorted(mult + (j, k)))
                        if prod in mon_idx:
                            M[row, mon_idx[prod]] += coeff
            # Constant part: -h_i * mult
            h_coeff = int(h_vec[eq_idx])
            if h_coeff != 0:
                if mult in mon_idx:
                    M[row, mon_idx[mult]] -= h_coeff
            row += 1
    
    return M, n_cols

def measure_d_reg(p, e, terms, max_d=None, label=""):
    t0 = time.time()
    GF = galois.GF(p**e)
    mult_table = build_mult_table(GF, p, e)
    Q, h_vec = build_system(GF, p, e, terms, mult_table)
    t1 = time.time()
    
    if max_d is None:
        max_d = e + 3
    
    print(f"  {label}: p={p}, e={e}, terms={[(a,b) for a,b,c in terms]}  (setup {t1-t0:.1f}s)")
    sys.stdout.flush()
    results = []
    for d in range(2, max_d + 1):
        t2 = time.time()
        M, n_cols = build_macaulay(Q, h_vec, e, d)
        if M.shape[0] == 0:
            continue
        n_rows = M.shape[0]
        rank = np.linalg.matrix_rank(M, tol=1e-6)
        falls = n_cols - rank
        results.append((d, rank, n_cols, n_rows, falls))
        t3 = time.time()
        print(f"    d={d}: rank={rank}, rows={n_rows}, cols={n_cols}, falls={falls}  ({t3-t2:.1f}s)")
        sys.stdout.flush()
    
    return results

if __name__ == "__main__":
    print("="*70)
    print("Degree of regularity: 3-term residual vs 5-term full")
    print("Frobenius-sum Weil descent WITH constant terms")
    print("="*70)
    print()
    
    random.seed(42)
    
    # Test 1: p=3, e=5, 3-term
    print("--- p=3, e=5, 3-term residual ---")
    GF = galois.GF(3**5)
    terms = [(0, 1, int(GF(random.randint(1, 3**5-1)))),
             (2, 3, int(GF(random.randint(1, 3**5-1)))),
             (4, 0, int(GF(random.randint(1, 3**5-1))))]
    measure_d_reg(3, 5, terms, max_d=8, label="3-term")
    print()
    
    # Test 2: p=3, e=5, 5-term
    print("--- p=3, e=5, 5-term full ---")
    terms = [(0, 1, int(GF(random.randint(1, 3**5-1)))),
             (1, 2, int(GF(random.randint(1, 3**5-1)))),
             (2, 3, int(GF(random.randint(1, 3**5-1)))),
             (3, 4, int(GF(random.randint(1, 3**5-1)))),
             (4, 0, int(GF(random.randint(1, 3**5-1))))]
    measure_d_reg(3, 5, terms, max_d=8, label="5-term")
    print()
    
    # Test 3: p=5, e=5, 3-term
    print("--- p=5, e=5, 3-term residual ---")
    GF5 = galois.GF(5**5)
    terms = [(0, 1, int(GF5(random.randint(1, 5**5-1)))),
             (2, 3, int(GF5(random.randint(1, 5**5-1)))),
             (4, 0, int(GF5(random.randint(1, 5**5-1))))]
    measure_d_reg(5, 5, terms, max_d=8, label="3-term")
    print()
    
    # Test 4: p=5, e=5, 5-term
    print("--- p=5, e=5, 5-term full ---")
    terms = [(0, 1, int(GF5(random.randint(1, 5**5-1)))),
             (1, 2, int(GF5(random.randint(1, 5**5-1)))),
             (2, 3, int(GF5(random.randint(1, 5**5-1)))),
             (3, 4, int(GF5(random.randint(1, 5**5-1)))),
             (4, 0, int(GF5(random.randint(1, 5**5-1))))]
    measure_d_reg(5, 5, terms, max_d=8, label="5-term")
    print()
    
    # Test 5: p=3, e=7, 3-term
    print("--- p=3, e=7, 3-term residual ---")
    GF7 = galois.GF(3**7)
    terms = [(0, 1, int(GF7(random.randint(1, 3**7-1)))),
             (2, 3, int(GF7(random.randint(1, 3**7-1)))),
             (4, 5, int(GF7(random.randint(1, 3**7-1))))]
    measure_d_reg(3, 7, terms, max_d=10, label="3-term")
    print()
    
    # Test 6: p=3, e=7, 5-term
    print("--- p=3, e=7, 5-term full ---")
    terms = [(0, 1, int(GF7(random.randint(1, 3**7-1)))),
             (1, 2, int(GF7(random.randint(1, 3**7-1)))),
             (2, 3, int(GF7(random.randint(1, 3**7-1)))),
             (3, 4, int(GF7(random.randint(1, 3**7-1)))),
             (4, 5, int(GF7(random.randint(1, 3**7-1))))]
    measure_d_reg(3, 7, terms, max_d=10, label="5-term")
    print()
    
    # Test 7: p=7, e=5, 3-term
    print("--- p=7, e=5, 3-term residual ---")
    GF7p = galois.GF(7**5)
    terms = [(0, 1, int(GF7p(random.randint(1, 7**5-1)))),
             (2, 3, int(GF7p(random.randint(1, 7**5-1)))),
             (4, 0, int(GF7p(random.randint(1, 7**5-1))))]
    measure_d_reg(7, 5, terms, max_d=8, label="3-term")
    print()
    
    print("DONE")
