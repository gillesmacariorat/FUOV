#!/usr/bin/env python3
"""
block_degree_profile.py — Macaulay matrix rank profile for 5x1 Frobenius block.
Measures degree falls to determine the degree of regularity d_reg.

Usage:
    python3 block_degree_profile.py
"""
import numpy as np
import galois
import time
from itertools import combinations_with_replacement

# ============================================================
# Parameters (must match centralizer_fq_exact.py)
# ============================================================
p = 31
e = 5
schedule = [(0,1), (1,2), (2,3), (3,4), (0,4)]


# ============================================================
# Field setup
# ============================================================
GF = galois.GF(p**e)
alpha = GF.primitive_element

frob_mats = []
for a in range(e):
    F = np.zeros((e, e), dtype=int)
    fa = alpha ** (p**a)
    for i in range(e):
        F[:, i] = np.array((fa ** i).vector(), dtype=int) % p
    frob_mats.append(F % p)

mult = np.zeros((e, e, e), dtype=int)
for m in range(e):
    for n2 in range(e):
        mult[:, m, n2] = np.array(((alpha**m) * (alpha**n2)).vector(), dtype=int) % p

reg = np.zeros((e, e, e), dtype=int)
for k in range(e):
    ak = alpha ** k
    for j in range(e):
        reg[:, j, k] = np.array((ak * (alpha ** j)).vector(), dtype=int) % p


# ============================================================
# Utility functions
# ============================================================
def fq_to_matrix(fq_el, reg, e, p):
    """Convert F_q element to e x e matrix over F_p."""
    vec = np.array(fq_el.vector(), dtype=int) % p
    M = np.zeros((e, e), dtype=np.int64)
    for k in range(e):
        if vec[k] != 0:
            M = (M + int(vec[k]) * reg[:, :, k]) % p
    return M


def mat_rank_fast(M, p):
    """Exact rank over F_p via Gaussian elimination."""
    M = np.array(M, dtype=np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        if pivot != rank:
            M[[rank, pivot]] = M[[pivot, rank]]
        inv_val = pow(int(M[rank, col]), -1, p)
        M[rank] = (M[rank] * inv_val) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
        if rank >= rows:
            break
    return rank


def build_macaulay(hessians, n_var, degree, p):
    """
    Build the Macaulay matrix at the given degree.
    Rows: n_eq * C(n_var + d - 3, d - 2)
    Cols: C(n_var + d - 1, d)  (monomials of degree exactly d)
    """
    n_eq = len(hessians)
    if degree < 2:
        return np.zeros((0, 0), dtype=int)
    mult_mons = list(combinations_with_replacement(range(n_var), degree - 2))
    col_mons = list(combinations_with_replacement(range(n_var), degree))
    n_rows = n_eq * len(mult_mons)
    n_cols = len(col_mons)
    col_idx = {m: i for i, m in enumerate(col_mons)}
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    for eq_i, H in enumerate(hessians):
        for mult_i, mult_mon in enumerate(mult_mons):
            row = eq_i * len(mult_mons) + mult_i
            for i in range(n_var):
                for j in range(n_var):
                    if H[i, j] != 0:
                        combined = tuple(sorted(mult_mon + (i, j)))
                        if combined in col_idx:
                            M[row, col_idx[combined]] = (
                                M[row, col_idx[combined]] + int(H[i, j])) % p
    return M % p


def measure_dreg(hessians, n_var, p, max_degree, label=""):
    """Measure degree falls at each degree up to max_degree."""
    print(f"\n{label}: {len(hessians)} equations, {n_var} variables")
    print(f"{'d':>3} | {'rows':>6} {'cols':>6} | {'rank':>6} {'null':>5} | {'time':>6}")
    print("-" * 45)

    first_fall = None
    for d in range(2, max_degree + 1):
        t0 = time.time()
        M = build_macaulay(hessians, n_var, d, p)
        n_rows, n_cols = M.shape
        rank = mat_rank_fast(M, p)
        nullity = n_cols - rank
        elapsed = time.time() - t0
        marker = " ***" if nullity > 0 else ""
        print(f"{d:>3} | {n_rows:>6} {n_cols:>6} | {rank:>6} {nullity:>5} | {elapsed:>5.1f}s{marker}")
        if nullity > 0 and first_fall is None:
            first_fall = d
            print(f"  => FIRST DEGREE FALL at d={d}")

    if first_fall is None:
        print(f"  => d_reg > {max_degree}")
    else:
        print(f"  => d_reg = {first_fall}")

    # HFE bound
    D = 1 + p  # minimal Frobenius difference delta=1
    d_hfe = (p - 1) * (int(np.log(D - 1) / np.log(p)) + 1) // 2 + 2
    print(f"  HFE bound (Ding-Yang, delta=1, p={p}): d_reg <= {d_hfe}")

    return first_fall


# ============================================================
# Build block Hessians
# ============================================================
def build_block_hessians(block_idx=1):
    """Build e x e Hessian matrices for a single 5x1 Frobenius block."""
    rng = np.random.default_rng(42)
    A_secret = []
    for k in range(5):
        A = GF(np.zeros((5, 5), dtype=int))
        A[0, 0] = GF(0)
        for i in range(1, 5):
            A[i, i] = alpha ** int(rng.integers(0, p**e - 1))
        for i in range(1, 5):
            A[0, i] = alpha ** int(rng.integers(0, p**e - 1))
            A[i, 0] = alpha ** int(rng.integers(0, p**e - 1))
        A_secret.append(A)

    block_hess = []
    for k in range(5):
        a_k, b_k = schedule[k]
        F_a = frob_mats[a_k % e]
        F_b = frob_mats[b_k % e]
        M_ii = fq_to_matrix(A_secret[k][block_idx, block_idx], reg, e, p)
        for j in range(e):
            B = (F_a.T @ mult[j] @ F_b) % p
            H = (M_ii @ B + M_ii.T @ B.T) % p
            block_hess.append(H % p)
    return block_hess


def build_generic_mq(n_eq, n_var, p, seed=777):
    """Build generic MQ system (random symmetric, zero diagonal)."""
    rng = np.random.default_rng(seed)
    hessians = []
    for i in range(n_eq):
        R = rng.integers(0, p, size=(n_var, n_var))
        H = ((R + R.T) // 1) % p
        for d in range(n_var):
            H[d, d] = 0
        hessians.append(H % p)
    return hessians


# ============================================================
# Main
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print(f"Block degree of regularity — e={e}, p={p}")
    print("=" * 60)

    # Frobenius 5x1 block
    block_hess = build_block_hessians(block_idx=1)
    d_reg_frob = measure_dreg(block_hess, e, p, max_degree=10, label="Frobenius 5x1")

    # Generic MQ comparison
    n_eq_block = 5 * e
    mq_hess = build_generic_mq(n_eq_block, e, p)
    d_reg_mq = measure_dreg(mq_hess, e, p, max_degree=5, label="Generic MQ")

    # Summary
    print(f"\n{'=' * 60}")
    print("SUMMARY")
    print(f"{'=' * 60}")
    if d_reg_frob:
        print(f"  Frobenius 5x1: d_reg = {d_reg_frob}")
    else:
        print(f"  Frobenius 5x1: d_reg > 10")
    if d_reg_mq:
        print(f"  Generic MQ:    d_reg = {d_reg_mq}")
    D = 1 + p
    d_hfe = (p - 1) * (int(np.log(D - 1) / np.log(p)) + 1) // 2 + 2
    print(f"  HFE bound:     d_reg <= {d_hfe}")
