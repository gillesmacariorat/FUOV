"""
Confirm the deficiency pattern e × C(n+d-2, d-2) for diagonal key recovery.
Priority 1: e=5, d=4 (predicted def = 5 × C(22,2) = 1155)
Priority 2: Multi-seed e=5 (seeds 0-9) at d=2,3,4
Priority 3: Multi-seed e=7,11,13 (seeds 0-9 / 0-5) at d=2,3
"""
import numpy as np, galois, time, csv, sys
from forgery_keyrec_v3 import *
from sparse_gauss import build_macaulay_sparse, sparse_rank
from math import comb

SCHEDULES = {
    5:  [(0,1), (1,2), (2,3), (3,4), (4,0)],
    7:  [(0,1), (1,3), (2,5), (3,0), (4,2)],
    11: [(0,2), (1,5), (3,7), (4,9), (6,10)],
    13: [(0,2), (1,4), (3,7), (5,9), (6,11)],
}

def run_one(p, e, diagonal, seed, d):
    sched = SCHEDULES[e]
    GF, alpha, mu, frob_fn = setup_field(p, e)
    coeffs_fq, Lambda = gen_keyrecovery_coeffs(GF, alpha, p, e, sched, diagonal, seed=seed)
    Q, L, c = build_keyrecovery_system(p, e, sched, coeffs_fq, diagonal, mu, frob_fn)
    
    # Verify planted
    lambda_vec = np.zeros(4*e, dtype=np.int64)
    for i in range(1, 5):
        vec = np.array(Lambda[i].vector(), dtype=np.int64)[::-1]
        lambda_vec[(i-1)*e:i*e] = vec
    check = c.copy()
    check = (check + L @ lambda_vec) % p
    for eq in range(5*e):
        check[eq] = (check[eq] + lambda_vec @ Q[eq] @ lambda_vec) % p
    planted_ok = int(np.max(check)) == 0
    
    rows_data, n_rows, n_cols = build_macaulay_sparse(Q, L, c, 4*e, 5*e, p, d)
    total_nnz = sum(len(r) for r in rows_data)
    
    t0 = time.time()
    rank = sparse_rank(rows_data, n_cols, p, verbose=False)
    elapsed = time.time() - t0
    
    expected_def = e * comb(4*e + d - 2, d - 2) if not diagonal else e * comb(4*e + d - 2, d - 2)
    actual_def = min(n_rows, n_cols) - rank
    
    return {
        'p': p, 'e': e, 'seed': seed, 'variant': 'diag' if diagonal else 'dense',
        'd': d, 'rows': n_rows, 'cols': n_cols, 'rank': rank, 'def': actual_def,
        'expected_def': expected_def if diagonal else 0,
        'nnz': total_nnz, 'density': f'{100.0*total_nnz/(n_rows*n_cols):.2f}',
        'time': f'{elapsed:.1f}', 'planted_ok': planted_ok,
    }

# CSV output
csvfile = open('pattern_results.csv', 'w', newline='')
writer = csv.DictWriter(csvfile, fieldnames=['p','e','seed','variant','d','rows','cols','rank','def','expected_def','nnz','density','time','planted_ok'])
writer.writeheader()

results = []

# Priority 1: e=5, d=4 (the key prediction)
print("=" * 70)
print("PRIORITY 1: e=5, d=4 — predicted def = 5 × C(22,2) = 1155")
print("=" * 70)
for p in [3, 31]:
    for diagonal in [True, False]:
        r = run_one(p, 5, diagonal, 42, 4)
        results.append(r)
        writer.writerow(r)
        print(f"  p={p} {r['variant']} d=4: {r['rows']}x{r['cols']} rank={r['rank']} def={r['def']} expected={r['expected_def']} [{r['time']}s]")
        sys.stdout.flush()

# Priority 2: Multi-seed e=5 at d=2,3,4
print("\n" + "=" * 70)
print("PRIORITY 2: Multi-seed e=5 (seeds 0-9)")
print("=" * 70)
for p in [3]:
    for seed in range(10):
        for diagonal in [True, False]:
            for d in [2, 3]:
                r = run_one(p, 5, diagonal, seed, d)
                results.append(r)
                writer.writerow(r)
                match = "MATCH" if (diagonal and r['def'] == r['expected_def']) or (not diagonal and r['def'] == 0) else "MISMATCH"
                print(f"  p={p} seed={seed} {r['variant']} d={d}: rank={r['rank']}/{min(r['rows'],r['cols'])} def={r['def']} {match}")
                sys.stdout.flush()

# Also d=4 for a few seeds
for p in [3]:
    for seed in range(5):
        for diagonal in [True, False]:
            r = run_one(p, 5, diagonal, seed, 4)
            results.append(r)
            writer.writerow(r)
            match = "MATCH" if (diagonal and r['def'] == r['expected_def']) or (not diagonal and r['def'] == 0) else "MISMATCH"
            print(f"  p={p} seed={seed} {r['variant']} d=4: rank={r['rank']}/{min(r['rows'],r['cols'])} def={r['def']} {match}")
            sys.stdout.flush()

# Priority 3: Multi-seed e=7,11,13 at d=2,3
print("\n" + "=" * 70)
print("PRIORITY 3: Multi-seed e>=7 (confirm disappearance)")
print("=" * 70)
for e in [7, 11, 13]:
    for p in [3]:
        n_seeds = 10 if e == 7 else (6 if e == 11 else 3)
        for seed in range(n_seeds):
            for diagonal in [True, False]:
                for d in [2, 3]:
                    r = run_one(p, e, diagonal, seed, d)
                    results.append(r)
                    writer.writerow(r)
                    match = "OK" if r['def'] == 0 else "DEFICIENCY!"
                    print(f"  p={p} e={e} seed={seed} {r['variant']} d={d}: rank={r['rank']}/{min(r['rows'],r['cols'])} def={r['def']} {match}")
                    sys.stdout.flush()

csvfile.close()
print(f"\nTotal experiments: {len(results)}")
print("Results saved to pattern_results.csv")
