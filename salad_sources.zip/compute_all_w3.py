#!/usr/bin/env python3
"""
compute_all_w3.py — Stage 1: Window-score precomputation and quintuplet filtering.

This script implements the first stage of the improved exponent-hardening pipeline
for the UFOs / SALAD signature scheme.  Given an extension degree e, it:

  1. Precomputes the w3 window score for every triplet of Frobenius deltas
     (a, b, c) in Z/eZ.  The w3 score measures, for the best common Frobenius
     shift, how spread out the three residual endpoints are on the cyclic
     group Z/eZ.  A higher score means the univariate polynomial after
     cancellation has higher degree and is harder to factor.

  2. Searches for quintuplets (d1, ..., d5) of deltas such that *every*
     triplet among them has a w3 score above a threshold.  The threshold
     is lowered from the maximum until at least one valid quintuplet is
     found.

  3. For each valid quintuplet, computes the full window diagnostic
     (w3, w4, w5) and saves the best candidate to a JSON file.

The output is consumed by deltas_points_2.py (Stage 2: shift optimization
to maximize the linear span L) and post_process_2.py (Stage 3: full
diagnostic certification).

Reference:
  Bariant, "On Exponent-Only Hardening of Frobenius-UOV" (2026).
"""

import itertools
import json
import math
import random
import sys

# =====================================================================
# Configuration
# =====================================================================

UFO_E = 127          # Extension degree: set to 61, 89, or 127 for Levels I, III, V
JSON_OUTPUT_FILE = f"deltas_wt_{UFO_E}.json"

# Units of Z/eZ (elements coprime to e) — used for Frobenius shift search
UNITS = [u for u in range(1, UFO_E) if math.gcd(u, UFO_E) == 1]


# =====================================================================
# Window-score computation
# =====================================================================

def compute_window_diagnostic_fast(deltas, e, t):
    """
    Compute the w_t window score for a set of deltas.

    For each subset I of t blocks (out of len(deltas)), and each Frobenius
    shift u (a unit of Z/eZ), compute the sum of circular distances:

        sum_{k in I} min(u * delta_k mod e, e - (u * delta_k mod e))

    The w_t score is the minimum over all subsets I and all units u.
    A higher score means no Frobenius shift can compress the t residual
    endpoints into a short window, so the univariate degree remains high.

    Parameters
    ----------
    deltas : list[int]
        List of delta values (cyclic distances between Frobenius endpoints).
    e : int
        Extension degree.
    t : int
        Number of blocks in the residual (3, 4, or 5).

    Returns
    -------
    int
        The w_t score.
    """
    min_w = float('inf')
    for I in itertools.combinations(range(len(deltas)), t):
        for u in UNITS:
            current_sum = 0
            for k in I:
                ud = (u * deltas[k]) % e
                current_sum += min(ud, (e - ud) % e)
            if current_sum < min_w:
                min_w = current_sum
    return min_w


def compute_w3_for_triplet(deltas, e):
    """
    Compute the w3 score for a single triplet of deltas.

    This is a special case of compute_window_diagnostic_fast with t=3
    and len(deltas)=3, optimized for speed (no subset enumeration).

    Parameters
    ----------
    deltas : list[int]
        Exactly 3 delta values.
    e : int
        Extension degree.

    Returns
    -------
    int
        The w3 score.
    """
    min_w = float('inf')
    for u in UNITS:
        current_sum = sum(
            min((u * d) % e, (e - (u * d) % e)) for d in deltas
        )
        if current_sum < min_w:
            min_w = current_sum
    return min_w


# =====================================================================
# Stage 1a: Precompute w3 scores for all triplets
# =====================================================================

def compute_w3_for_all_triplets(e):
    """
    Precompute w3 scores for all distinct triplets of deltas in Z/eZ.

    For each canonical triplet (a, b, c) with 1 <= a < b < c < e/2,
    compute its w3 score and cache it.  Also cache all Frobenius-rotated
    versions (multiplication by units) to avoid redundant computation.

    Parameters
    ----------
    e : int
        Extension degree.

    Returns
    -------
    dict[tuple[int, int, int], int]
        Mapping from sorted delta triplets to w3 scores.
    """
    cache = {}
    for a, b, c in itertools.combinations(range(1, e // 2), 3):
        deltas = [a, b, c]
        canonical_key = tuple(sorted(deltas))
        if canonical_key not in cache:
            w3_value = compute_w3_for_triplet(deltas, e)
            cache[canonical_key] = w3_value
            # Cache all unit-rotated versions
            for u in UNITS:
                rotated = tuple(sorted(
                    min((u * d) % e, e - (u * d) % e) for d in deltas
                ))
                if rotated not in cache:
                    cache[rotated] = w3_value
    return cache


# =====================================================================
# Stage 1b: Find quintuplets where all triplets exceed a threshold
# =====================================================================

def find_best_quintuplets(cache, e):
    """
    Search for quintuplets (d1, ..., d5) such that every triplet of deltas
    has a w3 score >= threshold.  The threshold is lowered from the maximum
    observed w3 score until at least one valid quintuplet is found.

    A quintuplet is valid if all C(5,3) = 10 triplets it contains are in
    the "good" set (w3 >= threshold).  The search is accelerated by:
      - Iterating over target triplets at the current threshold
      - Extending each triplet to a quintuplet by finding pairs (i, j)
        such that all 7 remaining triplets are also good
      - Deduplicating via Frobenius rotation (unit multiplication)

    Parameters
    ----------
    cache : dict
        Precomputed w3 scores for all triplets.
    e : int
        Extension degree.

    Returns
    -------
    list[dict]
        List of valid quintuplets with their (w3, w4, w5) scores,
        sorted by descending window scores.
    """
    results = []
    seen_keys = set()

    for threshold in reversed(range(1, max(cache.values()) + 1)):
        if results:
            break  # Stop at the first threshold that yields valid quintuplets

        target_triplets = {k for k, v in cache.items() if v == threshold}
        good_triplets = {k for k, v in cache.items() if v >= threshold}

        print(f"[INFO] Threshold {threshold}: {len(target_triplets)} target triplets, "
              f"{len(good_triplets)} good triplets")

        for key in target_triplets:
            # Find candidate 4th and 5th deltas that extend the triplet
            valid_candidates = []
            for x in range(1, e):
                if x in key:
                    continue
                # Check that all 3 triplets formed with x are good
                if tuple(sorted([key[0], key[1], x])) not in good_triplets:
                    continue
                if tuple(sorted([key[0], key[2], x])) not in good_triplets:
                    continue
                if tuple(sorted([key[1], key[2], x])) not in good_triplets:
                    continue
                valid_candidates.append(x)

            if len(valid_candidates) < 2:
                continue

            # Try all pairs (i, j) from valid candidates
            for i, j in itertools.combinations(valid_candidates, 2):
                # Check the 4 remaining triplets involving both i and j
                if tuple(sorted([key[0], i, j])) not in good_triplets:
                    continue
                if tuple(sorted([key[1], i, j])) not in good_triplets:
                    continue
                if tuple(sorted([key[2], i, j])) not in good_triplets:
                    continue

                deltas = [key[0], key[1], key[2], i, j]
                quint_key = tuple(sorted(deltas))

                if quint_key in seen_keys:
                    continue

                # Compute full window diagnostic (w3, w4, w5)
                w_scores = [
                    compute_window_diagnostic_fast(deltas, e, t)
                    for t in range(3, 6)
                ]

                results.append({
                    "quintuplet": list(quint_key),
                    "wt_scores": w_scores,
                })
                seen_keys.add(quint_key)

                # Mark all Frobenius-rotated versions as seen
                for u in UNITS:
                    rotated = tuple(sorted(
                        min((u * d) % e, e - (u * d) % e) for d in deltas
                    ))
                    seen_keys.add(rotated)

    # Sort by (w3, w4, w5) descending
    results.sort(
        key=lambda x: (x["wt_scores"][0], x["wt_scores"][1], x["wt_scores"][2]),
        reverse=True,
    )
    return results


# =====================================================================
# Main
# =====================================================================

if __name__ == "__main__":
    print(f"[INFO] Computing w3 scores for e = {UFO_E}...")

    cache = compute_w3_for_all_triplets(UFO_E)
    if not cache:
        print("[ERROR] w3 cache is empty.")
        sys.exit(1)

    print(f"[INFO] Cache loaded: {len(cache)} entries")

    # Distribution of w3 scores
    for i in range(1, UFO_E):
        count = sum(1 for v in cache.values() if v == i)
        if count > 0:
            print(f"  w3 = {i}: {count} triplets")

    print(f"\n[INFO] Searching for optimal quintuplets...")
    results = find_best_quintuplets(cache, UFO_E)

    if results:
        print(f"[INFO] Found {len(results)} valid quintuplet(s) at threshold "
              f"{results[0]['wt_scores'][0] + 1}")
        print(f"[INFO] Best quintuplet: {results[0]}")

        with open(JSON_OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(results[:1], f, indent=4)  # Save only the best
        print(f"[INFO] Saved to {JSON_OUTPUT_FILE}")
    else:
        print("[WARNING] No valid quintuplets found.")
