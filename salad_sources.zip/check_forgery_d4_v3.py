"""
Check d=4 syzygies: compare sparse vs dense random equations.
Use efficient sparse Gaussian elimination.
"""
import numpy as np
import random
from itertools import combinations_with_replacement
from math import comb
import time

def gaussian_rank_mod_p(M, p):
    """Dense Gaussian elimination mod p. Works for moderate sizes."""
    M = M.copy() % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = None
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot is None:
            continue
        M[[rank, pivot]] = M[[pivot, rank]]
        inv = pow(int(M[rank, col] % p), p - 2, p)
        M[rank] = (M[rank] * inv) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
        if rank >= rows:
            break
    return rank

e = 5
p = 31
d = 4
n = 5 * e  # 25

n_rows = e * comb(n + d - 2, d - 2)  # 1755
n_cols = comb(n + d, d)              # 23751

print(f"e={e}, p={p}, n={n}, d={d}")
print(f"Macaulay: {n_rows} rows x {n_cols} cols")
print()

# Build monomial index
monomials = []
for deg in range(d + 1):
    for combo in combinations_with_replacement(range(n), deg):
        monomials.append(combo)
monomial_index = {m: i for i, m in enumerate(monomials)}

# Use numpy array but only build rows we need (1755 rows, 23751 cols)
# This is 1755 * 23751 * 8 bytes = ~333 MB - manageable

for density_name, n_terms in [("Sparse (25 terms/eq)", 25), ("Dense (300 terms/eq)", 300)]:
    for seed in range(3):
        rng = random.Random(seed * 1000 + 42)
        
        # Generate equations
        equations = []
        for k in range(e):
            eq = {}
            terms = set()
            while len(terms) < n_terms:
                j = rng.randint(0, n - 1)
                l = rng.randint(0, n - 1)
                terms.add(tuple(sorted([j, l])))
            for mono in terms:
                eq[mono] = rng.randint(1, p - 1)
            equations.append(eq)
        
        # Build Macaulay matrix (dense numpy)
        M = np.zeros((n_rows, n_cols), dtype=np.int64)
        row_idx = 0
        for eq in equations:
            for extra in combinations_with_replacement(range(n), d - 2):
                for mono, coeff in eq.items():
                    full_mono = tuple(sorted(list(mono) + list(extra)))
                    col_idx = monomial_index.get(full_mono)
                    if col_idx is not None:
                        M[row_idx, col_idx] = (M[row_idx, col_idx] + coeff) % p
                row_idx += 1
        
        t0 = time.time()
        rank = gaussian_rank_mod_p(M, p)
        t1 = time.time()
        deficiency = min(n_rows, n_cols) - rank
        print(f"  {density_name} seed {seed}: rank={rank}/{min(n_rows,n_cols)}, def={deficiency} ({t1-t0:.1f}s)")
    print()

