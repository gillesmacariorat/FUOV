"""
Compute degree-1 syzygy rank for real UFOs Level I: p=31, e=61.

The constraint matrix C has:
- Rows: C(e+2, 3) = 39711 cubic monomials
- Columns: e^2 = 3721 pairs (i, j)
- Each row has at most 3*e = 183 nonzeros (very sparse)

We compute rank(C) using block processing:
1. Build C in blocks of 1000 rows as dense 1000 x 3721 matrices
2. Reduce each block against the pivot matrix (rank x 3721)
3. Find new pivots in the reduced block
4. The rank of C = total number of pivots

If rank(C) = e^2 = 3721: no syzygy, D_lin@3 not found
If rank(C) < e^2: syzygy exists, D_lin@3 may be found
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def compute_frobenius_vectors(GF, p, e, a):
    """Compute phi_a(alpha^j) for j=0..e-1 as field elements."""
    frob_exp = pow(p, a, p**e - 1)
    prim = GF.primitive_element
    alpha_frob = prim ** frob_exp
    vectors = []
    current = GF(1)
    for j in range(e):
        vectors.append(current)
        current = current * alpha_frob
    return vectors

def build_Q_from_frobenius(GF, p, e, terms):
    """Build Q tensor using Frobenius vectors (efficient for large e)."""
    # Precompute Frobenius vectors for each term
    frob_a_vecs = []
    frob_b_vecs = []
    for a, b, c_int in terms:
        fa = compute_frobenius_vectors(GF, p, e, a)
        fb = compute_frobenius_vectors(GF, p, e, b)
        frob_a_vecs.append(fa)
        frob_b_vecs.append(fb)
    
    # Compute u_{kl} = vector(sum_r c_r * phi_{a_r}(alpha^k) * phi_{b_r}(alpha^l))
    # These are the columns of Q viewed as Q[:, k, l]
    n_pairs = e * (e + 1) // 2
    U = np.zeros((e, n_pairs), dtype=np.int64)
    
    idx = 0
    for k in range(e):
        for l in range(k, e):
            field_elem = GF(0)
            for r, (a, b, c_int) in enumerate(terms):
                product = frob_a_vecs[r][k] * frob_b_vecs[r][l]
                field_elem = field_elem + GF(c_int) * product
            vec = np.array(field_elem.vector(), dtype=np.int64)
            U[:, idx] = vec[::-1]  # galois returns reversed
            idx += 1
    
    # Build Q[i, k, l] = U[i, idx(k, l)]
    Q = np.zeros((e, e, e), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            Q[:, k, l] = U[:, idx]
            Q[:, l, k] = U[:, idx]  # symmetric
            idx += 1
    
    return Q

def build_constraint_row(a, b, c, Q, e, p, inv2):
    """Build one row of the constraint matrix C for cubic monomial (a, b, c).
    
    Returns a vector of length e^2 (indexed by (i, j) = i*e + j).
    """
    row = np.zeros(e * e, dtype=np.int64)
    
    if a == b == c:
        # Monomial x_a^3
        # Coefficient of x_a^3 in x_j * F_i^{(2)} = Q[i,a,a] if j=a, else 0
        for i in range(e):
            row[i * e + a] = int(Q[i, a, a])
    elif a == b < c:
        # Monomial x_a^2 * x_c
        # j=a: 2*Q[i,a,c], j=c: Q[i,a,a]
        for i in range(e):
            row[i * e + a] = (2 * int(Q[i, a, c])) % p
            row[i * e + c] = int(Q[i, a, a])
    elif a < b == c:
        # Monomial x_a * x_b^2
        # j=b: 2*Q[i,a,b], j=a: Q[i,b,b]
        for i in range(e):
            row[i * e + b] = (2 * int(Q[i, a, b])) % p
            row[i * e + a] = int(Q[i, b, b])
    else:
        # a < b < c: all distinct
        # j=a: 2*Q[i,b,c], j=b: 2*Q[i,a,c], j=c: 2*Q[i,a,b]
        for i in range(e):
            row[i * e + a] = (2 * int(Q[i, b, c])) % p
            row[i * e + b] = (2 * int(Q[i, a, c])) % p
            row[i * e + c] = (2 * int(Q[i, a, b])) % p
    
    return row

def gauss_elim_block(block, p, pivot_matrix):
    """Gaussian elimination on a block, reducing against existing pivots.
    
    block: (n_rows, n_cols) matrix mod p
    pivot_matrix: (rank, n_cols) matrix of pivot rows
    Returns: updated pivot_matrix (with new pivots added), new rank
    """
    n_rows, n_cols = block.shape
    block = block.copy() % p
    
    # Reduce block against existing pivots
    if pivot_matrix.shape[0] > 0:
        # block -= (block @ pivot_matrix^T) @ pivot_matrix (mod p)
        coeffs = (block @ pivot_matrix.T) % p  # n_rows x rank
        block = (block - coeffs @ pivot_matrix) % p
    
    # Find new pivots in the reduced block
    new_pivots = []
    for r in range(n_rows):
        row = block[r] % p
        # Reduce against new pivots
        for pv in new_pivots:
            if row[pv[1]] != 0:
                factor = row[pv[1]]
                row = (row - factor * pv[0]) % p
        # Find first nonzero
        nz = np.where(row != 0)[0]
        if len(nz) > 0:
            col = nz[0]
            inv_val = pow(int(row[col]), p-2, p)
            row = (row * inv_val) % p
            new_pivots.append((row.copy(), col))
    
    if new_pivots:
        new_rows = np.array([pv[0] for pv in new_pivots])
        pivot_matrix = np.vstack([pivot_matrix, new_rows])
    
    return pivot_matrix, len(new_pivots)

def compute_C_rank(Q, e, p, block_size=1000):
    """Compute rank of constraint matrix C using block processing."""
    inv2 = pow(2, p-2, p)
    n_cols = e * e  # 3721 for e=61
    
    # Generate cubic monomials (a <= b <= c)
    cubic_mons = []
    for combo in combinations_with_replacement(range(e), 3):
        cubic_mons.append(combo)
    n_rows = len(cubic_mons)
    
    print(f"Constraint matrix C: {n_rows} rows x {n_cols} cols")
    print(f"Block size: {block_size}")
    
    pivot_matrix = np.zeros((0, n_cols), dtype=np.int64)
    total_rank = 0
    
    n_blocks = (n_rows + block_size - 1) // block_size
    
    for block_idx in range(n_blocks):
        start = block_idx * block_size
        end = min(start + block_size, n_rows)
        actual_size = end - start
        
        # Build block
        block = np.zeros((actual_size, n_cols), dtype=np.int64)
        for i, (a, b, c) in enumerate(cubic_mons[start:end]):
            block[i] = build_constraint_row(a, b, c, Q, e, p, inv2)
        
        # Reduce and find pivots
        pivot_matrix, n_new = gauss_elim_block(block, p, pivot_matrix)
        total_rank = pivot_matrix.shape[0]
        
        elapsed = time.time() - t_start
        print(f"  Block {block_idx+1}/{n_blocks}: rows {start}-{end}, "
              f"new pivots: {n_new}, total rank: {total_rank}/{n_cols}, "
              f"time: {elapsed:.1f}s")
        
        # Early termination: if rank = n_cols, matrix has full column rank
        if total_rank == n_cols:
            print(f"  Full column rank reached! No syzygy.")
            break
    
    return total_rank, n_cols

# === Test on e=7 first (validation) ===
print("="*80)
print("VALIDATION: e=7, p=31, consecutive schedule")
print("="*80)

p, e = 31, 7
GF = galois.GF(p**e)
schedule = [(0,1),(1,2),(2,3),(3,4),(4,5)]
cancel = (0, 1)
residual = [schedule[k] for k in range(5) if k not in cancel]

rng = random.Random(42)
x0_int = rng.randint(1, p**e - 1)
x0 = GF(x0_int)
rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
terms = []
for a, b in residual:
    c_int = int(GF(rng_c.randint(1, p**e - 1)))
    terms.append((a, b, c_int))

h_val = GF(0)
for a, b, c_int in terms:
    h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)

t_start = time.time()
Q = build_Q_from_frobenius(GF, p, e, terms)
print(f"Q built in {time.time() - t_start:.1f}s")

rank, n_cols = compute_C_rank(Q, e, p)
print(f"\nC rank: {rank}/{n_cols}")
print(f"Syzygy dimension: {n_cols - rank}")
print(f"D_lin@3: {'YES' if rank < n_cols else 'no'}")

# === Real UFOs Level I: p=31, e=61 ===
print("\n" + "="*80)
print("REAL UFOs Level I: p=31, e=61")
print("="*80)

p, e = 31, 61
ufos_schedule = [(0,9),(7,54),(13,29),(15,37),(35,47)]
GF = galois.GF(p**e)

# Test all 10 triplets
pairs = list(combinations(range(5), 2))
all_results = []

for cancel in pairs:
    residual = [ufos_schedule[k] for k in range(5) if k not in cancel]
    
    rng = random.Random(42)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
    terms = []
    for a, b in residual:
        c_int = int(GF(rng_c.randint(1, p**e - 1)))
        terms.append((a, b, c_int))
    
    h_val = GF(0)
    for a, b, c_int in terms:
        h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
    
    t_start = time.time()
    Q = build_Q_from_frobenius(GF, p, e, terms)
    t_q = time.time() - t_start
    
    rank, n_cols = compute_C_rank(Q, e, p, block_size=500)
    t_total = time.time() - t_start
    
    syz_dim = n_cols - rank
    dlin = rank < n_cols
    
    print(f"  Cancel {cancel}: C rank={rank}/{n_cols}, syzygy dim={syz_dim}, "
          f"D_lin@3={'YES' if dlin else 'no'}, time={t_total:.1f}s")
    all_results.append((cancel, rank, syz_dim, dlin))
    
    if t_total > 300:
        print("  WARNING: taking too long, reducing block size")

print(f"\n{'='*80}")
print("SUMMARY: UFOs Level I (p=31, e=61)")
print(f"{'='*80}")
dlin_count = sum(1 for r in all_results if r[3])
for cancel, rank, syz, dlin in all_results:
    print(f"  Cancel {cancel}: rank={rank}/{n_cols}, syz={syz}, D_lin@3={'YES' if dlin else 'no'}")
print(f"\nD_lin@3 found for {dlin_count}/10 triplets")
