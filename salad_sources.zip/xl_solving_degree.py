"""
XL Solving Degree Measurement for Frobenius-Sum Forgery Equation
================================================================

Measures D_lin (linear fall degree) and D_uni (univariate eliminant degree)
for the Weil descent of the 3-term residual forgery equation:

    sum_{k not cancelled} c_k * x^(p^{a_k} + p^{b_k}) = h

over F_{p^e}, descended to e quadratic equations in e variables over F_p.

Key implementation notes:
- galois .vector() returns [alpha^{e-1}, ..., alpha^0] (reversed order)
- Q matrix uses standard indices (alpha^j); x_std = x_vec[::-1]
- Quadratic forms built by evaluation: F(e_j), F(e_i+e_j)
- Cross terms divided by 2 mod p (inv2 = pow(2, p-2, p))
- No field equations x_i^p - x_i (would contaminate D=3 for small p)
- h = F(x0) for known solution x0 (measures forge degree)

Results:
  D_lin = 3 for ALL triplets, independent of e (tested e=5, 7)
  D_uni = 3 for 44-80% of (triplet, seed) pairs
  Generic systems: D_lin not found even at d=10
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def eval_frobenius_sum(GF, p, e, terms, x_int):
    """Evaluate F(x) = sum_r c_r * x^(p^{a_r} + p^{b_r}) in F_{p^e}."""
    x = GF(x_int)
    result = GF(0)
    for a, b, c_int in terms:
        result = result + GF(c_int) * x ** (p**a + p**b)
    return result

def build_quad_frobenius(GF, p, e, terms, h_int):
    """Build quadratic system Q, const by evaluation.
    
    NOTE: galois .vector() returns [alpha^{e-1}, ..., alpha^0] (reversed).
    Q is indexed by standard polynomial basis indices (alpha^j).
    """
    basis = []
    for j in range(e):
        v = np.zeros(e, dtype=np.int64)
        v[j] = 1
        val = sum(int(v[i]) * (p**i) for i in range(e))
        basis.append(GF(val))
    
    F_ej = [np.array(eval_frobenius_sum(GF, p, e, terms, int(basis[j])).vector(), dtype=np.int64)
            for j in range(e)]
    F_ei_ej = {}
    for i in range(e):
        for j in range(i+1, e):
            F_ei_ej[(i,j)] = np.array(
                eval_frobenius_sum(GF, p, e, terms, int(basis[i] + basis[j])).vector(),
                dtype=np.int64)
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    const = np.zeros(e, dtype=np.int64)
    h_vec = np.array(GF(h_int).vector(), dtype=np.int64)
    inv2 = pow(2, p-2, p)
    
    for eq in range(e):
        const[eq] = (-h_vec[eq]) % p
        for j in range(e):
            Q[eq, j, j] = int(F_ej[j][eq])
        for i in range(e):
            for j in range(i+1, e):
                cross = (int(F_ei_ej[(i,j)][eq]) - int(F_ej[i][eq]) - int(F_ej[j][eq])) % p
                cross = (cross * inv2) % p
                Q[eq, i, j] = cross
                Q[eq, j, i] = cross
    
    return Q, const

def validate_system(GF, p, e, terms, h_int, Q, const, n_tests=10):
    """Validate quadratic form matches F(x) - h on random points."""
    rng = random.Random(123)
    h = GF(h_int)
    for _ in range(n_tests):
        x_int = rng.randint(0, p**e - 1)
        F_val = eval_frobenius_sum(GF, p, e, terms, x_int)
        F_minus_h = F_val - h
        F_vec = np.array(F_minus_h.vector(), dtype=np.int64)
        
        x = GF(x_int)
        x_std = np.array(x.vector(), dtype=np.int64)[::-1]  # Reverse galois order
        
        for eq in range(e):
            q_val = int(const[eq])
            for j in range(e):
                for k in range(e):
                    q_val += int(Q[eq, j, k]) * int(x_std[j]) * int(x_std[k])
            q_val %= p
            if q_val != int(F_vec[eq]):
                return False, f"Mismatch eq={eq} x={x_int}"
    return True, "OK"

def gen_monomials(e, max_deg):
    """Generate all monomials of degree <= max_deg, high degree first."""
    mons = []
    for deg in range(max_deg, -1, -1):
        for combo in combinations_with_replacement(range(e), deg):
            mons.append(combo)
    return mons

def build_macaulay(Q, const, e, d, p):
    """Build Macaulay matrix at degree d."""
    col_mons = gen_monomials(e, d)
    n_cols = len(col_mons)
    col_idx = {m: i for i, m in enumerate(col_mons)}
    
    if d < 2:
        return np.zeros((0, n_cols), dtype=np.int64), col_mons, n_cols
    
    mult_mons = []
    for deg in range(d - 1):
        for combo in combinations_with_replacement(range(e), deg):
            mult_mons.append(combo)
    
    n_rows = e * len(mult_mons)
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    
    row = 0
    for eq_idx in range(e):
        Q_eq = Q[eq_idx]
        for mult in mult_mons:
            for j in range(e):
                for k in range(e):
                    coeff = int(Q_eq[j, k])
                    if coeff != 0:
                        prod = tuple(sorted(mult + (j, k)))
                        if prod in col_idx:
                            M[row, col_idx[prod]] = (M[row, col_idx[prod]] + coeff) % p
            c = int(const[eq_idx])
            if c != 0 and mult in col_idx:
                M[row, col_idx[mult]] = (M[row, col_idx[mult]] + c) % p
            row += 1
    
    return M, col_mons, n_cols

def gauss_elim_mod_p(M, p):
    """Exact Gaussian elimination mod p."""
    M = M.copy() % p
    n_rows, n_cols = M.shape
    pivot_row = 0
    
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        col_data = M[pivot_row:, col] % p
        nonzero = np.where(col_data != 0)[0]
        if len(nonzero) == 0:
            continue
        idx = nonzero[0] + pivot_row
        M[[pivot_row, idx]] = M[[idx, pivot_row]]
        inv = pow(int(M[pivot_row, col]), p-2, p)
        M[pivot_row] = (M[pivot_row] * inv) % p
        for r in range(n_rows):
            if r != pivot_row and M[r, col] % p != 0:
                M[r] = (M[r] - int(M[r, col]) * M[pivot_row]) % p
        pivot_row += 1
    
    return M[:pivot_row]

def detect_solving(reduced, col_mons, e, d, p):
    """Detect D_lin and D_uni from reduced matrix."""
    const_idx = None
    linear_allowed = set()
    univar_allowed = {}
    
    for i, m in enumerate(col_mons):
        if len(m) == 0:
            const_idx = i
        elif len(m) == 1:
            linear_allowed.add(i)
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
        elif len(set(m)) == 1:
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
    
    if const_idx is not None:
        linear_allowed.add(const_idx)
        for var in univar_allowed:
            univar_allowed[var].add(const_idx)
    
    n_lin = n_uni = n_inc = 0
    
    for r in range(reduced.shape[0]):
        row = reduced[r] % p
        nz = set(np.where(row != 0)[0])
        if const_idx is not None and nz == {const_idx}:
            n_inc += 1
            continue
        if nz.issubset(linear_allowed):
            n_lin += 1
        for var in range(e):
            if var in univar_allowed and nz.issubset(univar_allowed[var]):
                n_uni += 1
                break
    
    return n_lin > 0, n_uni > 0, n_lin, n_uni, n_inc

def run_xl(Q, const, e, p, max_d=7):
    """Run XL and return D_lin, D_uni, inconsistency flag."""
    d_lin = d_uni = None
    inconsistent = False
    
    for d in range(2, max_d + 1):
        M, col_mons, n_cols = build_macaulay(Q, const, e, d, p)
        if M.shape[0] == 0:
            continue
        
        reduced = gauss_elim_mod_p(M, p)
        found_lin, found_uni, _, _, n_inc = detect_solving(reduced, col_mons, e, d, p)
        
        if n_inc > 0:
            inconsistent = True
        if found_lin and d_lin is None:
            d_lin = d
        if found_uni and d_uni is None:
            d_uni = d
        if d_lin is not None and d_uni is not None:
            break
        if n_cols > 1500:
            break
    
    return d_lin, d_uni, inconsistent

def extract_relation(Q, const, e, p, d=3, relation_type='lin'):
    """Extract a D_lin or D_uni relation from the Macaulay matrix at degree d."""
    M, col_mons, n_cols = build_macaulay(Q, const, e, d, p)
    reduced = gauss_elim_mod_p(M, p)
    
    const_idx = None
    linear_allowed = set()
    univar_allowed = {}
    
    for i, m in enumerate(col_mons):
        if len(m) == 0:
            const_idx = i
        elif len(m) == 1:
            linear_allowed.add(i)
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
        elif len(set(m)) == 1:
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
    
    if const_idx is not None:
        linear_allowed.add(const_idx)
        for var in univar_allowed:
            univar_allowed[var].add(const_idx)
    
    for r in range(reduced.shape[0]):
        row = reduced[r] % p
        nz = set(np.where(row != 0)[0])
        
        if relation_type == 'lin' and nz.issubset(linear_allowed):
            coeffs = {}
            for idx in sorted(nz):
                m = col_mons[idx]
                if len(m) == 0:
                    coeffs['1'] = int(row[idx])
                else:
                    coeffs[f'x_{m[0]}'] = int(row[idx])
            return coeffs
        elif relation_type == 'uni':
            for var in range(e):
                if var in univar_allowed and nz.issubset(univar_allowed[var]):
                    coeffs = {}
                    for idx in sorted(nz):
                        m = col_mons[idx]
                        if len(m) == 0:
                            coeffs['1'] = int(row[idx])
                        else:
                            deg = len(m)
                            coeffs[f'x_{var}^{deg}'] = int(row[idx])
                    return coeffs, var
    
    return None


if __name__ == "__main__":
    # Quick demonstration
    p, e = 3, 5
    GF = galois.GF(p**e)
    schedule = [(0,1),(1,2),(2,3),(3,4),(4,0)]
    
    print(f"XL Solving Degree Measurement: p={p}, e={e}")
    print(f"Schedule: {schedule}")
    print()
    
    pairs = list(combinations(range(5), 2))
    
    for cancel in pairs[:3]:  # Show first 3
        residual = [schedule[k] for k in range(5) if k not in cancel]
        rng = random.Random(42)
        x0_int = rng.randint(1, p**e - 1)
        x0 = GF(x0_int)
        
        rng_c = random.Random(hash(cancel) % 2**32)
        terms = []
        for a, b in residual:
            c_int = int(GF(rng_c.randint(1, p**e - 1)))
            terms.append((a, b, c_int))
        
        h_val = GF(0)
        for a, b, c_int in terms:
            h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
        
        Q, const = build_quad_frobenius(GF, p, e, terms, int(h_val))
        valid, msg = validate_system(GF, p, e, terms, int(h_val), Q, const)
        d_lin, d_uni, inc = run_xl(Q, const, e, p, max_d=7)
        
        print(f"Cancel {cancel}: residual={residual}")
        print(f"  Validation: {msg}")
        print(f"  D_lin={d_lin}, D_uni={d_uni}, inconsistent={inc}")
        
        if d_lin is not None:
            rel = extract_relation(Q, const, e, p, d=d_lin, relation_type='lin')
            if rel:
                print(f"  D_lin relation: {rel}")
                # Verify at x0
                x0_std = np.array(GF(x0_int).vector(), dtype=np.int64)[::-1]
                val = 0
                for k, v in rel.items():
                    if k == '1':
                        val += v
                    else:
                        var = int(k.split('_')[1])
                        val += v * int(x0_std[var])
                print(f"  Relation value at x0: {val % p} (should be 0)")
        print()
