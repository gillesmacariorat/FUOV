#!/usr/bin/env python3
"""
post_process_2.py — Stage 3: Full diagnostic certification of hardened schedules.

Given the best schedules from Stage 2 (deltas_points_2.py), this script
computes the complete set of security diagnostics:

  - **Linear span L**: worst-case univariate span over all 10 cancellation pairs.
  - **Bivariate score R_eff**: effective resultant degree R - 1 + E, minimized
    over all orientation pairs and Frobenius shifts.
  - **Window scores w3, w4, w5**: multi-block window diagnostics measuring
    the spread of residual endpoints for 3, 4, and 5-block residuals.
  - **Bézout bounds B3, B4**: geometric degree bounds from the Bézout
    theorem applied to 3-block and 4-block resultants.  These give lower
    bounds on the degree of the elimination polynomial, hence on the
    attack cost.

Schedules that pass all threshold filters are certified and saved.

Usage:
    python post_process_2.py

Input:  best_quintuplets_{e}_{p}.json  (from Stage 2 + initial filtering)
Output: best_quintuplets_L_{e}_{p}.json
"""

import json
import itertools
import math
import os
import sys

# =====================================================================
# Configuration — select UFOs security level
# =====================================================================

# level = 0 -> Level I  (p=31,  e=61)
# level = 1 -> Level III (p=61,  e=89)
# level = 2 -> Level V  (p=61, e=127)
level = 2

TAB_E = [61, 89, 127]
TAB_P = [31, 61, 61]
UFO_E = TAB_E[level]
UFO_P = TAB_P[level]

JSON_INPUT_FILE = f"best_quintuplets_{UFO_E}_{UFO_P}.json"
JSON_OUTPUT_FILE = f"best_quintuplets_L_{UFO_E}_{UFO_P}.json"

# =====================================================================
# Mathematical utilities
# =====================================================================

# All 8 orientation assignments for a 3-block residual
_ALL_ORIENTATIONS = list(itertools.product((0, 1), repeat=3))
VALID_ORIENTATION_PAIRS = [
    (eps, eps_prime)
    for eps in _ALL_ORIENTATIONS
    for eps_prime in _ALL_ORIENTATIONS
    if eps != eps_prime
]

# Units of Z/eZ
UNITS = [u for u in range(1, UFO_E) if math.gcd(u, UFO_E) == 1]


# =====================================================================
# Schedule normalization
# =====================================================================

def normalize_schedule(schedule, e):
    """
    Normalize a 5-block schedule to Bariant canonical form.

    Each block (a, b) is reduced so that delta = (b - a) mod e is in [0, e/2].
    Blocks are sorted by delta, and the origin is shifted to the first block.
    """
    normalized = []
    for a, b in schedule:
        a_mod, b_mod = a % e, b % e
        delta = (b_mod - a_mod) % e
        if delta > (e - 1) // 2:
            normalized.append((b_mod, a_mod, e - delta))
        else:
            normalized.append((a_mod, b_mod, delta))

    normalized.sort(key=lambda x: x[2])
    shift = normalized[0][0]
    return [(a - shift) % e, (b - shift) % e for a, b, _ in normalized]


# =====================================================================
# Diagnostic 1: Linear span L
# =====================================================================

def compute_univariate_span(triplet_blocks, e):
    """
    Compute the linear span L for a 3-block residual.

    L = e - max_gap, where max_gap is the largest cyclic gap between
    the 6 sorted Frobenius endpoints on Z/eZ.
    """
    sorted_idx = sorted(set(
        idx for a, b in triplet_blocks for idx in [a, b]
    ))
    n = len(sorted_idx)
    if n <= 1:
        return 0
    max_gap = 0
    for i in range(n):
        gap = (sorted_idx[(i + 1) % n] - sorted_idx[i]) % e
        if gap > max_gap:
            max_gap = gap
    return e - max_gap


# =====================================================================
# Diagnostic 2: Window scores w_t
# =====================================================================

def compute_w3_for_triplet(triplet_blocks, e):
    """Compute the w3 window score for a 3-block residual."""
    deltas = [(b - a) % e for a, b in triplet_blocks]
    min_w = float('inf')
    for u in UNITS:
        current_sum = sum(
            min((u * d) % e, (e - (u * d) % e)) for d in deltas
        )
        if current_sum < min_w:
            min_w = current_sum
    return min_w


def compute_window_diagnostic_fast(schedule, e, t):
    """
    Compute the w_t window score for a t-block residual from a 5-block schedule.

    For each subset of t blocks and each Frobenius shift u, compute the sum
    of circular distances of the t deltas.  The w_t score is the minimum
    over all subsets and shifts.
    """
    deltas = [(b - a) % e for a, b in schedule]
    min_w = float('inf')
    for I in itertools.combinations(range(5), t):
        for u in UNITS:
            current_sum = 0
            for k in I:
                ud = (u * deltas[k]) % e
                current_sum += min(ud, (e - ud) % e)
            if current_sum < min_w:
                min_w = current_sum
    return min_w


def compute_n_layers_consecutive(schedule, e):
    """
    Compute the N-layer diagnostic: the minimum total window width for
    all 5 blocks under the best Frobenius shift.
    """
    deltas = [(b - a) % e for a, b in schedule]
    units = [u for u in range(1, e) if math.gcd(u, e) == 1]
    best_kappa, min_w5 = None, float('inf')
    for u in units:
        current_sum = sum(
            min((u * d) % e, (e - (u * d) % e)) for d in deltas
        )
        if current_sum < min_w5:
            min_w5 = current_sum
            best_kappa = u
    return sum(
        min((best_kappa * d) % e, (e - (best_kappa * d) % e)) for d in deltas
    )


# =====================================================================
# Diagnostic 3: Bivariate resultant degree R_eff
# =====================================================================

def evaluate_single_triplet_bivariate(triplet_blocks, e):
    """
    Compute the effective bivariate resultant degree R_eff = R - 1 + E
    for a single 3-block residual.

    Enumerates all Frobenius shifts sigma, all orientation pairs
    (eps, eps'), and all anchor points (r, s) to find the minimum
    attack cost.

    The resultant degree R and the scaling symmetry saving E are:

        R = max(dx1 + dy2, dx2 + dy1)
        E = min(max(dx1, dx2), max(dy1, dy2))
        attack_cost = R - 1 + E

    where dx_i, dy_i are the degrees of the two bivariate equations
    after assignment to Frobenius coordinates X, Y.
    """
    min_cost = float('inf')
    for sigma in range(1, e):
        for eps, eps_prime in VALID_ORIENTATION_PAIRS:
            u1, v1, u2, v2 = [], [], [], []
            for idx, (ak, bk) in enumerate(triplet_blocks):
                if eps[idx] == 0:
                    u1.append(ak % e)
                    v1.append(bk % e)
                else:
                    u1.append(bk % e)
                    v1.append(ak % e)

                if eps_prime[idx] == 0:
                    u2.append((ak + sigma) % e)
                    v2.append((bk + sigma) % e)
                else:
                    u2.append((bk + sigma) % e)
                    v2.append((ak + sigma) % e)

            admissible_r = set(u1 + u2)
            admissible_s = set(v1 + v2)

            for r in admissible_r:
                dx1 = max((u - r) % e for u in u1)
                dx2 = max((u - r) % e for u in u2)
                max_dx = max(dx1, dx2)

                for s in admissible_s:
                    dy1 = max((v - s) % e for v in v1)
                    dy2 = max((v - s) % e for v in v2)

                    R = max(dx1 + dy2, dx2 + dy1)
                    E = min(max_dx, max(dy1, dy2))
                    attack_cost = R - 1 + E

                    if attack_cost < min_cost:
                        min_cost = attack_cost
    return min_cost


def evaluate_quintuplet_bivariate(schedule, e):
    """
    Compute the worst-case (minimum) bivariate score over all 10
    cancellation pairs of a 5-block schedule.
    """
    min_cost = float('inf')
    for cancelled in itertools.combinations(range(5), 2):
        residual = [schedule[k] for k in range(5) if k not in cancelled]
        score = evaluate_single_triplet_bivariate(residual, e)
        if score < min_cost:
            min_cost = score
    return min_cost


# =====================================================================
# Diagnostic 4: Bézout bounds B_t
# =====================================================================

def multiply_homogenous_polys(poly_coeffs, u, v, p):
    """
    Multiply a homogeneous polynomial by (x^{p^u} - x^{p^v}).

    Used in the Bézout bound computation: each block contributes a
    factor (X^{p^{r_dir}} - X^{p^{r_trans}}) to the resultant, and
    the degree of the product gives the Bézout bound.
    """
    deg = len(poly_coeffs) - 1
    new_poly = [0] * (deg + 2)
    s_factor, t_factor = p ** u, p ** v
    for i in range(len(poly_coeffs)):
        new_poly[i + 1] += poly_coeffs[i] * s_factor
        new_poly[i] += poly_coeffs[i] * t_factor
    return new_poly


def log2_huge_int(n):
    """Compute log2 of a potentially very large integer."""
    if n <= 0:
        return 0
    b = n.bit_length()
    if b < 53:
        return math.log2(n)
    return math.log2(n >> (b - 53)) + (b - 53)


def compute_bezout_bounds_no_sympy(schedule, e, p, t_blocks):
    """
    Compute the Bézout bound B_t for t-block resultants.

    For each subset of t blocks from the 5-block schedule, and each
    Frobenius shift g, compute the degree of the product polynomial

        prod_{k in subset} (X^{p^{r_k}} - X^{p^{r_k'}})

    where r_k, r_k' are the direct and transposed Frobenius shifts.
    The Bézout bound is the maximum nonzero coefficient of this product,
    which gives a lower bound on the degree of the elimination polynomial.

    Parameters
    ----------
    schedule : list[(int, int)]
        The 5-block schedule.
    e : int
        Extension degree.
    p : int
        Prime field characteristic.
    t_blocks : int
        Number of blocks in the resultant (3 for B3, 4 for B4).

    Returns
    -------
    tuple(int, float)
        (dominant_exponent, log2_value) of the Bézout bound.
    """
    global_min_log2 = float('inf')
    dominant_exp = 0

    for chosen in itertools.combinations(range(5), t_blocks):
        for g in range(e):
            block_choices = []
            for k in chosen:
                ak, bk = schedule[k]
                delta = (bk - ak) % e
                r_dir = (delta - g) % e
                r_trans = (-delta - g) % e

                dir_opts = [(0, r_dir), (e - r_dir if r_dir != 0 else 0, 0)]
                trans_opts = [(0, r_trans), (e - r_trans if r_trans != 0 else 0, 0)]
                block_choices.append(list(itertools.product(dir_opts, trans_opts)))

            for global_choice in itertools.product(*block_choices):
                system_bidegrees = []
                for dir_eq, trans_eq in global_choice:
                    system_bidegrees.extend([dir_eq, trans_eq])

                current_poly = [1]
                for u_j, v_j in system_bidegrees:
                    current_poly = multiply_homogenous_polys(
                        current_poly, u_j, v_j, p
                    )

                # The dominant coefficient is in the middle of the polynomial
                # (avoiding the trivial endpoints from async factors)
                valid_coeffs = [c for c in current_poly[1:-1] if c > 0]
                if valid_coeffs:
                    coeff = max(valid_coeffs)
                    log2_val = log2_huge_int(coeff)
                    if log2_val < global_min_log2:
                        global_min_log2 = log2_val
                        dominant_exp = round(log2_val / math.log2(p))

    return dominant_exp, global_min_log2


# =====================================================================
# Main: Certification pipeline
# =====================================================================

if __name__ == "__main__":
    # Load candidate schedules
    if not os.path.exists(JSON_INPUT_FILE):
        print(f"[ERROR] {JSON_INPUT_FILE} not found.")
        sys.exit(1)

    with open(JSON_INPUT_FILE, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    print(f"[INFO] Loaded {len(raw_data)} schedule(s) for "
          f"p={UFO_P}, e={UFO_E}")

    # Select schedules with the best univariate span and bivariate score
    best_span = max(
        item["diagnostics_globaux"]["Span_univariate"] for item in raw_data
    )
    candidates = [
        item for item in raw_data
        if item["diagnostics_globaux"]["Span_univariate"] == best_span
    ]
    best_biva = max(
        item["diagnostics_globaux"]["Bivariate_score"] for item in candidates
    )
    candidates = [
        item for item in candidates
        if item["diagnostics_globaux"]["Bivariate_score"] == best_biva
    ]

    print(f"[INFO] {len(candidates)} schedule(s) with Span={best_span}, "
          f"Biv={best_biva}")

    results = []
    for count, item in enumerate(candidates, 1):
        if count % 50 == 0:
            print(f"  Processing schedule {count}...")

        schedule = item["schedule"]
        diagnostic = item["diagnostics_globaux"]

        # Compute Bézout bounds B3 and B4
        b3_exp, b3_log2 = compute_bezout_bounds_no_sympy(
            schedule, UFO_E, UFO_P, t_blocks=3
        )
        b4_exp, b4_log2 = compute_bezout_bounds_no_sympy(
            schedule, UFO_E, UFO_P, t_blocks=4
        )

        diagnostic["b3_dominant_exponent"] = b3_exp
        diagnostic["b3_log2"] = b3_log2
        diagnostic["b4_dominant_exponent"] = b4_exp
        diagnostic["b4_log2"] = b4_log2

        results.append({
            "parameters": {"p": UFO_P, "e": UFO_E},
            "schedule": normalize_schedule(schedule, UFO_E),
            "diagnostics_globaux": diagnostic,
        })

    # Sort by univariate span (descending)
    results.sort(
        key=lambda x: x["diagnostics_globaux"]["Span_univariate"],
        reverse=True,
    )

    with open(JSON_OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=4)

    print(f"\n[SUCCESS] {len(results)} certified schedule(s) saved to {JSON_OUTPUT_FILE}")
    for r in results:
        dg = r["diagnostics_globaux"]
        print(f"  Span={dg['Span_univariate']}, Biv={dg['Bivariate_score']}, "
              f"B3={dg['b3_dominant_exponent']}, B4={dg['b4_dominant_exponent']}")
