"""
Verify Koszul syzygies by explicit construction.
For each pair (i,j) of equations, construct the syzygy vector v where:
  v[row(i, m)] = coeff of m in g_j  (for each degree-2 monomial m)
  v[row(j, m)] = -coeff of m in g_i
  v[everything else] = 0
Then check v^T M = 0 (null space verification).
"""
import numpy as np, galois, time, sys
from forgery_keyrec_v3 import *
from math import comb

p, e = 3, 5
sched = [(0,1), (1,2), (2,3), (3,4), (4,0)]
GF, alpha, mu, frob_fn = setup_field(p, e)

for diagonal in [True, False]:
    dlabel = 'Diagonal' if diagonal else 'Dense'
    print(f'=== {dlabel} e={e} ===')
    
    coeffs_fq, Lambda = gen_keyrecovery_coeffs(GF, alpha, p, e, sched, diagonal, seed=42)
    Q, L, c = build_keyrecovery_system(p, e, sched, coeffs_fq, diagonal, mu, frob_fn)
    
    n, m = 4*e, 5*e  # 20 vars, 25 eqs
    d = 4
    
    # Generate monomials
    all_monos = generate_monomials(n, d)  # degree <= 4
    mono_to_idx = {m: i for i, m in enumerate(all_monos)}
    n_cols = len(all_monos)
    multipliers = generate_monomials(n, d - 2)  # degree <= 2
    mult_to_idx = {m: i for i, m in enumerate(multipliers)}
    n_mults = len(multipliers)
    n_rows = m * n_mults
    
    print(f'  Matrix: {n_rows}x{n_cols}, {n_mults} multipliers per eq')
    
    # Build sparse Macaulay matrix as list of row dicts
    from sparse_gauss import build_macaulay_sparse
    rows_data, _, _ = build_macaulay_sparse(Q, L, c, n, m, p, d)
    
    # For each equation i, extract its quadratic+linear+constant coefficients
    # g_i = sum_j L[i,j]*x_j + sum_{j<=l} Q[i,j,l]*x_j*x_l + c[i]
    # We need the coefficients of g_i as a degree-<=2 polynomial
    # g_i coefficients: for each degree-2 monomial (j,l), coeff = Q[i,j,l]
    #                    for each degree-1 monomial j, coeff = L[i,j]
    #                    for degree-0, coeff = c[i]
    
    # Extract g_i coefficients indexed by multiplier monomials
    g_coeffs = np.zeros((m, n_mults), dtype=np.int64)  # g_coeffs[i, m_idx] = coeff of multiplier monomial in g_i
    for i in range(m):
        for m_idx, m_mono in enumerate(multipliers):
            # m_mono is a degree-<=2 exponent vector
            if sum(m_mono) == 0:  # constant
                g_coeffs[i, m_idx] = int(c[i]) % p
            elif sum(m_mono) == 1:  # linear
                j = m_mono.index(1)
                g_coeffs[i, m_idx] = int(L[i, j]) % p
            elif sum(m_mono) == 2:  # quadratic
                # Find which two variables
                indices = [k for k in range(n) if m_mono[k] > 0]
                if len(indices) == 1:  # x_j^2
                    j = indices[0]
                    g_coeffs[i, m_idx] = int(Q[i, j, j]) % p
                else:  # x_j * x_l
                    j, l = indices
                    g_coeffs[i, m_idx] = int(Q[i, j, l]) % p
    
    # Construct Koszul syzygy vectors
    # For pair (i, j), the syzygy is: g_j * g_i - g_i * g_j = 0
    # In terms of Macaulay rows: sum_m g_coeffs[j, m] * row(i, m) - sum_m g_coeffs[i, m] * row(j, m) = 0
    # So the syzygy vector v has:
    #   v[row(i, m)] = g_coeffs[j, m]  for each multiplier m
    #   v[row(j, m)] = -g_coeffs[i, m]  for each multiplier m
    
    print(f'  Constructing {comb(m, 2)} Koszul syzygy vectors...')
    
    # Verify each syzygy: v^T M = 0
    # Instead of building full vectors, compute v^T M for each syzygy
    # v^T M = sum_m g_coeffs[j, m] * row(i, m) - sum_m g_coeffs[i, m] * row(j, m)
    
    # Precompute: for each equation i, the combined row = sum_m g_coeffs[j, m] * rows_data[row(i, m)]
    # This is a matrix-vector product
    
    null_count = 0
    null_vectors = []  # Store as sparse dicts
    
    t0 = time.time()
    for i in range(m):
        for j in range(i+1, m):
            # Compute v^T M = sum_m g_coeffs[j, m] * row(i, m) - sum_m g_coeffs[i, m] * row(j, m)
            result = {}  # col -> value
            
            # Add g_coeffs[j, m] * row(i, m) for each m
            for m_idx in range(n_mults):
                coeff = int(g_coeffs[j, m_idx])
                if coeff == 0:
                    continue
                row_idx = i * n_mults + m_idx
                for col, val in rows_data[row_idx].items():
                    new_val = (result.get(col, 0) + coeff * int(val)) % p
                    if new_val == 0:
                        result.pop(col, None)
                    else:
                        result[col] = new_val
            
            # Subtract g_coeffs[i, m] * row(j, m) for each m
            for m_idx in range(n_mults):
                coeff = int(g_coeffs[i, m_idx])
                if coeff == 0:
                    continue
                row_idx = j * n_mults + m_idx
                for col, val in rows_data[row_idx].items():
                    new_val = (result.get(col, 0) - coeff * int(val)) % p
                    if new_val == 0:
                        result.pop(col, None)
                    else:
                        result[col] = new_val
            
            # Check if result is zero
            if len(result) == 0:
                null_count += 1
            else:
                print(f'  WARNING: syzygy ({i},{j}) not in null space, |residual|={len(result)}')
    
    elapsed = time.time() - t0
    print(f'  Koszul syzygies verified: {null_count}/{comb(m, 2)} in null space [{elapsed:.1f}s]')
    
    # Now check linear independence of the null vectors
    # The Koszul syzygies form a subset of the null space
    # We need to check how many are linearly independent
    # Build them as sparse vectors and do sparse Gaussian elimination
    
    print(f'  Checking linear independence of {comb(m, 2)} syzygies...')
    
    # Build syzygy vectors as sparse rows
    syn_rows = []
    for i in range(m):
        for j in range(i+1, m):
            row = {}
            for m_idx in range(n_mults):
                coeff = int(g_coeffs[j, m_idx])
                if coeff != 0:
                    row_idx = i * n_mults + m_idx
                    row[row_idx] = (row.get(row_idx, 0) + coeff) % p
                coeff = int(g_coeffs[i, m_idx])
                if coeff != 0:
                    row_idx = j * n_mults + m_idx
                    row[row_idx] = (row.get(row_idx, 0) - coeff) % p
            # Clean up zeros
            row = {k: v % p for k, v in row.items() if v % p != 0}
            if row:
                syn_rows.append(row)
    
    # Rank of syzygy matrix
    from sparse_gauss import sparse_rank
    syn_rank = sparse_rank(syn_rows, n_rows, p, verbose=False)
    print(f'  Syzygy rank: {syn_rank}/{len(syn_rows)}')
    print(f'  Predicted Koszul rank: {comb(m, 2)} = {comb(m, 2)}')
    
    # Also compute actual null space dimension
    actual_null = n_rows - sparse_rank(rows_data, n_cols, p, verbose=False)
    print(f'  Actual null space dim: {actual_null}')
    
    if diagonal:
        block_syn = 5 * comb(n + 2, 2)
        koszul = comb(20, 2)
        print(f'  Predicted: block={block_syn} + koszul={koszul} = {block_syn + koszul}')
    else:
        koszul = comb(25, 2)
        print(f'  Predicted: koszul={koszul}')
    print()
