"""
Full XL solving degree measurement: Frobenius vs Generic systems.
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def eval_frobenius_sum(GF, p, e, terms, x_int):
    x = GF(x_int)
    result = GF(0)
    for a, b, c_int in terms:
        result = result + GF(c_int) * x ** (p**a + p**b)
    return result

def build_quad_frobenius(GF, p, e, terms, h_int):
    basis = []
    for j in range(e):
        v = np.zeros(e, dtype=np.int64)
        v[j] = 1
        val = sum(int(v[i]) * (p**i) for i in range(e))
        basis.append(GF(val))
    
    F_ej = [np.array(eval_frobenius_sum(GF, p, e, terms, int(basis[j])).vector(), dtype=np.int64) for j in range(e)]
    F_ei_ej = {}
    for i in range(e):
        for j in range(i+1, e):
            F_ei_ej[(i,j)] = np.array(eval_frobenius_sum(GF, p, e, terms, int(basis[i] + basis[j])).vector(), dtype=np.int64)
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    const = np.zeros(e, dtype=np.int64)
    h_vec = np.array(GF(h_int).vector(), dtype=np.int64)
    inv2 = pow(2, p-2, p)
    
    for eq in range(e):
        const[eq] = (-h_vec[eq]) % p
        for j in range(e):
            Q[eq, j, j] = int(F_ej[j][eq])
        for i in range(e):
            for j in range(i+1, e):
                cross = (int(F_ei_ej[(i,j)][eq]) - int(F_ej[i][eq]) - int(F_ej[j][eq])) % p
                cross = (cross * inv2) % p
                Q[eq, i, j] = cross
                Q[eq, j, i] = cross
    
    return Q, const

def build_quad_generic(p, e, rng):
    """Build a generic random quadratic system."""
    Q = np.zeros((e, e, e), dtype=np.int64)
    const = np.zeros(e, dtype=np.int64)
    for eq in range(e):
        for j in range(e):
            Q[eq, j, j] = rng.randint(0, p-1)
        for i in range(e):
            for j in range(i+1, e):
                v = rng.randint(0, p-1)
                Q[eq, i, j] = v
                Q[eq, j, i] = v
        const[eq] = rng.randint(0, p-1)
    return Q, const

def gen_monomials(e, max_deg):
    mons = []
    for deg in range(max_deg, -1, -1):
        for combo in combinations_with_replacement(range(e), deg):
            mons.append(combo)
    return mons

def build_macaulay(Q, const, e, d, p):
    col_mons = gen_monomials(e, d)
    n_cols = len(col_mons)
    col_idx = {m: i for i, m in enumerate(col_mons)}
    
    if d < 2:
        return np.zeros((0, n_cols), dtype=np.int64), col_mons, n_cols
    
    mult_mons = []
    for deg in range(d - 1):
        for combo in combinations_with_replacement(range(e), deg):
            mult_mons.append(combo)
    
    n_rows = e * len(mult_mons)
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    
    row = 0
    for eq_idx in range(e):
        Q_eq = Q[eq_idx]
        for mult in mult_mons:
            for j in range(e):
                for k in range(e):
                    coeff = int(Q_eq[j, k])
                    if coeff != 0:
                        prod = tuple(sorted(mult + (j, k)))
                        if prod in col_idx:
                            M[row, col_idx[prod]] = (M[row, col_idx[prod]] + coeff) % p
            c = int(const[eq_idx])
            if c != 0 and mult in col_idx:
                M[row, col_idx[mult]] = (M[row, col_idx[mult]] + c) % p
            row += 1
    
    return M, col_mons, n_cols

def gauss_fast(M, p):
    M = M.copy() % p
    n_rows, n_cols = M.shape
    pivot_row = 0
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        col_data = M[pivot_row:, col] % p
        nonzero = np.where(col_data != 0)[0]
        if len(nonzero) == 0:
            continue
        idx = nonzero[0] + pivot_row
        M[[pivot_row, idx]] = M[[idx, pivot_row]]
        inv = pow(int(M[pivot_row, col]), p-2, p)
        M[pivot_row] = (M[pivot_row] * inv) % p
        for r in range(n_rows):
            if r != pivot_row and M[r, col] % p != 0:
                M[r] = (M[r] - int(M[r, col]) * M[pivot_row]) % p
        pivot_row += 1
    return M[:pivot_row]

def detect_solving(reduced, col_mons, e, d, p):
    const_idx = None
    linear_allowed = set()
    univar_allowed = {}
    for i, m in enumerate(col_mons):
        if len(m) == 0:
            const_idx = i
        elif len(m) == 1:
            linear_allowed.add(i)
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
        elif len(set(m)) == 1:
            var = m[0]
            if var not in univar_allowed:
                univar_allowed[var] = set()
            univar_allowed[var].add(i)
    
    if const_idx is not None:
        linear_allowed.add(const_idx)
        for var in univar_allowed:
            univar_allowed[var].add(const_idx)
    
    n_lin = 0
    n_uni = 0
    n_inc = 0
    
    for r in range(reduced.shape[0]):
        row = reduced[r] % p
        nz = set(np.where(row != 0)[0])
        if const_idx is not None and nz == {const_idx}:
            n_inc += 1
            continue
        if nz.issubset(linear_allowed):
            n_lin += 1
        for var in range(e):
            if var in univar_allowed and nz.issubset(univar_allowed[var]):
                n_uni += 1
                break
    
    return n_lin > 0, n_uni > 0, n_lin, n_uni, n_inc

def run_xl(Q, const, e, p, max_d=8):
    d_lin = None
    d_uni = None
    inconsistent = False
    
    for d in range(2, max_d + 1):
        M, col_mons, n_cols = build_macaulay(Q, const, e, d, p)
        if M.shape[0] == 0:
            continue
        
        reduced = gauss_fast(M, p)
        found_lin, found_uni, n_lin, n_uni, n_inc = detect_solving(reduced, col_mons, e, d, p)
        
        if n_inc > 0:
            inconsistent = True
        if found_lin and d_lin is None:
            d_lin = d
        if found_uni and d_uni is None:
            d_uni = d
        if d_lin is not None and d_uni is not None:
            break
        if n_cols > 1500:
            break
    
    return d_lin, d_uni, inconsistent

def main():
    # === Test 1: p=3, e=5 ===
    p, e = 3, 5
    GF = galois.GF(p**e)
    schedule = [(0,1),(1,2),(2,3),(3,4),(4,0)]
    
    print(f"{'='*85}")
    print(f"XL Solving Degree: p={p}, e={e}")
    print(f"{'='*85}")
    
    pairs = list(combinations(range(5), 2))
    
    # --- Frobenius systems ---
    print(f"\n--- Frobenius (3-term residual) ---")
    print(f"{'Cancel':>8s} | {'D_lin':>6s} | {'D_uni':>6s} | {'Incons':>6s}")
    print("-" * 40)
    
    frob_results = []
    for cancel in pairs:
        residual = [schedule[k] for k in range(5) if k not in cancel]
        rng = random.Random(42)
        x0_int = rng.randint(1, p**e - 1)
        x0 = GF(x0_int)
        
        rng_c = random.Random(hash(cancel) % 2**32)
        terms = []
        for a, b in residual:
            c_int = int(GF(rng_c.randint(1, p**e - 1)))
            terms.append((a, b, c_int))
        
        h_val = GF(0)
        for a, b, c_int in terms:
            h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
        
        Q, const = build_quad_frobenius(GF, p, e, terms, int(h_val))
        d_lin, d_uni, inc = run_xl(Q, const, e, p, max_d=7)
        
        dl = str(d_lin) if d_lin else "-"
        du = str(d_uni) if d_uni else "-"
        ic = "YES" if inc else "no"
        print(f"{str(cancel):>8s} | {dl:>6s} | {du:>6s} | {ic:>6s}")
        frob_results.append((d_lin, d_uni, inc))
    
    # --- Generic systems ---
    print(f"\n--- Generic (random quadratics) ---")
    print(f"{'Seed':>8s} | {'D_lin':>6s} | {'D_uni':>6s} | {'Incons':>6s}")
    print("-" * 40)
    
    gen_results = []
    for seed in range(10):
        rng = random.Random(seed * 1000 + 777)
        Q, const = build_quad_generic(p, e, rng)
        d_lin, d_uni, inc = run_xl(Q, const, e, p, max_d=7)
        
        dl = str(d_lin) if d_lin else "-"
        du = str(d_uni) if d_uni else "-"
        ic = "YES" if inc else "no"
        print(f"{seed:>8d} | {dl:>6s} | {du:>6s} | {ic:>6s}")
        gen_results.append((d_lin, d_uni, inc))
    
    # Summary
    f_lins = [r[0] for r in frob_results if r[0]]
    f_unis = [r[1] for r in frob_results if r[1]]
    f_inc = sum(1 for r in frob_results if r[2])
    g_lins = [r[0] for r in gen_results if r[0]]
    g_unis = [r[1] for r in gen_results if r[1]]
    g_inc = sum(1 for r in gen_results if r[2])
    
    print(f"\n--- Summary ---")
    print(f"Frobenius: D_lin=[{min(f_lins) if f_lins else '-'},{max(f_lins) if f_lins else '-'}] "
          f"D_uni=[{min(f_unis) if f_unis else '-'},{max(f_unis) if f_unis else '-'}] "
          f"Incons={f_inc}/10")
    print(f"Generic:   D_lin=[{min(g_lins) if g_lins else '-'},{max(g_lins) if g_lins else '-'}] "
          f"D_uni=[{min(g_unis) if g_unis else '-'},{max(g_unis) if g_unis else '-'}] "
          f"Incons={g_inc}/10")
    
    # === Test 2: p=5, e=5 ===
    print(f"\n{'='*85}")
    p, e = 5, 5
    GF = galois.GF(p**e)
    
    print(f"XL Solving Degree: p={p}, e={e}")
    print(f"{'='*85}")
    
    print(f"\n--- Frobenius (3-term residual) ---")
    print(f"{'Cancel':>8s} | {'D_lin':>6s} | {'D_uni':>6s} | {'Incons':>6s}")
    print("-" * 40)
    
    frob_results2 = []
    for cancel in pairs:
        residual = [schedule[k] for k in range(5) if k not in cancel]
        rng = random.Random(42)
        x0_int = rng.randint(1, p**e - 1)
        x0 = GF(x0_int)
        
        rng_c = random.Random(hash(cancel) % 2**32)
        terms = []
        for a, b in residual:
            c_int = int(GF(rng_c.randint(1, p**e - 1)))
            terms.append((a, b, c_int))
        
        h_val = GF(0)
        for a, b, c_int in terms:
            h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
        
        Q, const = build_quad_frobenius(GF, p, e, terms, int(h_val))
        d_lin, d_uni, inc = run_xl(Q, const, e, p, max_d=7)
        
        dl = str(d_lin) if d_lin else "-"
        du = str(d_uni) if d_uni else "-"
        ic = "YES" if inc else "no"
        print(f"{str(cancel):>8s} | {dl:>6s} | {du:>6s} | {ic:>6s}")
        frob_results2.append((d_lin, d_uni, inc))
    
    print(f"\n--- Generic (random quadratics) ---")
    print(f"{'Seed':>8s} | {'D_lin':>6s} | {'D_uni':>6s} | {'Incons':>6s}")
    print("-" * 40)
    
    gen_results2 = []
    for seed in range(10):
        rng = random.Random(seed * 1000 + 777)
        Q, const = build_quad_generic(p, e, rng)
        d_lin, d_uni, inc = run_xl(Q, const, e, p, max_d=7)
        
        dl = str(d_lin) if d_lin else "-"
        du = str(d_uni) if d_uni else "-"
        ic = "YES" if inc else "no"
        print(f"{seed:>8d} | {dl:>6s} | {du:>6s} | {ic:>6s}")
        gen_results2.append((d_lin, d_uni, inc))
    
    f_lins = [r[0] for r in frob_results2 if r[0]]
    f_unis = [r[1] for r in frob_results2 if r[1]]
    f_inc = sum(1 for r in frob_results2 if r[2])
    g_lins = [r[0] for r in gen_results2 if r[0]]
    g_unis = [r[1] for r in gen_results2 if r[1]]
    g_inc = sum(1 for r in gen_results2 if r[2])
    
    print(f"\n--- Summary ---")
    print(f"Frobenius: D_lin=[{min(f_lins) if f_lins else '-'},{max(f_lins) if f_lins else '-'}] "
          f"D_uni=[{min(f_unis) if f_unis else '-'},{max(f_unis) if f_unis else '-'}] "
          f"Incons={f_inc}/10")
    print(f"Generic:   D_lin=[{min(g_lins) if g_lins else '-'},{max(g_lins) if g_lins else '-'}] "
          f"D_uni=[{min(g_unis) if g_unis else '-'},{max(g_unis) if g_unis else '-'}] "
          f"Incons={g_inc}/10")

if __name__ == "__main__":
    main()
