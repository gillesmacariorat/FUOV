#!/usr/bin/env python3
"""
idempotents_fq_exact.py — Exhaustive idempotent search in the centralizer algebra.
Searches for E in the centralizer with E^2 = E (over F_p), using exact
arithmetic. Requires centralizer_fq_exact.py to produce the centralizer basis.

Usage:
    python3 -c "
    from centralizer_fq_exact import *
    from idempotents_fq_exact import find_idempotents_exhaustive
    find_idempotents_exhaustive(comm_sec, n, p, e, 'Secret')
    find_idempotents_exhaustive(comm_pub, n, p, e, 'Public')
    "
"""
import numpy as np
from collections import Counter


def mat_rank_exact(M, p):
    """Exact rank over F_p via Gaussian elimination."""
    M = np.array(M, dtype=np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        if pivot != rank:
            M[[rank, pivot]] = M[[pivot, rank]]
        inv_val = pow(int(M[rank, col]), -1, p)
        M[rank] = (M[rank] * inv_val) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
    return rank


def find_idempotents_exhaustive(comm_mats, n, p, e, label=""):
    """
    Exhaustive search over F_p^dim for idempotents E^2 = E.
    Returns list of (coefficients, rank) pairs.
    """
    dim = len(comm_mats)
    if dim == 0:
        print(f"{label}: dim=0, no idempotents")
        return []

    print(f"{label}: exhaustive search over F_{p}^{dim} ({p**dim} elements)...")

    idempotents = []
    for idx in np.ndindex(*[p] * dim):
        a = list(idx)
        X = np.zeros((n, n), dtype=np.int64)
        for i in range(dim):
            X = (X + a[i] * comm_mats[i]) % p

        X2 = (X @ X) % p
        if np.array_equal(X2 % p, X % p):
            rank = mat_rank_exact(X.copy(), p)
            if 0 < rank < n:
                idempotents.append((a, rank))

    ranks = Counter(r for _, r in idempotents)
    print(f"{label}: {len(idempotents)} idempotents, ranks={dict(ranks)}")

    # Show primitive idempotents (rank = e)
    primitive = [(a, r) for a, r in idempotents if r == e]
    if primitive:
        print(f"  {len(primitive)} primitive idempotents of rank {e}:")
        for a, r in primitive:
            print(f"    coeffs={a}, rank={r}")

    # Show block structure of first primitive idempotent
    if primitive:
        a = primitive[0][0]
        X = np.zeros((n, n), dtype=np.int64)
        for i in range(dim):
            X = (X + a[i] * comm_mats[i]) % p
        print(f"\n  Block structure of first primitive idempotent:")
        for bi in range(4):
            for bj in range(4):
                block = X[bi*e:(bi+1)*e, bj*e:(bj+1)*e]
                nz = int(np.sum(np.abs(block)))
                status = "empty" if nz == 0 else f"norm={nz}"
                print(f"    ({bi},{bj}): {status}")

    return idempotents


if __name__ == "__main__":
    from centralizer_fq_exact import main
    results = main()
    print("\n" + "=" * 60)
    print("IDEMPOTENT SEARCH")
    print("=" * 60)
    find_idempotents_exhaustive(
        results['comm_sec'], results['n'], results['p'], results['e'], "Secret")
    find_idempotents_exhaustive(
        results['comm_pub'], results['n'], results['p'], results['e'], "Public")
