"""
Check whether the forgery system (e eqs in 5e vars) has degree-4 syzygies,
comparing diagonal (SALAD) vs dense (UFOs) vs generic random MQ.

This tests the semi-regular assumption underlying the Hybrid-F4 analysis.
"""
import numpy as np
import random

def gaussian_rank_mod_p(M, p):
    """Exact rank of M over F_p using Gaussian elimination."""
    M = M.copy() % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        # Find pivot
        pivot = None
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot is None:
            continue
        # Swap
        M[[rank, pivot]] = M[[pivot, rank]]
        # Eliminate
        inv = pow(int(M[rank, col] % p), p - 2, p)
        M[rank] = (M[rank] * inv) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
        if rank >= rows:
            break
    return rank

def build_macaulay_forgery_diagonal(e, p, d, seed=42):
    """
    Build Macaulay matrix for the forgery system (diagonal/SALAD case).
    
    The forgery system has e equations in 5e variables over F_p.
    After Weil descent, each equation is a quadratic form in the 
    coordinate variables of X = (X_0, ..., X_4).
    
    For the diagonal case, each P_k(X) = sum_i c_{k,i} * X_i^{p^{a_k} + p^{b_k}}
    After Weil descent, this becomes e quadratic equations per block.
    
    We simulate this with random diagonal quadratic forms.
    """
    rng = random.Random(seed)
    n = 5 * e  # 5e variables
    m = e      # e equations
    
    # Generate random quadratic forms (diagonal: only X_i^{p^a + p^b} terms)
    # For simplicity, use random quadratic forms over F_p
    # Each equation has terms of the form c * x_j * x_k where j,k are coordinates
    
    # Monomials of degree <= d in n variables
    from itertools import combinations_with_replacement
    monomials = []
    for deg in range(d + 1):
        for combo in combinations_with_replacement(range(n), deg):
            monomials.append(combo)
    
    cols = len(monomials)
    monomial_index = {m: i for i, m in enumerate(monomials)}
    
    # For each equation, generate quadratic terms
    # Diagonal case: only terms within the same block (X_i coordinates)
    rows = m * len([1 for deg in range(2, d+1) for _ in combinations_with_replacement(range(n), deg-2)])
    # Actually, let's use the standard Macaulay construction
    
    # Macaulay matrix: rows = m * C(n+d-2, d-2), cols = C(n+d, d)
    from math import comb
    n_rows = m * comb(n + d - 2, d - 2)
    n_cols = comb(n + d, d)
    
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    
    # Generate e random quadratic equations (diagonal structure)
    # For diagonal: each equation involves only monomials where all variables 
    # come from the same block (same X_i)
    equations = []
    for k in range(m):
        eq = {}  # monomial -> coefficient
        # Random diagonal quadratic terms: for each block i, pick random pairs
        for block in range(5):
            start = block * e
            for _ in range(e):  # e terms per block
                j = rng.randint(start, start + e - 1)
                l = rng.randint(start, start + e - 1)
                c = rng.randint(1, p - 1)
                mono = tuple(sorted([j, l]))
                eq[mono] = (eq.get(mono, 0) + c) % p
        equations.append(eq)
    
    # Fill Macaulay matrix
    row_idx = 0
    for eq_idx in range(m):
        eq = equations[eq_idx]
        # Multiply each quadratic term by all monomials of degree d-2
        for extra in combinations_with_replacement(range(n), d - 2):
            for mono, coeff in eq.items():
                full_mono = tuple(sorted(list(mono) + list(extra)))
                col_idx = monomial_index.get(full_mono)
                if col_idx is not None:
                    M[row_idx, col_idx] = (M[row_idx, col_idx] + coeff) % p
            row_idx += 1
    
    return M, n_rows, n_cols

def build_macaulay_forgery_dense(e, p, d, seed=42):
    """Build Macaulay matrix for the forgery system (dense/UFOs case)."""
    rng = random.Random(seed)
    n = 5 * e
    m = e
    
    from itertools import combinations_with_replacement
    from math import comb
    monomials = []
    for deg in range(d + 1):
        for combo in combinations_with_replacement(range(n), deg):
            monomials.append(combo)
    
    n_rows = m * comb(n + d - 2, d - 2)
    n_cols = comb(n + d, d)
    
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    monomial_index = {m: i for i, m in enumerate(monomials)}
    
    # Dense: random quadratic terms across ALL variables (not block-restricted)
    equations = []
    for k in range(m):
        eq = {}
        for _ in range(5 * e):  # same number of terms as diagonal
            j = rng.randint(0, n - 1)
            l = rng.randint(0, n - 1)
            c = rng.randint(1, p - 1)
            mono = tuple(sorted([j, l]))
            eq[mono] = (eq.get(mono, 0) + c) % p
        equations.append(eq)
    
    row_idx = 0
    for eq_idx in range(m):
        eq = equations[eq_idx]
        for extra in combinations_with_replacement(range(n), d - 2):
            for mono, coeff in eq.items():
                full_mono = tuple(sorted(list(mono) + list(extra)))
                col_idx = monomial_index.get(full_mono)
                if col_idx is not None:
                    M[row_idx, col_idx] = (M[row_idx, col_idx] + coeff) % p
            row_idx += 1
    
    return M, n_rows, n_cols

def build_macaulay_forgery_generic(e, p, d, seed=42):
    """Build Macaulay matrix for a GENERIC random MQ system (e eqs, 5e vars)."""
    rng = random.Random(seed)
    n = 5 * e
    m = e
    
    from itertools import combinations_with_replacement
    from math import comb
    monomials = []
    for deg in range(d + 1):
        for combo in combinations_with_replacement(range(n), deg):
            monomials.append(combo)
    
    n_rows = m * comb(n + d - 2, d - 2)
    n_cols = comb(n + d, d)
    
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    monomial_index = {m: i for i, m in enumerate(monomials)}
    
    # Generic: completely random quadratic forms
    equations = []
    for k in range(m):
        eq = {}
        # Random number of terms
        n_terms = rng.randint(e, 3*e)
        for _ in range(n_terms):
            j = rng.randint(0, n - 1)
            l = rng.randint(0, n - 1)
            c = rng.randint(1, p - 1)
            mono = tuple(sorted([j, l]))
            eq[mono] = (eq.get(mono, 0) + c) % p
        equations.append(eq)
    
    row_idx = 0
    for eq_idx in range(m):
        eq = equations[eq_idx]
        for extra in combinations_with_replacement(range(n), d - 2):
            for mono, coeff in eq.items():
                full_mono = tuple(sorted(list(mono) + list(extra)))
                col_idx = monomial_index.get(full_mono)
                if col_idx is not None:
                    M[row_idx, col_idx] = (M[row_idx, col_idx] + coeff) % p
            row_idx += 1
    
    return M, n_rows, n_cols

# Test at d=4 for e=5
e = 5
p = 31
d = 4

from math import comb
n = 5 * e
n_rows = e * comb(n + d - 2, d - 2)
n_cols = comb(n + d, d)
print(f"Forgery system d=4: e={e}, p={p}, n={n}")
print(f"Macaulay matrix: {n_rows} rows x {n_cols} cols")
print()

for variant_name, builder in [("Diagonal (SALAD)", build_macaulay_forgery_diagonal),
                               ("Dense (UFOs)", build_macaulay_forgery_dense),
                               ("Generic MQ", build_macaulay_forgery_generic)]:
    results = []
    for seed in range(5):
        M, nr, nc = builder(e, p, d, seed=seed)
        rank = gaussian_rank_mod_p(M, p)
        deficiency = min(nr, nc) - rank
        results.append((rank, deficiency))
    
    print(f"{variant_name}:")
    for i, (rank, deficiency) in enumerate(results):
        print(f"  seed {i}: rank={rank}/{min(n_rows, n_cols)}, def={deficiency}")
    
    # Check if any deficiency > 0
    any_def = any(d > 0 for _, d in results)
    if any_def:
        print(f"  ** SYZYGIES DETECTED at d=4! **")
    else:
        print(f"  No syzygies (full rank)")
    print()

