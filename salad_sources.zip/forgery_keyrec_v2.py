#!/usr/bin/env python3
"""
Optimized experiments: construct Weil-descent systems directly with numpy.
Forgery: e eqs in 5e vars. Key recovery: 5e eqs in 4e vars.
Compares SALAD (diagonal) vs UFOs (dense).
"""

import numpy as np
from math import comb
import time

def setup_field(p, e):
    """Setup GF(p^e): primitive element, Frobenius matrices, multiplication table."""
    import galois
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    
    # Frobenius matrix F_a: col j = vector(alpha^(j*p^a))
    def frob_matrix(a):
        F = np.zeros((e, e), dtype=np.int64)
        for j in range(e):
            val = alpha ** (j * (p ** a))
            vec = np.array(val.vector(), dtype=np.int64)[::-1]
            F[:, j] = vec
        return F % p
    
    # Multiplication table: mu[r,s,m] = coeff of alpha^m in alpha^r * alpha^s
    mu = np.zeros((e, e, e), dtype=np.int64)
    for i in range(e):
        for j in range(e):
            prod = (alpha ** i) * (alpha ** j)
            vec = np.array(prod.vector(), dtype=np.int64)[::-1]
            mu[i, j, :] = vec
    
    return GF, alpha, mu, frob_matrix

def build_forgery_system(p, e, schedule, cancel_pair, coeffs, diagonal, mu, frob_fn):
    """
    Build the quadratic system for forgery (relaxed: e eqs in 5e vars).
    Returns: Q (e, 5e, 5e) quadratic tensor, L (e, 5e) linear, c (e,) constant.
    Only upper triangle of Q is filled.
    """
    residual = [k for k in range(5) if k not in cancel_pair]
    n_vars = 5 * e
    n_eqs = e
    
    Q = np.zeros((n_eqs, n_vars, n_vars), dtype=np.int64)
    L = np.zeros((n_eqs, n_vars), dtype=np.int64)
    c = np.zeros(n_eqs, dtype=np.int64)
    
    for k in residual:
        a_k, b_k = schedule[k]
        Fa = frob_fn(a_k)
        Fb = frob_fn(b_k)
        # For each variable i (0..4), the term is c_{k,i} * X_i^{p^a} * X_i^{p^b}
        # In coordinates: c_{k,i} * sum_{r,s} mu[r,s,m] * (Fa @ x_i)_r * (Fb @ x_i)_s
        # = c_{k,i} * sum_{r,s,m} mu[r,s,m] * Fa[r,j] * Fb[s,l] * x_{i,j} * x_{i,l}
        # So Q[m, i*e+j, i*e+l] += c_{k,i} * sum_{r,s} mu[r,s,m] * Fa[r,j] * Fb[s,l]
        
        if diagonal:
            for i in range(5):
                ci = int(coeffs[k, i])
                if ci == 0:
                    continue
                # Compute the quadratic form for variable i, block k
                # Q_ki[m, j, l] = ci * sum_{r,s} mu[r,s,m] * Fa[r,j] * Fb[s,l]
                # = ci * einsum('rsm,rj,sl->mjl', mu, Fa, Fb)
                Q_block = ci * np.einsum('rsm,rj,sl->mjl', mu, Fa, Fb) % p
                # Add to the diagonal block for variable i
                idx = i * e
                Q[:, idx:idx+e, idx:idx+e] = (Q[:, idx:idx+e, idx:idx+e] + Q_block) % p
        else:
            # Dense: P_k(X) = sum_{i,j} A_k[i,j] * X_i^[a_k] * X_j^[b_k]
            for i in range(5):
                for j in range(5):
                    aij = int(coeffs[k, i, j])
                    if aij == 0:
                        continue
                    # Q[m, i*e+r, j*e+s] += aij * sum_{r',s'} mu[r',s',m] * Fa[r',r] * Fb[s',s]
                    Q_block = aij * np.einsum('rsm,rp,sq->mpq', mu, Fa, Fb) % p
                    idx_i = i * e
                    idx_j = j * e
                    Q[:, idx_i:idx_i+e, idx_j:idx_j+e] = (Q[:, idx_i:idx_i+e, idx_j:idx_j+e] + Q_block) % p
    
    return Q, L, c

def build_keyrecovery_system(p, e, schedule, coeffs, diagonal, mu, frob_fn):
    """
    Build the quadratic system for key recovery (5e eqs in 4e vars, X_0=1).
    Variables: x_{1,0},...,x_{1,e-1}, ..., x_{4,0},...,x_{4,e-1} (4e vars)
    Equations: 5 blocks, each giving e equations (5e total)
    
    For planted instances, P_k(Lambda) = 0 for the planted Lambda.
    """
    n_vars = 4 * e
    n_eqs = 5 * e
    
    Q = np.zeros((n_eqs, n_vars, n_vars), dtype=np.int64)
    L = np.zeros((n_eqs, n_vars), dtype=np.int64)
    c = np.zeros(n_eqs, dtype=np.int64)
    
    for k in range(5):
        a_k, b_k = schedule[k]
        Fa = frob_fn(a_k)
        Fb = frob_fn(b_k)
        eq_offset = k * e  # This block contributes to equations eq_offset..eq_offset+e-1
        
        # The quadratic form tensor for one pair (i,j):
        # Q_kij[m, r, s] = A_k[i,j] * sum_{r',s'} mu[r',s',m] * Fa[r',r] * Fb[s',s]
        # where m is the equation index within this block (0..e-1)
        Q_tensor = np.einsum('rsm,rp,sq->mpq', mu, Fa, Fb) % p
        
        if diagonal:
            # P_k(X) = sum_i c_{k,i} * X_i^{p^a + p^b}
            # X_0 = 1 (constant), so the term for i=0 is c_{k,0} * 1 = c_{k,0} (constant)
            # Terms for i=1..4 involve variables x_{i-1, 0..e-1}
            
            # Constant term from X_0
            c[eq_offset:eq_offset+e] = (c[eq_offset:eq_offset+e] + int(coeffs[k, 0])) % p
            
            for i in range(1, 5):
                ci = int(coeffs[k, i])
                if ci == 0:
                    continue
                var_offset = (i - 1) * e
                # Quadratic part: ci * Q_tensor
                Q[eq_offset:eq_offset+e, var_offset:var_offset+e, var_offset:var_offset+e] = (
                    Q[eq_offset:eq_offset+e, var_offset:var_offset+e, var_offset:var_offset+e] + ci * Q_tensor
                ) % p
        else:
            # Dense: P_k(X) = sum_{i,j} A_k[i,j] * X_i^[a_k] * X_j^[b_k]
            for i in range(5):
                for j in range(5):
                    aij = int(coeffs[k, i, j])
                    if aij == 0:
                        continue
                    
                    if i == 0 and j == 0:
                        # Both X_0 = 1: constant term
                        c[eq_offset:eq_offset+e] = (c[eq_offset:eq_offset+e] + aij) % p
                    elif i == 0:
                        # X_0 = 1, X_j is variable: linear term
                        var_offset = (j - 1) * e
                        # L[m, s] += aij * sum_{r',s'} mu[r',s',m] * Fa[r',0] * Fb[s',s]
                        # = aij * einsum('rsm,r0,sp->mp', mu, Fa, Fb) -- but Fa[:,0] is just a vector
                        lin = aij * np.einsum('rsm,r,sp->mp', mu, Fa[:, 0], Fb) % p
                        L[eq_offset:eq_offset+e, var_offset:var_offset+e] = (
                            L[eq_offset:eq_offset+e, var_offset:var_offset+e] + lin
                        ) % p
                    elif j == 0:
                        # X_i is variable, X_0 = 1: linear term
                        var_offset = (i - 1) * e
                        lin = aij * np.einsum('rsm,rp,s0->mp', mu, Fa, Fb[:, 0]) % p
                        L[eq_offset:eq_offset+e, var_offset:var_offset+e] = (
                            L[eq_offset:eq_offset+e, var_offset:var_offset+e] + lin
                        ) % p
                    else:
                        # Both X_i and X_j are variables: quadratic term
                        var_i = (i - 1) * e
                        var_j = (j - 1) * e
                        Q[eq_offset:eq_offset+e, var_i:var_i+e, var_j:var_j+e] = (
                            Q[eq_offset:eq_offset+e, var_i:var_i+e, var_j:var_j+e] + aij * Q_tensor
                        ) % p
    
    return Q, L, c

def validate_system(Q, L, c, n_vars, n_eqs, p, eval_func, n_tests=3):
    """Validate by comparing with direct evaluation."""
    import random
    rng = random.Random(123)
    max_err = 0
    for _ in range(n_tests):
        x = np.array([rng.randrange(0, p) for _ in range(n_vars)], dtype=np.int64)
        f_exact = eval_func(x) % p
        f_approx = c.copy()
        f_approx = (f_approx + L @ x) % p
        # Quadratic: x^T Q x for each equation
        for eq in range(n_eqs):
            quad = x @ Q[eq] @ x  # This computes sum_{j,l} Q[eq,j,l] * x_j * x_l
            f_approx[eq] = (f_approx[eq] + quad) % p
        err = np.max(np.abs((f_exact - f_approx) % p))
        max_err = max(max_err, int(err))
    return max_err

def generate_monomials(n, max_deg):
    """Generate all monomials of degree <= max_deg as exponent tuples."""
    monos = []
    def gen(idx, remaining, current):
        if idx == n:
            monos.append(tuple(current))
            return
        for d in range(remaining + 1):
            current.append(d)
            gen(idx + 1, remaining - d, current)
            current.pop()
    gen(0, max_deg, [])
    return monos

def build_macaulay_and_rank(Q, L, c, n_vars, n_eqs, p, degree):
    """Build Macaulay matrix at given degree and compute rank."""
    t0 = time.time()
    
    all_monos = generate_monomials(n_vars, degree)
    n_cols = len(all_monos)
    mono_to_idx = {m: i for i, m in enumerate(all_monos)}
    
    if degree < 2:
        multipliers = [tuple([0] * n_vars)]
    else:
        multipliers = generate_monomials(n_vars, degree - 2)
    
    n_rows = n_eqs * len(multipliers)
    print(f"  d={degree}: {n_rows} rows x {n_cols} cols", end="", flush=True)
    
    # Build as sparse (COO format)
    rows_list = []
    cols_list = []
    vals_list = []
    
    for eq_idx in range(n_eqs):
        # Constant: c[eq_idx] * mono
        if c[eq_idx] != 0:
            for m_idx, m_mono in enumerate(multipliers):
                rows_list.append(eq_idx * len(multipliers) + m_idx)
                cols_list.append(mono_to_idx[m_mono])
                vals_list.append(int(c[eq_idx]) % p)
        
        # Linear: L[eq_idx, j] * x_j * mono
        for j in range(n_vars):
            if L[eq_idx, j] != 0:
                for m_idx, m_mono in enumerate(multipliers):
                    new_mono = list(m_mono)
                    new_mono[j] += 1
                    new_mono = tuple(new_mono)
                    col = mono_to_idx.get(new_mono)
                    if col is not None:
                        rows_list.append(eq_idx * len(multipliers) + m_idx)
                        cols_list.append(col)
                        vals_list.append(int(L[eq_idx, j]) % p)
        
        # Quadratic: Q[eq_idx, j, l] * x_j * x_l * mono
        # Only iterate over nonzero entries
        for j in range(n_vars):
            for l in range(j, n_vars):
                qval = int(Q[eq_idx, j, l] % p)
                if qval == 0:
                    continue
                for m_idx, m_mono in enumerate(multipliers):
                    new_mono = list(m_mono)
                    new_mono[j] += 1
                    new_mono[l] += 1
                    new_mono = tuple(new_mono)
                    col = mono_to_idx.get(new_mono)
                    if col is not None:
                        rows_list.append(eq_idx * len(multipliers) + m_idx)
                        cols_list.append(col)
                        vals_list.append(qval)
    
    elapsed_build = time.time() - t0
    print(f" ({len(vals_list)} nnz, build {elapsed_build:.1f}s)", end="", flush=True)
    
    # Check if feasible
    if n_cols > 6000:
        print(f" -> SKIP (too large)", flush=True)
        return n_rows, n_cols, -1, -1
    
    # Build dense matrix
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    for r, col, v in zip(rows_list, cols_list, vals_list):
        M[r, col] = (M[r, col] + v) % p
    
    # Rank computation
    t0 = time.time()
    rank = rank_mod_p_fast(M, p)
    elapsed_rank = time.time() - t0
    
    expected = min(n_rows, n_cols)
    defic = expected - rank
    print(f" rank={rank}/{expected} def={defic} [{elapsed_rank:.1f}s]", flush=True)
    
    return n_rows, n_cols, rank, defic

def rank_mod_p_fast(M, p):
    """Fast Gaussian elimination over F_p."""
    M = M.copy().astype(np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        # Find pivot
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1:
            continue
        if pivot != rank:
            M[[rank, pivot]] = M[[pivot, rank]]
        # Scale pivot row
        inv_val = pow(int(M[rank, col]), p - 2, p)
        M[rank] = (M[rank] * inv_val) % p
        # Eliminate
        if rows > 1:
            # Vectorized elimination
            mask = (M[:, col] % p != 0)
            mask[rank] = False
            if mask.any():
                M[mask] = (M[mask] - M[mask, col:col+1] * M[rank:rank+1]) % p
        rank += 1
        if rank >= rows:
            break
    return rank

def gen_forgery_coeffs(p, schedule, cancel_pair, diagonal, seed=42):
    """Generate random coefficients for forgery."""
    import random
    rng = random.Random(seed)
    if diagonal:
        coeffs = np.zeros((5, 5), dtype=np.int64)
        for k in range(5):
            for i in range(5):
                coeffs[k, i] = rng.randrange(1, p)
        return coeffs
    else:
        coeffs = np.zeros((5, 5, 5), dtype=np.int64)
        for k in range(5):
            for i in range(5):
                for j in range(5):
                    coeffs[k, i, j] = rng.randrange(1, p)
        return coeffs

def gen_keyrecovery_coeffs(GF, alpha, p, e, schedule, diagonal, seed=42):
    """Generate planted key recovery instance."""
    import random
    rng = random.Random(seed)
    
    Lambda = [GF(1)]
    for i in range(4):
        Lambda.append(GF(rng.randrange(1, p**e)))
    
    if diagonal:
        coeffs = np.zeros((5, 5), dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            total = GF(0)
            for i in range(1, 5):
                coeffs[k, i] = rng.randrange(1, p)
                val = Lambda[i] ** (p ** a_k) * Lambda[i] ** (p ** b_k)
                total += GF(int(coeffs[k, i])) * val
            coeffs[k, 0] = int((-total) % p)
        return coeffs, Lambda
    else:
        coeffs = np.zeros((5, 5, 5), dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            total = GF(0)
            for i in range(5):
                for j in range(5):
                    if i == 0 and j == 0:
                        continue
                    coeffs[k, i, j] = rng.randrange(1, p)
                    val = Lambda[i] ** (p ** a_k) * Lambda[j] ** (p ** b_k)
                    total += GF(int(coeffs[k, i, j])) * val
            coeffs[k, 0, 0] = int((-total) % p)
        return coeffs, Lambda

def make_eval_keyrecovery(GF, alpha, p, e, schedule, coeffs, diagonal):
    """Make evaluation function for key recovery (4e vars -> 5e eqs)."""
    def eval_func(x_vec):
        X = [GF(1)]
        for i in range(1, 5):
            Xi = GF(0)
            for j in range(e):
                if x_vec[(i-1)*e + j] != 0:
                    Xi += GF(int(x_vec[(i-1)*e + j])) * (alpha ** j)
            X.append(Xi)
        
        output = np.zeros(5 * e, dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            val = GF(0)
            if diagonal:
                for i in range(5):
                    val += GF(int(coeffs[k, i])) * (X[i] ** (p ** a_k) * X[i] ** (p ** b_k))
            else:
                for i in range(5):
                    for j in range(5):
                        if coeffs[k, i, j] != 0:
                            val += GF(int(coeffs[k, i, j])) * (X[i] ** (p ** a_k) * X[j] ** (p ** b_k))
            vec = np.array(val.vector(), dtype=np.int64)[::-1]
            output[k*e:(k+1)*e] = vec % p
        return output
    return eval_func

# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    SCHEDULE_MOD5 = [(0,1), (1,2), (2,3), (3,4), (4,0)]
    SCHEDULE_MOD7 = [(0,1), (1,3), (2,5), (3,0), (4,2)]
    
    cancel_pair = (0, 1)
    all_results = {}
    
    configs = [
        (3, 5, SCHEDULE_MOD5, "mod5"),
        (3, 7, SCHEDULE_MOD7, "mod7"),
        (31, 5, SCHEDULE_MOD5, "mod5"),
        (31, 7, SCHEDULE_MOD7, "mod7"),
    ]
    
    # === FORGERY ===
    for p, e, sched, label in configs:
        GF, alpha, mu, frob_fn = setup_field(p, e)
        
        for diagonal in [True, False]:
            dlabel = "diag" if diagonal else "dense"
            key = f"forgery_p{p}_e{e}_{label}_{dlabel}"
            print(f"\n{'='*60}")
            print(f"FORGERY: p={p}, e={e}, {dlabel}, system: {e} eqs x {5*e} vars")
            print(f"{'='*60}")
            
            try:
                t0 = time.time()
                coeffs = gen_forgery_coeffs(p, sched, cancel_pair, diagonal, seed=42)
                Q, L, c = build_forgery_system(p, e, sched, cancel_pair, coeffs, diagonal, mu, frob_fn)
                print(f"  System built in {time.time()-t0:.1f}s")
                
                results = {}
                for d in range(2, 5):
                    n_rows, n_cols, rank, defic = build_macaulay_and_rank(Q, L, c, 5*e, e, p, d)
                    results[d] = (n_rows, n_cols, rank, defic)
                all_results[key] = results
            except Exception as ex:
                import traceback
                traceback.print_exc()
                all_results[key] = f"ERROR: {ex}"
    
    # === KEY RECOVERY ===
    for p, e, sched, label in configs:
        GF, alpha, mu, frob_fn = setup_field(p, e)
        
        for diagonal in [True, False]:
            dlabel = "diag" if diagonal else "dense"
            key = f"keyrec_p{p}_e{e}_{label}_{dlabel}"
            print(f"\n{'='*60}")
            print(f"KEY RECOVERY: p={p}, e={e}, {dlabel}, system: {5*e} eqs x {4*e} vars")
            print(f"{'='*60}")
            
            try:
                t0 = time.time()
                coeffs, Lambda = gen_keyrecovery_coeffs(GF, alpha, p, e, sched, diagonal, seed=42)
                Q, L, c = build_keyrecovery_system(p, e, sched, coeffs, diagonal, mu, frob_fn)
                print(f"  System built in {time.time()-t0:.1f}s")
                
                # Validate
                eval_func = make_eval_keyrecovery(GF, alpha, p, e, sched, coeffs, diagonal)
                lambda_vec = np.zeros(4 * e, dtype=np.int64)
                for i in range(1, 5):
                    vec = np.array(Lambda[i].vector(), dtype=np.int64)[::-1]
                    lambda_vec[(i-1)*e:i*e] = vec
                check = eval_func(lambda_vec) % p
                print(f"  Planted solution check: max={np.max(check)}")
                
                # Quick validation on random point
                import random
                rng = random.Random(99)
                x_test = np.array([rng.randrange(0, p) for _ in range(4*e)], dtype=np.int64)
                f_exact = eval_func(x_test) % p
                f_approx = c.copy()
                f_approx = (f_approx + L @ x_test) % p
                for eq in range(5*e):
                    f_approx[eq] = (f_approx[eq] + x_test @ Q[eq] @ x_test) % p
                err = np.max(np.abs((f_exact - f_approx) % p))
                print(f"  Validation error: {err}")
                
                results = {}
                for d in range(2, 5):
                    n_rows, n_cols, rank, defic = build_macaulay_and_rank(Q, L, c, 4*e, 5*e, p, d)
                    results[d] = (n_rows, n_cols, rank, defic)
                all_results[key] = results
            except Exception as ex:
                import traceback
                traceback.print_exc()
                all_results[key] = f"ERROR: {ex}"
    
    # === SUMMARY ===
    print(f"\n\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    
    for prefix, desc in [("forgery", "FORGERY (e eqs x 5e vars)"), ("keyrec", "KEY RECOVERY (5e eqs x 4e vars)")]:
        print(f"\n--- {desc} ---")
        print(f"{'Config':<40} {'d=2':>15} {'d=3':>15} {'d=4':>15}")
        for p, e, label in [(3,5,"mod5"), (3,7,"mod7"), (31,5,"mod5"), (31,7,"mod7")]:
            for dlabel in ["diag", "dense"]:
                key = f"{prefix}_p{p}_e{e}_{label}_{dlabel}"
                if key not in all_results:
                    continue
                results = all_results[key]
                if isinstance(results, str):
                    print(f"  {key:<38} {results}")
                    continue
                row = f"  p={p} e={e} {label} {dlabel:<6}"
                for d in [2, 3, 4]:
                    if d in results:
                        n_rows, n_cols, rank, defic = results[d]
                        row += f" {rank}/{min(n_rows,n_cols)}(d={defic})".rjust(15)
                    else:
                        row += f" {'N/A':>15}"
                print(row)
        
        # Comparison
        print(f"\n  Diagonal vs Dense comparison:")
        for p, e, label in [(3,5,"mod5"), (3,7,"mod7"), (31,5,"mod5"), (31,7,"mod7")]:
            diag_key = f"{prefix}_p{p}_e{e}_{label}_diag"
            dense_key = f"{prefix}_p{p}_e{e}_{label}_dense"
            if diag_key in all_results and dense_key in all_results:
                if isinstance(all_results[diag_key], str) or isinstance(all_results[dense_key], str):
                    continue
                rd = all_results[diag_key]
                rn = all_results[dense_key]
                for d in [2, 3, 4]:
                    if d in rd and d in rn:
                        _, _, rank_d, def_d = rd[d]
                        _, _, rank_n, def_n = rn[d]
                        match = "MATCH" if def_d == def_n else "DIFFER"
                        if def_d != def_n:
                            print(f"    p={p} e={e} d={d}: diag def={def_d}, dense def={def_n} -> {match}")
                        else:
                            print(f"    p={p} e={e} d={d}: diag def={def_d}, dense def={def_n} -> {match}")
