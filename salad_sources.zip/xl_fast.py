"""
Optimized XL solving degree measurement.
Key optimizations:
1. Vectorized Macaulay matrix construction using numpy
2. Fast Gaussian elimination mod p using numpy
3. Early termination when D_lin or D_uni found
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time, sys
from math import comb

def eval_frobenius_sum(GF, p, e, terms, x_int):
    x = GF(x_int)
    result = GF(0)
    for a, b, c_int in terms:
        result = result + GF(c_int) * x ** (p**a + p**b)
    return result

def build_quadratic_by_evaluation(GF, p, e, terms, h_int):
    n = e
    basis = []
    for j in range(e):
        v = np.zeros(e, dtype=np.int64)
        v[j] = 1
        val = sum(int(v[i]) * (p**i) for i in range(e))
        basis.append(GF(val))
    
    F_0_vec = np.zeros(e, dtype=np.int64)
    F_ej = []
    for j in range(e):
        val = eval_frobenius_sum(GF, p, e, terms, int(basis[j]))
        F_ej.append(np.array(val.vector(), dtype=np.int64))
    
    F_ei_ej = {}
    for i in range(e):
        for j in range(i+1, e):
            x_ij = int(basis[i] + basis[j])
            val = eval_frobenius_sum(GF, p, e, terms, x_ij)
            F_ei_ej[(i,j)] = np.array(val.vector(), dtype=np.int64)
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    const = np.zeros(e, dtype=np.int64)
    
    h = GF(h_int)
    h_vec = np.array(h.vector(), dtype=np.int64)
    inv2 = pow(2, p - 2, p)
    
    for eq in range(e):
        const[eq] = (-h_vec[eq]) % p
        for j in range(e):
            Q[eq, j, j] = int(F_ej[j][eq])
        for i in range(e):
            for j in range(i+1, e):
                cross = (int(F_ei_ej[(i,j)][eq]) - int(F_ej[i][eq]) - int(F_ej[j][eq])) % p
                cross = (cross * inv2) % p
                Q[eq, i, j] = cross
                Q[eq, j, i] = cross
    
    return Q, const

def validate_system(GF, p, e, terms, h_int, Q, const, n_tests=5):
    rng = random.Random(123)
    h = GF(h_int)
    for _ in range(n_tests):
        x_int = rng.randint(0, p**e - 1)
        F_val = eval_frobenius_sum(GF, p, e, terms, x_int)
        F_minus_h = F_val - h
        F_vec = np.array(F_minus_h.vector(), dtype=np.int64)
        
        x = GF(x_int)
        x_vec = np.array(x.vector(), dtype=np.int64)
        x_std = x_vec[::-1]  # Reverse: galois returns [alpha^{e-1},...,alpha^0]
        
        for eq in range(e):
            q_val = int(const[eq])
            for j in range(e):
                for k in range(e):
                    q_val += int(Q[eq, j, k]) * int(x_std[j]) * int(x_std[k])
            q_val %= p
            if q_val != int(F_vec[eq]):
                return False, f"Mismatch eq={eq} x={x_int}: got {q_val} expected {int(F_vec[eq])}"
    return True, "OK"

def generate_monomials(e, max_deg):
    mons = []
    for deg in range(max_deg, -1, -1):
        for combo in combinations_with_replacement(range(e), deg):
            mons.append(combo)
    return mons

def build_macaulay_fast(Q, const, e, d, p):
    """Build Macaulay matrix using numpy vectorization."""
    n = e
    col_mons = generate_monomials(e, d)
    n_cols = len(col_mons)
    col_idx = {m: i for i, m in enumerate(col_mons)}
    
    if d < 2:
        return np.zeros((0, n_cols), dtype=np.int64), col_mons, n_cols
    
    mult_mons = []
    for deg in range(d - 1):  # degree 0 to d-2
        for combo in combinations_with_replacement(range(n), deg):
            mult_mons.append(combo)
    
    n_rows = e * len(mult_mons)
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    
    # Pre-compute all products (j, k) -> sorted tuple
    # For each equation and multiplier, add Q[eq,j,k] to column of mult*(j,k)
    row = 0
    for eq_idx in range(e):
        Q_eq = Q[eq_idx]  # e x e matrix
        for mult in mult_mons:
            # Quadratic terms
            for j in range(n):
                for k in range(n):
                    coeff = int(Q_eq[j, k])
                    if coeff != 0:
                        prod = tuple(sorted(mult + (j, k)))
                        if prod in col_idx:
                            M[row, col_idx[prod]] = (M[row, col_idx[prod]] + coeff) % p
            # Constant term
            c = int(const[eq_idx])
            if c != 0 and mult in col_idx:
                M[row, col_idx[mult]] = (M[row, col_idx[mult]] + c) % p
            row += 1
    
    return M, col_mons, n_cols

def gauss_elim_mod_p(M, p):
    """Fast Gaussian elimination mod p using numpy."""
    M = M.copy() % p
    n_rows, n_cols = M.shape
    pivot_row = 0
    
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        # Find pivot
        col_data = M[pivot_row:, col] % p
        nonzero = np.where(col_data != 0)[0]
        if len(nonzero) == 0:
            continue
        
        idx = nonzero[0] + pivot_row
        # Swap
        M[[pivot_row, idx]] = M[[idx, pivot_row]]
        # Scale
        inv = pow(int(M[pivot_row, col]), p - 2, p)
        M[pivot_row] = (M[pivot_row] * inv) % p
        # Eliminate
        for r in range(n_rows):
            if r != pivot_row and M[r, col] % p != 0:
                factor = int(M[r, col])
                M[r] = (M[r] - factor * M[pivot_row]) % p
        pivot_row += 1
    
    return M[:pivot_row]

def detect_solving(reduced_M, col_mons, e, d, p):
    """Detect D_lin and D_uni from reduced matrix."""
    n_rows = reduced_M.shape[0]
    
    # Classify columns
    const_idx = None
    linear_cols = set()
    univar_cols = {}  # var -> set of col indices
    
    for i, m in enumerate(col_mons):
        if len(m) == 0:
            const_idx = i
        elif len(m) == 1:
            linear_cols.add(i)
            var = m[0]
            if var not in univar_cols:
                univar_cols[var] = set()
            univar_cols[var].add(i)
        elif len(set(m)) == 1:
            var = m[0]
            if var not in univar_cols:
                univar_cols[var] = set()
            univar_cols[var].add(i)
    
    # Add constant to linear and univariate allowed sets
    linear_allowed = linear_cols | ({const_idx} if const_idx is not None else set())
    for var in univar_cols:
        if const_idx is not None:
            univar_cols[var].add(const_idx)
    
    n_lin = 0
    n_uni = 0
    n_inc = 0
    
    for r in range(n_rows):
        row = reduced_M[r] % p
        nz = set(np.where(row != 0)[0])
        
        # Inconsistency
        if const_idx is not None and nz == {const_idx}:
            n_inc += 1
            continue
        
        # Linear
        if nz.issubset(linear_allowed):
            n_lin += 1
        
        # Univariate
        for var in range(e):
            if var in univar_cols and nz.issubset(univar_cols[var]):
                n_uni += 1
                break
    
    return n_lin > 0, n_uni > 0, n_lin, n_uni, n_inc

def run_experiment(p, e, schedule, max_d=None):
    GF = galois.GF(p**e)
    rng = random.Random(42)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    
    if max_d is None:
        max_d = e + 2
    
    pairs_to_cancel = list(combinations(range(5), 2))
    
    print(f"{'='*90}")
    print(f"XL Solving Degree: p={p}, e={e}")
    print(f"Schedule: {schedule}")
    print(f"{'='*90}")
    print(f"{'Cancel':>8s} | {'Residual':>30s} | {'D_lin':>6s} | {'D_uni':>6s} | {'Incons':>6s} | {'Note':>20s}")
    print("-" * 90)
    
    results = []
    
    for cancel_pair in pairs_to_cancel:
        residual_indices = [k for k in range(5) if k not in cancel_pair]
        residual_pairs = [schedule[k] for k in residual_indices]
        
        rng_coeff = random.Random(hash(cancel_pair) % 2**32)
        terms = []
        for a, b in residual_pairs:
            c_int = int(GF(rng_coeff.randint(1, p**e - 1)))
            terms.append((a, b, c_int))
        
        h_val = GF(0)
        for a, b, c_int in terms:
            h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
        h_int = int(h_val)
        
        Q, const = build_quadratic_by_evaluation(GF, p, e, terms, h_int)
        
        valid, msg = validate_system(GF, p, e, terms, h_int, Q, const)
        if not valid:
            print(f"{str(cancel_pair):>8s} | {str(residual_pairs):>30s} | {'FAIL':>6s} | {'FAIL':>6s} | {'FAIL':>6s} | {msg[:20]:>20s}")
            results.append((cancel_pair, residual_pairs, None, None, False, msg))
            continue
        
        d_lin = None
        d_uni = None
        inconsistent = False
        
        for d in range(2, max_d + 1):
            t0 = time.time()
            M, col_mons, n_cols = build_macaulay_fast(Q, const, e, d, p)
            if M.shape[0] == 0:
                continue
            
            t1 = time.time()
            reduced = gauss_elim_mod_p(M, p)
            t2 = time.time()
            
            rank = reduced.shape[0]
            found_lin, found_uni, n_lin, n_uni, n_inc = detect_solving(reduced, col_mons, e, d, p)
            
            if n_inc > 0:
                inconsistent = True
            
            if found_lin and d_lin is None:
                d_lin = d
            if found_uni and d_uni is None:
                d_uni = d
            
            elapsed = t2 - t0
            
            # Stop conditions
            if d_lin is not None and d_uni is not None:
                break
            if n_cols > 3000:
                break
            if elapsed > 60:
                break
        
        note = "INCONSISTENT" if inconsistent else ("not found" if d_uni is None else "")
        d_lin_s = str(d_lin) if d_lin is not None else "-"
        d_uni_s = str(d_uni) if d_uni is not None else "-"
        inc_s = "YES" if inconsistent else "no"
        
        print(f"{str(cancel_pair):>8s} | {str(residual_pairs):>30s} | {d_lin_s:>6s} | {d_uni_s:>6s} | {inc_s:>6s} | {note:>20s}")
        results.append((cancel_pair, residual_pairs, d_lin, d_uni, inconsistent, note))
    
    print()
    d_lins = [r[2] for r in results if r[2] is not None]
    d_unis = [r[3] for r in results if r[3] is not None]
    n_inc = sum(1 for r in results if r[4])
    
    print(f"Summary: D_lin=[{min(d_lins) if d_lins else '-'},{max(d_lins) if d_lins else '-'}] "
          f"D_uni=[{min(d_unis) if d_unis else '-'},{max(d_unis) if d_unis else '-'}] "
          f"Incons={n_inc}/{len(results)} "
          f"Attacker best D_uni={min(d_unis) if d_unis else 'not found'}")
    
    return results

if __name__ == "__main__":
    # Test 1: p=3, e=5
    schedule_5 = [(0,1),(1,2),(2,3),(3,4),(4,0)]
    run_experiment(3, 5, schedule_5, max_d=8)
    print()
    
    # Test 2: p=5, e=5
    run_experiment(5, 5, schedule_5, max_d=8)
    print()
    
    # Test 3: p=3, e=7
    schedule_7 = [(0,1),(1,2),(2,3),(3,4),(4,5)]
    run_experiment(3, 7, schedule_7, max_d=8)
