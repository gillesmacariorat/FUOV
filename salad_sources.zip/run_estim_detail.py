"""Get detailed algorithm breakdown for SALAD parameters."""
from cryptographic_estimators.MQEstimator import MQEstimator
from cryptographic_estimators.UOVEstimator import UOVEstimator

for level, (p, e) in [('I', (31, 61)), ('III', (61, 89)), ('V', (61, 127))]:
    n_vars = 5 * e
    print(f"=== Level {level}: p={p}, e={e}, n={n_vars}, m={e} ===")
    
    MQE = MQEstimator(n=n_vars, m=e, q=p)
    print("MQ algorithms:")
    MQE.table()
    print()
    
    UOVE = UOVEstimator(n=n_vars, m=e, q=p)
    print("UOV algorithms:")
    UOVE.table()
    print()

