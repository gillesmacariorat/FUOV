"""
Verify: is the 140 deficiency at d=4 generic or an artifact?
Test with m=3, n=15 (smaller, same ratio) where prediction is 3 syzygies.
Also test with TRULY random dense equations (all 325 terms, random coefficients).
"""
import numpy as np
import random
from itertools import combinations_with_replacement
from math import comb
import time

def gaussian_rank_mod_p(M, p):
    M = M.copy() % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = None
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot is None:
            continue
        M[[rank, pivot]] = M[[pivot, rank]]
        inv = pow(int(M[rank, col] % p), p - 2, p)
        M[rank] = (M[rank] * inv) % p
        for row in range(rows):
            if row != rank and M[row, col] % p != 0:
                M[row] = (M[row] - M[row, col] * M[rank]) % p
        rank += 1
        if rank >= rows:
            break
    return rank

def build_and_test(m, n, p, d, n_terms, seed):
    """Build Macaulay matrix with random dense equations and compute rank."""
    rng = random.Random(seed)
    
    # Build monomial index
    monomials = []
    for deg in range(d + 1):
        for combo in combinations_with_replacement(range(n), deg):
            monomials.append(combo)
    monomial_index = {m: i for i, m in enumerate(monomials)}
    
    n_rows = m * comb(n + d - 2, d - 2)
    n_cols = comb(n + d, d)
    
    # Generate equations with ALL possible quadratic terms
    all_quad_monomials = []
    for j in range(n):
        for l in range(j, n):
            all_quad_monomials.append((j, l))
    
    # Generate m equations, each with ALL quadratic terms
    equations = []
    for k in range(m):
        eq = {}
        for mono in all_quad_monomials:
            eq[mono] = rng.randint(1, p - 1)
        equations.append(eq)
    
    # Build Macaulay matrix
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    row_idx = 0
    for eq in equations:
        for extra in combinations_with_replacement(range(n), d - 2):
            for mono, coeff in eq.items():
                full_mono = tuple(sorted(list(mono) + list(extra)))
                col_idx = monomial_index.get(full_mono)
                if col_idx is not None:
                    M[row_idx, col_idx] = (M[row_idx, col_idx] + coeff) % p
            row_idx += 1
    
    rank = gaussian_rank_mod_p(M, p)
    deficiency = min(n_rows, n_cols) - rank
    return rank, deficiency, n_rows, n_cols

# Test 1: m=3, n=15, d=4 (predicted syzygies: 3)
print("=== m=3, n=15, d=4 (predicted syzygies: C(3,2)=3) ===")
for seed in range(3):
    rank, deficiency, nr, nc = build_and_test(3, 15, 31, 4, None, seed)
    print(f"  seed {seed}: rank={rank}/{min(nr,nc)}, def={deficiency}")

print()

# Test 2: m=5, n=25, d=4 with FULL density (all 325 terms)
print("=== m=5, n=25, d=4, FULL density (325 terms/eq) ===")
for seed in range(3):
    rank, deficiency, nr, nc = build_and_test(5, 25, 31, 4, None, seed)
    print(f"  seed {seed}: rank={rank}/{min(nr,nc)}, def={deficiency}")

print()

# Test 3: m=5, n=5, d=4 (square system, predicted: 10)
print("=== m=5, n=5, d=4 (square, predicted syzygies: 10) ===")
for seed in range(3):
    rank, deficiency, nr, nc = build_and_test(5, 5, 31, 4, None, seed)
    print(f"  seed {seed}: rank={rank}/{min(nr,nc)}, def={deficiency}")

