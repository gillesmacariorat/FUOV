# SALAD Security Analysis — Source Archive

This archive contains the complete LaTeX source, compiled PDF, and Python
scripts for the security analysis of the SALAD diagonal variant of UFOs.

## Contents

### Report
- `report.tex` — LaTeX source (compile with `pdflatex report.tex`)
- `report.pdf` — Compiled report (24 pages)

### Cryptographic Estimators
- `estim.py` — Original script (by G. Macario-Rat): iterates over a parameter
  list of (p, e, NIST-level) triples and runs `MQEstimator` and `UOVEstimator`
  from the `cryptographic_estimators` library. For each parameter set, it
  constructs the forgery system as an MQ problem with n=5e variables and m=e
  equations over F_p, prints the fastest algorithm and its time complexity.
  Output goes to stdout (redirect to a file by uncommenting the `f = open(...)`
  line). This is the reference script from which `run_estim.py` was derived.
- `run_estim.py` — Extended version: runs `cryptographic_estimators` for SALAD
  parameters (Levels I, III, V) in addition to the original parameter set.
  Produces full MQEstimator and UOVEstimator tables with all algorithm costs.
- `run_estim_detail.py` — Detailed algorithm breakdown (full tables) for SALAD.
- `run_estim_orig.py` — Estimators for the original parameter set only.

#### Dependencies for estimator scripts

```
pip install cryptographic-estimators
```

This installs the following transitive dependencies:
- `sympy` (>=1.12) — symbolic Hilbert series computation
- `python-flint` (>=0.9) — fast FLINT arithmetic for polynomial operations
- `mpmath` (>=1.3) — arbitrary-precision floating point
- `scipy` — numerical utilities
- `prettytable` — formatted table output
- `pyyaml` — configuration parsing
- `numpy` — array operations (used by other scripts in this archive)

The `cryptographic_estimators` library (v2.1.1) is available at:
https://github.com/crypto-ig/cryptographic_estimators

### Hardened Schedule Optimization (3-stage pipeline)
- `compute_all_w3.py` — Stage 1: w3 precomputation and quintuplet filtering.
  Generates all valid exponent quintuplets and computes w3 (3-term window)
  diagnostics. Reads JSON schedule files for Level I/III/V.
- `deltas_points_2.py` — Stage 2: shift optimization for linear span L.
  Optimizes the shift parameters of each quintuplet to maximize the linear
  span L (Frobenius window coverage).
- `post_process_2.py` — Stage 3: full diagnostic certification. Computes
  w_t scores, Bézout bounds B_t, and R_eff for the best schedules.

  Pipeline: `python compute_all_w3.py && python deltas_points_2.py && python post_process_2.py`

### XL Solving Degree Analysis
- `xl_solving_degree.py` — XL solving degree computation for the e×e square
  system. Computes the Macaulay matrix crossover degree and XL work estimate.
- `xl_full.py` — Full XL experiment with exact rank computation.
- `xl_fast.py` — Optimized XL using sparse Gaussian elimination.
- `xl_ufos_real.py` — XL on real UFOs Level I parameters (e=61).
- `xl_ufos_real_v2.py` — Improved version with constraint matrix analysis.
- `xl_ufos_real_c.py` — Version with C-accelerated rank computation.
- `xl_ufos_sparse.py` — Sparse matrix version for large parameters.
- `xl_ufos_gram.py` — Gram matrix (C^T C) approach (note: incorrect over F_p).
- `xl_ufos_syzygy.py` — Syzygy analysis at degree d=4 for UFOs schedules.

### Forgery System Analysis
- `forgery_keyrec_v3.py` — Main experiment: builds Macaulay matrices for both
  the forgery system (e eqs, 5e vars) and key recovery system (5e eqs, 4e vars),
  diagonal vs dense. Computes exact rank over F_p at degrees d=2,3,4.
- `forgery_keyrec_v2.py` — Earlier version with Frobenius structure.
- `forgery_keyrec_experiments.py` — Extended experiments across multiple seeds.
- `check_forgery_d4.py` — Checks d=4 syzygies comparing diagonal, dense, and
  generic random MQ systems. Verifies semi-regularity assumption.
- `check_forgery_d4_v3.py` — Version with dense (300-term) equations.
- `verify_d4_generic.py` — Verifies generic syzygy count across m,n values.

### Syzygy and Structure Analysis
- `koszul_verify.py` — Verifies Koszul syzygy decomposition at d=4 (block-
  redundancy + Koszul) for the key recovery system.
- `pattern_experiments.py` — Experiments on rank deficiency patterns across
  seeds, primes, and extension degrees.
- `dreg_experiment.py` — Degree of regularity experiments for small e.
- `cascade_experiment.py` — Cascade analysis of syzygy propagation.

### Finite Field Utilities
- `centralizer_fq_exact.py` — Exact computation of the centralizer group in
  GL(e, F_p) for Frobenius structure analysis.
- `idempotents_fq_exact.py` — Exact idempotent computation in F_{p^e}.
- `block_degree_profile.py` — Block degree profile analysis for diagonal vs
  dense Macaulay matrices.
- `sparse_gauss.py` — Sparse Gaussian elimination mod p (utility library).

### Helper Scripts
- `run_all.sh` — Runs the full experimental pipeline end-to-end.

## Prerequisites

```
pip install numpy cryptographic-estimators
```

The `cryptographic_estimators` package (v2.1.1) pulls in `sympy`,
`python-flint`, `mpmath`, `scipy`, `prettytable`, and `pyyaml` automatically.
See the "Dependencies for estimator scripts" section above for details.

For LaTeX compilation:
```
pdflatex report.tex
```

## Key Results

| Level | p  | e   | Best MQ algo    | Cost    | Target  | Margin    |
|-------|----|-----|-----------------|---------|---------|-----------|
| I     | 31 | 61  | PXL             | 2^154   | 2^128   | 26 bits   |
| III   | 61 | 89  | PXL             | 2^236   | 2^192   | 44 bits   |
| V     | 61 | 127 | BooleanSolveFXL | 2^327   | 2^256   | 71 bits   |

All estimates remain above the security thresholds. The forgery system
behaves identically to a generic MQ system (verified at d=4).
