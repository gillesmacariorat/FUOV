#from cryptographic_estimators.SDEstimator import SDEstimator
import sys

from cryptographic_estimators.UOVEstimator import UOVEstimator
#from cryptographic_estimators.MREstimator import MREstimator
from cryptographic_estimators.MQEstimator import MQEstimator
#f = open('workfile', 'w', encoding="utf-8")
o=sys.stdout
try: 
    #f = open('output_135.txt', 'w', encoding="utf-8")
    f = o
except Exception as e:
    print(f"An error occurred while opening the file: {e}") 
    exit(1)
sys.stdout = f
#exit(0)
print("Hello, World!")

for pe in [
[ 31 , 59 , 143],
[ 37 , 59 , 143],
[ 43 , 59 , 143],
[ 31 , 61 , 143],
[ 53 , 79 , 207],
[ 59 , 79 , 207],
[ 61 , 79 , 207],
[ 97 , 101 , 272],
[ 101 , 101 , 272],
[ 71 , 103 , 272],
[ 73 , 103 , 272]
]:
    p=pe[0]
    e=pe[1]
    v = 4
    n = v + 1
    ell = 5
    #MRE = MREstimator(q=p, m=ell*e, n=v*e+1, k=v*e, r=v*e)
    #print ("MR",p, ell*e, v*e+1, v*e, v*e)
    #MRE.table()

    print (p, e, "start")
    #print ("MQ",e*n,e,p)
    try:
        MQE = MQEstimator(n=e*n, m=e, q=p)
        #MQE.table()
        print(MQE.fastest_algorithm().time_complexity())
    except Exception as e:
        print(f"An error occurred while generating the MQ table: {e}")
        sys.stdout = o
        print(f"An error occurred while generating the MQ table: {e}")
    sys.stdout = f


    #print ("UOV",n*e,e,p)
    try:
        UOVE = UOVEstimator(n=n*e,m=e,q=p)
        #UOVE.table()
        print(UOVE.fastest_algorithm().time_complexity())
    except Exception as e:
        print(f"An error occurred while generating the UOV table: {e}")
        sys.stdout = o
        print(f"An error occurred while generating the UOV table: {e}")
    sys.stdout = f

print("Bye, World!")
f.close()
sys.stdout = o
