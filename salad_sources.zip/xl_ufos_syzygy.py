"""
XL D_lin/D_uni measurement for real UFOs parameters via syzygy approach.

Instead of building the full Macaulay matrix, we compute:
1. D_lin=3: Find degree-1 syzygies of the quadratic system.
   - Build constraint matrix C: rows = cubic monomials, cols = a_{ij}
   - ker(C) gives syzygies. For each syzygy, check if linear part L_a != 0.
2. D_uni=3: Find syzygies with support constraint (only {1, x_v, x_v^2, x_v^3}).

For e=11,13: dense computation.
For e=61,89,127: sparse/incremental approach.
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time, sys
from math import comb

def eval_frobenius_sum(GF, p, e, terms, x_int):
    x = GF(x_int)
    result = GF(0)
    for a, b, c_int in terms:
        result = result + GF(c_int) * x ** (p**a + p**b)
    return result

def build_quad_frobenius(GF, p, e, terms, h_int):
    """Build quadratic system Q[eq,j,k], const[eq] by evaluation."""
    basis = []
    for j in range(e):
        v = np.zeros(e, dtype=np.int64)
        v[j] = 1
        val = sum(int(v[i]) * (p**i) for i in range(e))
        basis.append(GF(val))
    
    F_ej = [np.array(eval_frobenius_sum(GF, p, e, terms, int(basis[j])).vector(), dtype=np.int64)
            for j in range(e)]
    F_ei_ej = {}
    for i in range(e):
        for j in range(i+1, e):
            F_ei_ej[(i,j)] = np.array(
                eval_frobenius_sum(GF, p, e, terms, int(basis[i] + basis[j])).vector(),
                dtype=np.int64)
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    const = np.zeros(e, dtype=np.int64)
    h_vec = np.array(GF(h_int).vector(), dtype=np.int64)
    inv2 = pow(2, p-2, p)
    
    for eq in range(e):
        const[eq] = (-h_vec[eq]) % p
        for j in range(e):
            Q[eq, j, j] = int(F_ej[j][eq])
        for i in range(e):
            for j in range(i+1, e):
                cross = (int(F_ei_ej[(i,j)][eq]) - int(F_ej[i][eq]) - int(F_ej[j][eq])) % p
                cross = (cross * inv2) % p
                Q[eq, i, j] = cross
                Q[eq, j, i] = cross
    return Q, const

def build_cubic_constraint_matrix(Q, e, p):
    """Build constraint matrix C for degree-1 syzygies.
    
    Rows: cubic monomials (a,b,c) with a<=b<=c
    Cols: unknowns a_{ij} for i=0..e-1, j=0..e-1 (indexed as i*e + j)
    
    Entry C[(a,b,c), (i,j)] = coefficient of x_a*x_b*x_c in x_j * f_i^{(2)}(x)
    """
    # Generate cubic monomials
    cubic_mons = []
    for combo in combinations_with_replacement(range(e), 3):
        cubic_mons.append(combo)
    
    n_rows = len(cubic_mons)
    n_cols = e * e
    
    # Build sparse: for each row, store (col_idx, value) pairs
    # Each row involves at most 3*e nonzeros (j=a, j=b, j=c, each with e values of i)
    
    # Use dense for small e, sparse for large e
    if n_rows * n_cols < 5_000_000:
        C = np.zeros((n_rows, n_cols), dtype=np.int64)
        
        for row_idx, (a, b, c) in enumerate(cubic_mons):
            for i in range(e):
                # j = a: coefficient of x_a in x_a * f_i, times coefficient of x_b*x_c in f_i
                if a == b == c:
                    # x_a * x_a * x_a: j=a, k=l=a → Q[i,a,a]
                    C[row_idx, i*e + a] = (C[row_idx, i*e + a] + int(Q[i, a, a])) % p
                elif a == b:
                    # x_a * x_a * x_c: j=a gives k=l=a → Q[i,a,a]; j=c gives k=l=a → Q[i,a,a]
                    C[row_idx, i*e + a] = (C[row_idx, i*e + a] + int(Q[i, a, a])) % p
                    C[row_idx, i*e + c] = (C[row_idx, i*e + c] + int(Q[i, a, a])) % p
                elif b == c:
                    # x_a * x_b * x_b: j=a gives k=l=b → Q[i,b,b]; j=b gives k=a,l=b → 2*Q[i,a,b]
                    C[row_idx, i*e + a] = (C[row_idx, i*e + a] + int(Q[i, b, b])) % p
                    C[row_idx, i*e + b] = (C[row_idx, i*e + b] + 2 * int(Q[i, a, b])) % p
                else:
                    # a < b < c: j=a → 2*Q[i,b,c]; j=b → 2*Q[i,a,c]; j=c → 2*Q[i,a,b]
                    C[row_idx, i*e + a] = (C[row_idx, i*e + a] + 2 * int(Q[i, b, c])) % p
                    C[row_idx, i*e + b] = (C[row_idx, i*e + b] + 2 * int(Q[i, a, c])) % p
                    C[row_idx, i*e + c] = (C[row_idx, i*e + c] + 2 * int(Q[i, a, b])) % p
        
        C %= p
        return C, cubic_mons
    else:
        # Sparse representation: list of (row_idx, col_idx, value)
        print(f"  Using sparse mode: {n_rows} rows x {n_cols} cols")
        # Return as list of sparse rows
        sparse_rows = []
        for row_idx, (a, b, c) in enumerate(cubic_mons):
            entries = {}
            for i in range(e):
                if a == b == c:
                    col = i*e + a
                    entries[col] = (entries.get(col, 0) + int(Q[i, a, a])) % p
                elif a == b:
                    col_a = i*e + a
                    col_c = i*e + c
                    entries[col_a] = (entries.get(col_a, 0) + int(Q[i, a, a])) % p
                    entries[col_c] = (entries.get(col_c, 0) + int(Q[i, a, a])) % p
                elif b == c:
                    col_a = i*e + a
                    col_b = i*e + b
                    entries[col_a] = (entries.get(col_a, 0) + int(Q[i, b, b])) % p
                    entries[col_b] = (entries.get(col_b, 0) + 2 * int(Q[i, a, b])) % p
                else:
                    col_a = i*e + a
                    col_b = i*e + b
                    col_c = i*e + c
                    entries[col_a] = (entries.get(col_a, 0) + 2 * int(Q[i, b, c])) % p
                    entries[col_b] = (entries.get(col_b, 0) + 2 * int(Q[i, a, c])) % p
                    entries[col_c] = (entries.get(col_c, 0) + 2 * int(Q[i, a, b])) % p
            # Remove zeros
            entries = {k: v % p for k, v in entries.items() if v % p != 0}
            sparse_rows.append(entries)
        
        return sparse_rows, cubic_mons

def gauss_elim_dense(M, p):
    """Gaussian elimination on dense matrix mod p. Returns reduced row echelon form."""
    M = M.copy() % p
    n_rows, n_cols = M.shape
    pivot_row = 0
    pivots = []
    
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        col_data = M[pivot_row:, col] % p
        nonzero = np.where(col_data != 0)[0]
        if len(nonzero) == 0:
            continue
        idx = nonzero[0] + pivot_row
        M[[pivot_row, idx]] = M[[idx, pivot_row]]
        inv = pow(int(M[pivot_row, col]), p-2, p)
        M[pivot_row] = (M[pivot_row] * inv) % p
        for r in range(n_rows):
            if r != pivot_row and M[r, col] % p != 0:
                M[r] = (M[r] - int(M[r, col]) * M[pivot_row]) % p
        pivots.append(col)
        pivot_row += 1
    
    return M[:pivot_row], pivots

def gauss_elim_sparse(sparse_rows, n_cols, p):
    """Incremental Gaussian elimination on sparse rows mod p.
    Returns list of pivot rows (as dense vectors) and pivot columns.
    """
    pivots = []  # list of (pivot_col, dense_row)
    pivot_cols = []
    
    for row_idx, row in enumerate(sparse_rows):
        if row_idx % 5000 == 0:
            print(f"    Processing row {row_idx}/{len(sparse_rows)}, {len(pivots)} pivots so far")
        
        # Reduce current row against existing pivots
        current = dict(row)  # sparse row as dict
        
        for pc, prow in pivots:
            if pc in current:
                factor = current[pc]
                if factor != 0:
                    # Subtract factor * prow from current
                    for col, val in prow.items():
                        current[col] = (current.get(col, 0) - factor * val) % p
                    # Remove zeros
                    current = {k: v % p for k, v in current.items() if v % p != 0}
        
        # Find pivot
        if current:
            # Find leftmost nonzero column
            pc = min(current.keys())
            if current[pc] != 0:
                # Normalize
                inv = pow(current[pc], p-2, p)
                current = {k: (v * inv) % p for k, v in current.items()}
                pivots.append((pc, current))
                pivot_cols.append(pc)
    
    return pivots, pivot_cols

def extract_kernel_dense(C, p):
    """Extract kernel of dense matrix C mod p."""
    n_rows, n_cols = C.shape
    rref, pivot_cols = gauss_elim_dense(C, p)
    rank = len(pivot_cols)
    free_cols = [j for j in range(n_cols) if j not in pivot_cols]
    
    kernel_vectors = []
    for fc in free_cols:
        v = np.zeros(n_cols, dtype=np.int64)
        v[fc] = 1
        for i, pc in enumerate(pivot_cols):
            v[pc] = (-int(rref[i, fc])) % p
        kernel_vectors.append(v)
    
    return kernel_vectors, rank

def extract_kernel_sparse(pivots, pivot_cols, n_cols, p):
    """Extract kernel from sparse RREF."""
    rank = len(pivot_cols)
    free_cols = [j for j in range(n_cols) if j not in pivot_cols]
    
    kernel_vectors = []
    for fc in free_cols:
        v = np.zeros(n_cols, dtype=np.int64)
        v[fc] = 1
        for i, (pc, prow) in enumerate(pivots):
            if fc in prow:
                v[pc] = (-prow[fc]) % p
        kernel_vectors.append(v)
    
    return kernel_vectors, rank

def check_dlin(Q, const, e, p, kernel_vectors):
    """For each syzygy, compute linear part and check if nonzero."""
    dlin_relations = []
    
    for kv in kernel_vectors:
        # kv is indexed as i*e + j
        # Linear part: L_a(x) = -sum_{i,j} a_{ij} * h_i * x_j
        # = -sum_j (sum_i a_{ij} * h_i) * x_j
        linear_coeffs = np.zeros(e, dtype=np.int64)
        for j in range(e):
            s = 0
            for i in range(e):
                s += int(kv[i*e + j]) * int(const[i])
            linear_coeffs[j] = (-s) % p
        
        if np.any(linear_coeffs % p != 0):
            dlin_relations.append(linear_coeffs % p)
    
    return dlin_relations

def check_duni(Q, const, e, p, kernel_vectors, cubic_mons):
    """For each syzygy, check if the resulting relation is univariate in some x_v.
    
    The relation from syzygy a is:
    - Cubic part: 0 (by construction)
    - Linear part: L_a(x) = -sum_{i,j} a_{ij} h_i x_j
    - But we also need to account for the full degree-3 Macaulay, which includes
      degree-0 multipliers (original equations). The D_uni check requires that
      the relation is supported on {1, x_v, x_v^2, x_v^3} only.
    
    For the syzygy approach, we only have degree-1 multipliers, so the relation
    has only linear terms. A univariate linear relation is already a D_uni=3
    if it involves only one variable.
    
    Actually, D_uni requires a relation in {1, x_v, x_v^2, x_v^3}. Since our
    syzygy gives a linear form, it's univariate if only one x_j appears.
    But we should also check if combining with degree-0 multiplier rows
    (quadratic equations) can produce a higher-degree univariate relation.
    
    For now, check if the linear form is univariate.
    """
    duni_relations = []
    
    for kv in kernel_vectors:
        linear_coeffs = np.zeros(e, dtype=np.int64)
        for j in range(e):
            s = 0
            for i in range(e):
                s += int(kv[i*e + j]) * int(const[i])
            linear_coeffs[j] = (-s) % p
        
        nz_vars = np.where(linear_coeffs % p != 0)[0]
        if len(nz_vars) == 1:
            var = nz_vars[0]
            duni_relations.append((var, linear_coeffs))
    
    return duni_relations

def run_syzygy_test(p, e, schedule, cancel_pair, seed=42, use_sparse=None):
    """Run D_lin/D_uni syzygy test for one triplet."""
    GF = galois.GF(p**e)
    
    if use_sparse is None:
        use_sparse = (e > 15)
    
    residual = [schedule[k] for k in range(5) if k not in cancel_pair]
    
    rng = random.Random(seed)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    
    rng_c = random.Random(hash(cancel_pair) % 2**32 + seed * 7919)
    terms = []
    for a, b in residual:
        c_int = int(GF(rng_c.randint(1, p**e - 1)))
        terms.append((a, b, c_int))
    
    h_val = GF(0)
    for a, b, c_int in terms:
        h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
    h_int = int(h_val)
    
    Q, const = build_quad_frobenius(GF, p, e, terms, h_int)
    
    # Build constraint matrix
    t0 = time.time()
    if use_sparse:
        sparse_rows, cubic_mons = build_cubic_constraint_matrix(Q, e, p)
        n_rows = len(sparse_rows)
        n_cols = e * e
        t1 = time.time()
        print(f"  Constraint matrix: {n_rows} rows x {n_cols} cols (sparse), build={t1-t0:.1f}s")
        
        # Incremental Gaussian elimination
        pivots, pivot_cols = gauss_elim_sparse(sparse_rows, n_cols, p)
        rank = len(pivot_cols)
        t2 = time.time()
        print(f"  Rank: {rank}/{n_cols}, kernel dim: {n_cols - rank}, gauss={t2-t1:.1f}s")
        
        kernel_vectors, _ = extract_kernel_sparse(pivots, pivot_cols, n_cols, p)
    else:
        C, cubic_mons = build_cubic_constraint_matrix(Q, e, p)
        n_rows, n_cols = C.shape
        t1 = time.time()
        print(f"  Constraint matrix: {n_rows} rows x {n_cols} cols (dense), build={t1-t0:.1f}s")
        
        kernel_vectors, rank = extract_kernel_dense(C, p)
        t2 = time.time()
        print(f"  Rank: {rank}/{n_cols}, kernel dim: {n_cols - rank}, gauss={t2-t1:.1f}s")
    
    t3 = time.time()
    
    # Check D_lin
    dlin_rels = check_dlin(Q, const, e, p, kernel_vectors)
    
    # Check D_uni
    duni_rels = check_duni(Q, const, e, p, kernel_vectors, cubic_mons)
    
    t4 = time.time()
    
    # Validate D_lin relations at x0
    x0_std = np.array(GF(x0_int).vector(), dtype=np.int64)[::-1]
    validated = 0
    for rel in dlin_rels:
        val = 0
        for j in range(e):
            val += int(rel[j]) * int(x0_std[j])
        val %= p
        if val == 0:
            validated += 1
    
    result = {
        'cancel': cancel_pair,
        'residual': residual,
        'kernel_dim': n_cols - rank,
        'dlin_count': len(dlin_rels),
        'duni_count': len(duni_rels),
        'dlin_validated': validated,
        'dlin': 3 if dlin_rels else None,
        'duni': 3 if duni_rels else None,
    }
    
    print(f"  D_lin={'3' if dlin_rels else 'not found'} ({len(dlin_rels)} relations, {validated} validated at x0)")
    print(f"  D_uni={'3' if duni_rels else 'not found'} ({len(duni_rels)} univariate)")
    
    return result

def main():
    # UFOs schedules
    ufos_schedules = {
        'Level I (e=61)': {
            'p': 31, 'e': 61,
            'schedule': [(0,9),(7,54),(13,29),(15,37),(35,47)],
        },
        'Level III (e=89)': {
            'p': 61, 'e': 89,
            'schedule': [(0,13),(28,43),(40,61),(52,84),(53,76)],
        },
        'Level V (e=127)': {
            'p': 61, 'e': 127,
            'schedule': [(0,2),(22,83),(29,74),(53,79),(94,111)],
        },
    }
    
    # Small UFOs schedule tests (e=11, 13)
    small_tests = [
        ('UFOs e=11', 3, 11, [(0,9%11),(7,54%11),(13%11,29%11),(15%11,37%11),(35%11,47%11)]),
        ('UFOs e=13', 3, 13, [(0,9%13),(7,54%13),(13%13,29%13),(15%13,37%13),(35%13,47%13)]),
    ]
    
    pairs = list(combinations(range(5), 2))
    
    # === Small tests ===
    for name, p, e, schedule in small_tests:
        print(f"\n{'='*80}")
        print(f"{name}: p={p}, e={e}")
        print(f"Schedule: {schedule}")
        print(f"{'='*80}")
        
        all_dlin = True
        duni_count = 0
        
        for cancel in pairs:
            print(f"\n  Cancel {cancel}:")
            result = run_syzygy_test(p, e, schedule, cancel, seed=42)
            if result['dlin'] is None:
                all_dlin = False
            if result['duni'] is not None:
                duni_count += 1
        
        print(f"\n  Summary: D_lin=3 {'always' if all_dlin else 'NOT always'}, "
              f"D_uni=3 for {duni_count}/10 triplets")
    
    # === Real UFOs Level I (e=61) ===
    print(f"\n{'='*80}")
    print(f"REAL UFOs Level I: p=31, e=61")
    print(f"Schedule: {ufos_schedules['Level I (e=61)']['schedule']}")
    print(f"{'='*80}")
    
    p1 = ufos_schedules['Level I (e=61)']
    
    # Test one triplet first
    cancel = (0, 1)
    print(f"\n  Cancel {cancel}:")
    result = run_syzygy_test(p1['p'], p1['e'], p1['schedule'], cancel, seed=42, use_sparse=True)
    
    if result['dlin'] is not None:
        print(f"\n  D_lin=3 confirmed for Level I! Testing more triplets...")
        all_dlin = True
        duni_count = 0
        
        for cancel in pairs:
            print(f"\n  Cancel {cancel}:")
            result = run_syzygy_test(p1['p'], p1['e'], p1['schedule'], cancel, seed=42, use_sparse=True)
            if result['dlin'] is None:
                all_dlin = False
            if result['duni'] is not None:
                duni_count += 1
        
        print(f"\n  Summary Level I: D_lin=3 {'always' if all_dlin else 'NOT always'}, "
              f"D_uni=3 for {duni_count}/10 triplets")
    
if __name__ == "__main__":
    main()
