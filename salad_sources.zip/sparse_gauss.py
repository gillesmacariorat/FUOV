"""
Sparse Gaussian elimination mod p for computing rank of large Macaulay matrices.
Uses dict-of-dicts representation: each row is a dict {col: value}.
"""
import numpy as np
from collections import defaultdict
import time

def sparse_rank(rows_data, n_cols, p, verbose=True):
    """
    Compute rank of a sparse matrix over F_p.
    
    rows_data: list of dicts, each dict maps col_idx -> value (mod p)
    n_cols: number of columns
    p: prime
    """
    n_rows = len(rows_data)
    t0 = time.time()
    
    # Convert to list of dicts (mutable copies)
    rows = [dict(r) for r in rows_data]
    
    pivot_row = [None] * n_cols  # pivot_row[col] = row index that has this pivot
    rank = 0
    
    for i in range(n_rows):
        row = rows[i]
        if not row:
            continue
        
        # Find leftmost nonzero column
        while True:
            if not row:
                break
            col = min(row.keys())
            val = row[col]
            if val % p == 0:
                del row[col]
                continue
            
            # Check if this column already has a pivot
            pr = pivot_row[col]
            if pr is not None:
                # Eliminate using pivot row
                pivot = rows[pr]
                # val = row[col], pivot[col] = pivot_val
                pivot_val = pivot[col]  # should be nonzero mod p
                # factor = val / pivot_val mod p = val * inverse(pivot_val) mod p
                inv_pv = pow(int(pivot_val) % p, p - 2, p)
                factor = (int(val) * inv_pv) % p
                
                # row = row - factor * pivot (mod p)
                for c, v in pivot.items():
                    new_val = (int(row.get(c, 0)) - factor * int(v)) % p
                    if new_val == 0:
                        row.pop(c, None)
                    else:
                        row[c] = new_val
                continue  # re-check the same column
            else:
                # This is a new pivot
                # Normalize: make pivot value 1
                inv_val = pow(int(val) % p, p - 2, p)
                for c in row:
                    row[c] = (int(row[c]) * inv_val) % p
                
                pivot_row[col] = i
                rank += 1
                break
        
        if verbose and (i + 1) % 500 == 0:
            elapsed = time.time() - t0
            print(f"  Row {i+1}/{n_rows}, rank={rank}, {elapsed:.1f}s", flush=True)
    
    elapsed = time.time() - t0
    if verbose:
        print(f"  Final: rank={rank}/{n_rows}, {elapsed:.1f}s", flush=True)
    return rank


def build_macaulay_sparse(Q, L, c, n_vars, n_eqs, p, degree):
    """
    Build Macaulay matrix at given degree and return as list of dicts (sparse rows).
    """
    def generate_monomials(n, d):
        """Generate exponent vectors of length n with total degree d."""
        monos = []
        def gen(idx, remaining, current):
            if idx == n:
                monos.append(tuple(current))
                return
            for deg in range(remaining + 1):
                current.append(deg)
                gen(idx + 1, remaining - deg, current)
                current.pop()
        gen(0, d, [])
        return monos
    
    all_monos = generate_monomials(n_vars, degree)
    mono_to_idx = {m: i for i, m in enumerate(all_monos)}
    n_cols = len(all_monos)
    
    if degree < 2:
        multipliers = [tuple([0]*n_vars)]
    else:
        multipliers = generate_monomials(n_vars, degree - 2)
    
    n_rows = n_eqs * len(multipliers)
    
    rows_data = [dict() for _ in range(n_rows)]
    
    for eq_idx in range(n_eqs):
        base_row = eq_idx * len(multipliers)
        
        # Constant term
        if c[eq_idx] != 0:
            for m_idx, m_mono in enumerate(multipliers):
                row = rows_data[base_row + m_idx]
                col = mono_to_idx[m_mono]
                row[col] = (row.get(col, 0) + int(c[eq_idx])) % p
        
        # Linear terms
        for j in range(n_vars):
            if L[eq_idx, j] != 0:
                for m_idx, m_mono in enumerate(multipliers):
                    nm = list(m_mono); nm[j] += 1; nm = tuple(nm)
                    col = mono_to_idx.get(nm)
                    if col is not None:
                        row = rows_data[base_row + m_idx]
                        row[col] = (row.get(col, 0) + int(L[eq_idx, j])) % p
        
        # Quadratic terms
        for j in range(n_vars):
            for l in range(j, n_vars):
                qval = int(Q[eq_idx, j, l] % p)
                if qval == 0:
                    continue
                for m_idx, m_mono in enumerate(multipliers):
                    nm = list(m_mono); nm[j] += 1; nm[l] += 1; nm = tuple(nm)
                    col = mono_to_idx.get(nm)
                    if col is not None:
                        row = rows_data[base_row + m_idx]
                        row[col] = (row.get(col, 0) + qval) % p
    
    return rows_data, n_rows, n_cols
