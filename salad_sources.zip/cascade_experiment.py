"""
Cascade experiment: measure actual degree falls at d=4,5,6,7 for Forge block
and compare with theoretical cascade prediction.

For each e, we build the Macaulay matrix at each degree d and measure:
- Actual rank and degree falls
- Compare with cascade prediction (extra rows from d=4 falls)

Key question: do the degree falls at d=4 produce independent degree-3
polynomials that add rows at higher degrees?
"""

import numpy as np
import galois
import time
import random
from itertools import combinations_with_replacement
from math import comb

p = 31

def mat_rank_np(M, p):
    """Exact rank over F_p using Gaussian elimination."""
    M = np.array(M, dtype=np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = -1
        for r in range(rank, rows):
            if M[r, col] % p != 0:
                pivot = r
                break
        if pivot == -1:
            continue
        if pivot != rank:
            M[rank], M[pivot] = M[pivot].copy(), M[rank].copy()
        inv = pow(int(M[rank, col]), -1, p)
        M[rank] = (M[rank] * inv) % p
        for r in range(rows):
            if r != rank and M[r, col] % p != 0:
                M[r] = (M[r] - M[r, col] * M[rank]) % p
        rank += 1
        if rank >= rows:
            break
    return rank

def fq_to_matrix(fq_el, reg, e, p):
    vec = np.array(fq_el.vector(), dtype=int) % p
    M = np.zeros((e, e), dtype=np.int64)
    for k in range(e):
        if vec[k] != 0:
            M = (M + int(vec[k]) * reg[:, :, k]) % p
    return M

def build_macaulay(hess, n_var, d, p):
    """Build Macaulay matrix at degree d."""
    n_eq = len(hess)
    mm = list(combinations_with_replacement(range(n_var), d - 2))
    cm = list(combinations_with_replacement(range(n_var), d))
    nr = n_eq * len(mm)
    nc = len(cm)
    ci = {m: i for i, m in enumerate(cm)}
    M = np.zeros((nr, nc), dtype=np.int8)
    for ei, H in enumerate(hess):
        nz = np.argwhere(H != 0)
        for mi, mn in enumerate(mm):
            row = ei * len(mm) + mi
            for idx in nz:
                i, j = int(idx[0]), int(idx[1])
                comb_key = tuple(sorted(mn + (i, j)))
                if comb_key in ci:
                    c = ci[comb_key]
                    M[row, c] = (int(M[row, c]) + int(H[i, j])) % p
    return M, nr, nc

def measure_dreg(hess, n_var, d, p):
    """Measure degree falls at degree d."""
    M, nr, nc = build_macaulay(hess, n_var, d, p)
    rank = mat_rank_np(M, p)
    md = min(nr, nc)
    null = nc - rank
    falls = null - max(0, nc - nr)
    return nr, nc, rank, falls

def setup_forge_block(e, schedule, p=31):
    """Setup Forge block (e eq, e vars)."""
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    
    frob = []
    for a in range(e):
        F = np.zeros((e, e), dtype=int)
        fa = alpha ** (p**a)
        for i in range(e):
            F[:, i] = np.array((fa ** i).vector(), dtype=int) % p
        frob.append(F % p)
    
    mult = np.zeros((e, e, e), dtype=int)
    for m in range(e):
        for n in range(e):
            mult[:, m, n] = np.array(((alpha**m) * (alpha**n)).vector(), dtype=int) % p
    
    reg = np.zeros((e, e, e), dtype=int)
    for k in range(e):
        ak = alpha ** k
        for j in range(e):
            reg[:, j, k] = np.array((ak * (alpha ** j)).vector(), dtype=int) % p
    
    random.seed(42)
    A_k_list = []
    for k in range(5):
        A = GF(np.zeros((5, 5), dtype=int))
        A[0, 0] = GF(0)
        for i in range(1, 5):
            A[i, i] = alpha ** random.randrange(0, p**e - 1)
        for i in range(1, 5):
            A[0, i] = alpha ** random.randrange(0, p**e - 1)
            A[i, 0] = alpha ** random.randrange(0, p**e - 1)
        A_k_list.append(A)
    
    block_idx = 1
    fg_hess = []
    for j in range(e):
        H_sum = np.zeros((e, e), dtype=np.int64)
        for k in range(5):
            a_k, b_k = schedule[k]
            F_a = frob[a_k % e]
            F_b = frob[b_k % e]
            M_ii = fq_to_matrix(A_k_list[k][block_idx, block_idx], reg, e, p)
            B = (F_a.T @ mult[j] @ F_b) % p
            H_k = (M_ii @ B + M_ii.T @ B.T) % p
            H_sum = (H_sum + H_k) % p
        fg_hess.append(H_sum % p)
    
    return fg_hess

def setup_keyrec_block(e, schedule, p=31):
    """Setup KeyRec block (5e eq, e vars)."""
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    
    frob = []
    for a in range(e):
        F = np.zeros((e, e), dtype=int)
        fa = alpha ** (p**a)
        for i in range(e):
            F[:, i] = np.array((fa ** i).vector(), dtype=int) % p
        frob.append(F % p)
    
    mult = np.zeros((e, e, e), dtype=int)
    for m in range(e):
        for n in range(e):
            mult[:, m, n] = np.array(((alpha**m) * (alpha**n)).vector(), dtype=int) % p
    
    reg = np.zeros((e, e, e), dtype=int)
    for k in range(e):
        ak = alpha ** k
        for j in range(e):
            reg[:, j, k] = np.array((ak * (alpha ** j)).vector(), dtype=int) % p
    
    random.seed(42)
    A_k_list = []
    for k in range(5):
        A = GF(np.zeros((5, 5), dtype=int))
        A[0, 0] = GF(0)
        for i in range(1, 5):
            A[i, i] = alpha ** random.randrange(0, p**e - 1)
        for i in range(1, 5):
            A[0, i] = alpha ** random.randrange(0, p**e - 1)
            A[i, 0] = alpha ** random.randrange(0, p**e - 1)
        A_k_list.append(A)
    
    block_idx = 1
    kr_hess = []
    for k in range(5):
        a_k, b_k = schedule[k]
        F_a = frob[a_k % e]
        F_b = frob[b_k % e]
        M_ii = fq_to_matrix(A_k_list[k][block_idx, block_idx], reg, e, p)
        for j in range(e):
            B = (F_a.T @ mult[j] @ F_b) % p
            H = (M_ii @ B + M_ii.T @ B.T) % p
            kr_hess.append(H % p)
    
    return kr_hess

def run_cascade_experiment(e, schedule, label, n_vars):
    """Run full cascade experiment for a given e and schedule."""
    t0 = time.time()
    
    if label.startswith('Forge'):
        hess = setup_forge_block(e, schedule)
    else:
        hess = setup_keyrec_block(e, schedule)
    
    n_eq = len(hess)
    print(f'\n{"="*60}')
    print(f'{label}: e={e}, {n_eq} eq, {n_vars} vars')
    print(f'{"="*60}')
    print(f'  Setup: {time.time()-t0:.1f}s')
    
    results = []
    max_d = 8 if e <= 7 else 7 if e <= 11 else 5
    
    for d in range(2, max_d + 1):
        t1 = time.time()
        nr, nc, rank, falls = measure_dreg(hess, n_vars, d, p)
        t2 = time.time()
        
        # Theoretical cascade prediction
        # At d=4: falls = C(e,2) (or n_vars * C(e,2) for multi-block)
        # These falls produce degree-3 polynomials
        # At degree d>4: extra rows = falls_d4 * C(n_vars*e + d-4, d-3)
        
        if d == 4:
            falls_d4 = falls
            theoretical_falls = n_vars * comb(e, 2) if n_vars == 1 else falls
        elif d > 4 and 'falls_d4' in dir():
            # Cascade prediction: extra rows from degree-3 polynomials
            mm_extra = comb(n_vars * e + d - 4, d - 3)
            extra_rows = falls_d4 * mm_extra
            # Effective rows
            eff_rows = nr + extra_rows
            eff_falls = max(0, eff_rows - nc) - max(0, nr - nc)  # additional falls from cascade
            theoretical_extra = extra_rows
        else:
            theoretical_extra = 0
        
        status = 'OVER' if nr > nc else 'UNDER'
        
        print(f'  d={d}: {nr}x{nc} rank={rank} falls={falls} [{status}] t={t2-t1:.1f}s', end='')
        
        if d == 4:
            print(f' <- d_reg=4, falls=C(e,2)*n_vars={n_vars*comb(e,2)}', end='')
            if falls == n_vars * comb(e, 2):
                print(' [MATCH]', end='')
            print()
        elif d > 4:
            # Compare actual falls with cascade prediction
            # The cascade adds extra_rows to the system
            # If the system becomes overdetermined, falls should increase
            eff_total = nr + (falls_d4 * comb(n_vars * e + d - 4, d - 3) if d >= 5 and 'falls_d4' in dir() else 0)
            eff_status = 'OVER' if eff_total > nc else 'UNDER'
            print(f' [cascade: +{falls_d4 * comb(n_vars * e + d - 4, d - 3) if d >= 5 and "falls_d4" in dir() else 0} extra rows -> {eff_total} vs {nc} {eff_status}]', end='')
            print()
        else:
            print()
        
        results.append((d, nr, nc, rank, falls))
    
    return results

# ============================================================
# EXPERIMENT 1: Forge block cascade for e=5,7,11
# ============================================================

print('='*60)
print('EXPERIMENT 1: Forge block cascade (e eq, e vars)')
print('='*60)

schedule = [(0,1), (1,2), (2,3), (3,4), (4,5)]

for e in [5, 7, 11]:
    run_cascade_experiment(e, schedule, f'Forge block', e)

# ============================================================
# EXPERIMENT 2: KeyRec block cascade for e=5,7
# ============================================================

print()
print('='*60)
print('EXPERIMENT 2: KeyRec block cascade (5e eq, e vars)')
print('='*60)

for e in [5, 7]:
    run_cascade_experiment(e, schedule, f'KeyRec block', e)

# ============================================================
# EXPERIMENT 3: 2-block forgery (e eq, 2e vars) for e=5,7
# ============================================================

print()
print('='*60)
print('EXPERIMENT 3: 2-block forgery cascade (e eq, 2e vars)')
print('='*60)

for e in [5, 7]:
    t0 = time.time()
    
    # Build 2-block forgery: sum of 2 Forge blocks
    # Equation: f1(X1) + f2(X2) = h
    # After Weil descent: e eq in 2e vars
    
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    
    frob = []
    for a in range(e):
        F = np.zeros((e, e), dtype=int)
        fa = alpha ** (p**a)
        for i in range(e):
            F[:, i] = np.array((fa ** i).vector(), dtype=int) % p
        frob.append(F % p)
    
    mult = np.zeros((e, e, e), dtype=int)
    for m in range(e):
        for n in range(e):
            mult[:, m, n] = np.array(((alpha**m) * (alpha**n)).vector(), dtype=int) % p
    
    reg = np.zeros((e, e, e), dtype=int)
    for k in range(e):
        ak = alpha ** k
        for j in range(e):
            reg[:, j, k] = np.array((ak * (alpha ** j)).vector(), dtype=int) % p
    
    random.seed(42)
    A_k_list = []
    for k in range(5):
        A = GF(np.zeros((5, 5), dtype=int))
        A[0, 0] = GF(0)
        for i in range(1, 5):
            A[i, i] = alpha ** random.randrange(0, p**e - 1)
        for i in range(1, 5):
            A[0, i] = alpha ** random.randrange(0, p**e - 1)
            A[i, 0] = alpha ** random.randrange(0, p**e - 1)
        A_k_list.append(A)
    
    def fq_to_matrix_local(fq_el):
        return fq_to_matrix(fq_el, reg, e, p)
    
    block_idx = 1
    
    # Build 2-block forgery Hessians (e eq in 2e vars)
    # Each equation j: sum_k c_{k,1} * (F_{a_k} x1)^T M_j (F_{b_k} x1) + c_{k,2} * (F_{a_k} x2)^T M_j (F_{b_k} x2)
    # The Hessian is block-diagonal: H_j = [H_{j,1} 0; 0 H_{j,2}]
    # where H_{j,i} is the Forge block Hessian for variable i
    
    fg2_hess = []
    for j in range(e):
        # Build 2e x 2e block-diagonal Hessian
        H = np.zeros((2*e, 2*e), dtype=np.int64)
        for block in range(2):
            H_sum = np.zeros((e, e), dtype=np.int64)
            for k in range(5):
                a_k, b_k = schedule[k]
                F_a = frob[a_k % e]
                F_b = frob[b_k % e]
                M_ii = fq_to_matrix_local(A_k_list[k][block_idx, block_idx])
                B = (F_a.T @ mult[j] @ F_b) % p
                H_k = (M_ii @ B + M_ii.T @ B.T) % p
                H_sum = (H_sum + H_k) % p
            H[block*e:(block+1)*e, block*e:(block+1)*e] = H_sum % p
        fg2_hess.append(H % p)
    
    n_eq = len(fg2_hess)
    n_var = 2 * e
    print(f'\n{"="*60}')
    print(f'2-block forgery: e={e}, {n_eq} eq, {n_var} vars')
    print(f'{"="*60}')
    print(f'  Setup: {time.time()-t0:.1f}s')
    
    falls_d4 = None
    max_d = 7 if e <= 5 else 5
    
    for d in range(2, max_d + 1):
        t1 = time.time()
        nr, nc, rank, falls = measure_dreg(fg2_hess, n_var, d, p)
        t2 = time.time()
        
        status = 'OVER' if nr > nc else 'UNDER'
        
        if d == 4:
            falls_d4 = falls
            expected = 2 * comb(e, 2)
            print(f'  d={d}: {nr}x{nc} rank={rank} falls={falls} [{status}] (expected 2*C(e,2)={expected}) t={t2-t1:.1f}s')
        elif d > 4 and falls_d4 is not None:
            mm_extra = comb(n_var + d - 4, d - 3)
            extra_rows = falls_d4 * mm_extra
            eff_total = nr + extra_rows
            eff_status = 'OVER' if eff_total > nc else 'UNDER'
            print(f'  d={d}: {nr}x{nc} rank={rank} falls={falls} [{status}] t={t2-t1:.1f}s', end='')
            print(f'  [cascade: +{extra_rows} rows -> {eff_total} vs {nc} {eff_status}]')
        else:
            print(f'  d={d}: {nr}x{nc} rank={rank} falls={falls} [{status}] t={t2-t1:.1f}s')

print()
print('='*60)
print('SUMMARY')
print('='*60)
print()
print('Key questions answered:')
print('1. Do degree-4 falls produce independent degree-3 polynomials?')
print('2. Does the cascade amplify or diminish at higher degrees?')
print('3. Is the effective crossover lower than the theoretical prediction?')
