#!/bin/bash
# run_all.sh — Run all reproduction experiments
# Requirements: python3, numpy, galois (pip install galois)
set -e

echo "============================================================"
echo "Reproduction: Diagonal variant of UFOs — centralizer analysis"
echo "============================================================"
echo ""

echo "=== 1. Centralizer dimension (Table 2) ==="
python3 centralizer_fq_exact.py

echo ""
echo "=== 2. Idempotent search (Table 3) ==="
python3 idempotents_fq_exact.py

echo ""
echo "=== 3. Block degree of regularity (Table 4) ==="
python3 block_degree_profile.py

echo ""
echo "============================================================"
echo "Done. See report.tex for analysis."
echo "============================================================"
