"""
Direct U_dim computation for real UFOs Level I: p=31, e=61.

Instead of building the full Macaulay matrix (3782 x 41664, too large),
we compute the dimension of the subspace U = span{u_{kl}} where
u_{kl} = Q[:,k,l] = vector representation of the field element
    sum_r c_r * phi_{a_r}(alpha^k) * phi_{b_r}(alpha^l)

If U_dim = e, the syzygy space is trivial and D_lin=3 is NOT found.
If U_dim < e, syzygies exist and D_lin=3 may be found.

The Frobenius map phi_a: x -> x^(p^a) is F_p-linear, so:
  phi_a(alpha^k) = alpha^(k * p^a)
We precompute alpha^(p^a mod (p^e-1)) once, then take powers.
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def compute_frobenius_vectors(GF, p, e, a):
    """Compute phi_a(alpha^j) for j=0..e-1 as field elements.
    
    phi_a(alpha^j) = alpha^(j * p^a) = (alpha^(p^a))^j
    """
    frob_exp = pow(p, a, p**e - 1)
    prim = GF.primitive_element
    alpha_frob = prim ** frob_exp
    
    # Compute alpha_frob^j for j=0..e-1
    vectors = []
    current = GF(1)  # alpha_frob^0
    for j in range(e):
        vectors.append(current)
        current = current * alpha_frob  # alpha_frob^(j+1)
    
    return vectors

def compute_U_matrix(GF, p, e, terms):
    """Compute the e x (e*(e+1)/2) matrix of u_{kl} vectors.
    
    u_{kl} = vector(sum_r c_r * phi_{a_r}(alpha^k) * phi_{b_r}(alpha^l))
    
    Returns the matrix M where M[i, idx(k,l)] = u_{kl}[i].
    """
    # Precompute Frobenius vectors for each term
    frob_a_vecs = []
    frob_b_vecs = []
    for a, b, c_int in terms:
        fa = compute_frobenius_vectors(GF, p, e, a)
        fb = compute_frobenius_vectors(GF, p, e, b)
        frob_a_vecs.append(fa)
        frob_b_vecs.append(fb)
    
    # Compute u_{kl} for all k <= l
    n_pairs = e * (e + 1) // 2
    M = np.zeros((e, n_pairs), dtype=np.int64)
    
    idx = 0
    for k in range(e):
        for l in range(k, e):
            # u_{kl} = sum_r c_r * phi_{a_r}(alpha^k) * phi_{b_r}(alpha^l)
            field_elem = GF(0)
            for r, (a, b, c_int) in enumerate(terms):
                product = frob_a_vecs[r][k] * frob_b_vecs[r][l]
                field_elem = field_elem + GF(c_int) * product
            
            # Convert to vector representation
            vec = np.array(field_elem.vector(), dtype=np.int64)
            # galois returns [alpha^{e-1}, ..., alpha^0] (reversed)
            # We use standard order: reverse
            M[:, idx] = vec[::-1]
            idx += 1
    
    return M

def compute_U_dim(M, p):
    """Compute rank of M mod p (dimension of U subspace)."""
    M = M.copy() % p
    n_rows, n_cols = M.shape
    pivot_row = 0
    
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        col_data = M[pivot_row:, col] % p
        nonzero = np.where(col_data != 0)[0]
        if len(nonzero) == 0:
            continue
        idx = nonzero[0] + pivot_row
        M[[pivot_row, idx]] = M[[idx, pivot_row]]
        inv = pow(int(M[pivot_row, col]), p-2, p)
        M[pivot_row] = (M[pivot_row] * inv) % p
        for r in range(n_rows):
            if r != pivot_row and M[r, col] % p != 0:
                M[r] = (M[r] - int(M[r, col]) * M[pivot_row]) % p
        pivot_row += 1
    
    return pivot_row

def test_schedule(p, e, schedule, n_seeds=3):
    """Test all 10 triplets for a given schedule."""
    GF = galois.GF(p**e)
    pairs = list(combinations(range(5), 2))
    
    print(f"\n{'='*80}")
    print(f"p={p}, e={e}, schedule={schedule}")
    print(f"{'='*80}")
    print(f"{'Cancel':>8s} | {'U_dim':>10s} | {'kernel':>10s} | {'D_lin@3':>8s} | {'Note':>20s}")
    print("-" * 65)
    
    all_results = []
    
    for cancel in pairs:
        residual = [schedule[k] for k in range(5) if k not in cancel]
        
        # Try multiple seeds
        seed_results = []
        for seed in range(n_seeds):
            rng = random.Random(seed * 42 + 7)
            x0_int = rng.randint(1, p**e - 1)
            x0 = GF(x0_int)
            
            rng_c = random.Random(hash(cancel) % 2**32 + seed * 7919)
            terms = []
            for a, b in residual:
                c_int = int(GF(rng_c.randint(1, p**e - 1)))
                terms.append((a, b, c_int))
            
            # Compute h = F(x0)
            h_val = GF(0)
            for a, b, c_int in terms:
                h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
            
            # Compute U matrix
            t0 = time.time()
            M = compute_U_matrix(GF, p, e, terms)
            t1 = time.time()
            
            U_dim = compute_U_dim(M, p)
            t2 = time.time()
            
            kernel_dim = e * (e - U_dim)  # theoretical minimum
            dlin = U_dim < e
            
            seed_results.append({
                'U_dim': U_dim,
                'kernel_min': kernel_dim,
                'dlin': dlin,
                'time': t2 - t0,
            })
        
        # Aggregate
        u_dims = [r['U_dim'] for r in seed_results]
        dlin_found = any(r['dlin'] for r in seed_results)
        
        u_str = f"{u_dims[0]}" if len(set(u_dims)) == 1 else f"{u_dims}"
        k_str = f"{seed_results[0]['kernel_min']}" if len(set(u_dims)) == 1 else "varies"
        dl_str = "YES" if dlin_found else "no"
        note = "rank deficient" if dlin_found else "full rank"
        
        print(f"{str(cancel):>8s} | {u_str:>10s} | {k_str:>10s} | {dl_str:>8s} | {note:>20s}")
        all_results.append((cancel, dlin_found, u_dims))
    
    dlin_count = sum(1 for r in all_results if r[1])
    print(f"\n  Summary: D_lin@3 possible for {dlin_count}/10 triplets")
    print(f"  (U_dim = e means full rank, no syzygies, no D_lin)")
    
    return all_results

# === Real UFOs Level I: p=31, e=61 ===
ufos_level1_schedule = [(0,9),(7,54),(13,29),(15,37),(35,47)]

print("="*80)
print("REAL UFOs Level I: p=31, e=61")
print(f"Schedule: {ufos_level1_schedule}")
print("="*80)

t_start = time.time()
results = test_schedule(31, 61, ufos_level1_schedule, n_seeds=1)
t_end = time.time()
print(f"\nTotal time: {t_end - t_start:.1f}s")

# === Comparison: consecutive schedule at e=61 (if feasible) ===
print("\n" + "="*80)
print("Comparison: Consecutive schedule at e=61")
print("="*80)
consec_schedule = [(0,1),(1,2),(2,3),(3,4),(4,5)]
results_consec = test_schedule(31, 61, consec_schedule, n_seeds=1)
print(f"\nTotal time: {time.time() - t_end:.1f}s")
