"""
Run cryptographic_estimators for SALAD forgery parameters.
"""
import sys
from cryptographic_estimators.UOVEstimator import UOVEstimator
from cryptographic_estimators.MQEstimator import MQEstimator

print("=== SALAD forgery parameters (e eqs in 5e vars) ===")
print()

for level, (p, e) in [('I', (31, 61)), ('III', (61, 89)), ('V', (61, 127))]:
    v = 4
    n = v + 1  # 5
    n_vars = e * n  # 5e
    
    print(f"Level {level} (p={p}, e={e}, n={n_vars}, m={e}):")
    
    try:
        MQE = MQEstimator(n=n_vars, m=e, q=p)
        fastest = MQE.fastest_algorithm()
        print(f"  MQ fastest: {fastest}")
        print(f"  MQ time: {fastest.time_complexity()}")
    except Exception as ex:
        print(f"  MQ error: {ex}")
    
    try:
        UOVE = UOVEstimator(n=n_vars, m=e, q=p)
        fastest_uov = UOVE.fastest_algorithm()
        print(f"  UOV fastest: {fastest_uov}")
        print(f"  UOV time: {fastest_uov.time_complexity()}")
    except Exception as ex:
        print(f"  UOV error: {ex}")
    
    print()

print("=== Original script parameters ===")
print()
for pe in [
    [31, 59, 143], [37, 59, 143], [43, 59, 143], [31, 61, 143],
    [53, 79, 207], [59, 79, 207], [61, 79, 207],
    [97, 101, 272], [101, 101, 272], [71, 103, 272], [73, 103, 272]
]:
    p = pe[0]; e = pe[1]
    v = 4; n = v + 1; n_vars = e * n
    
    print(f"p={p}, e={e}, n={n_vars}, m={e}:")
    
    try:
        MQE = MQEstimator(n=n_vars, m=e, q=p)
        fastest = MQE.fastest_algorithm()
        print(f"  MQ: {fastest} -> {fastest.time_complexity()}")
    except Exception as ex:
        print(f"  MQ error: {ex}")
    
    try:
        UOVE = UOVEstimator(n=n_vars, m=e, q=p)
        fastest_uov = UOVE.fastest_algorithm()
        print(f"  UOV: {fastest_uov} -> {fastest_uov.time_complexity()}")
    except Exception as ex:
        print(f"  UOV error: {ex}")
    
    print()

