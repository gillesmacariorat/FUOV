"""
Gram matrix approach for constraint matrix rank computation.

Instead of Gaussian elimination on C (39711 x 3721), compute G = C^T @ C (3721 x 3721).
Over F_p with p=31 and e=61, ker(G) = ker(C) with overwhelming probability
(no isotropic vectors in the row space).

Steps:
1. Build Q using Frobenius vectors
2. Build C in blocks of 2000 rows, accumulate G = C^T @ C (mod p)
3. Compute rank of G (3721 x 3721 Gaussian elimination - fast)
4. rank(C) = rank(G)
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def compute_frobenius_vectors(GF, p, e, a):
    frob_exp = pow(p, a, p**e - 1)
    prim = GF.primitive_element
    alpha_frob = prim ** frob_exp
    vectors = []
    current = GF(1)
    for j in range(e):
        vectors.append(current)
        current = current * alpha_frob
    return vectors

def build_Q(GF, p, e, terms):
    frob_a_vecs = []
    frob_b_vecs = []
    for a, b, c_int in terms:
        fa = compute_frobenius_vectors(GF, p, e, a)
        fb = compute_frobenius_vectors(GF, p, e, b)
        frob_a_vecs.append(fa)
        frob_b_vecs.append(fb)
    
    n_pairs = e * (e + 1) // 2
    U = np.zeros((e, n_pairs), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            field_elem = GF(0)
            for r, (a, b, c_int) in enumerate(terms):
                product = frob_a_vecs[r][k] * frob_b_vecs[r][l]
                field_elem = field_elem + GF(c_int) * product
            vec = np.array(field_elem.vector(), dtype=np.int64)
            U[:, idx] = vec[::-1]
            idx += 1
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            Q[:, k, l] = U[:, idx]
            Q[:, l, k] = U[:, idx]
            idx += 1
    return Q

def build_C_block(Q, e, p, monomials):
    """Build a block of constraint matrix C for given cubic monomials."""
    n_cols = e * e
    n_rows = len(monomials)
    C_block = np.zeros((n_rows, n_cols), dtype=np.int32)
    
    for row_idx, (a, b, c) in enumerate(monomials):
        if a == b == c:
            for i in range(e):
                C_block[row_idx, i*e + a] = int(Q[i, a, a])
        elif a == b:
            for i in range(e):
                C_block[row_idx, i*e + a] = (2 * int(Q[i, a, c])) % p
                C_block[row_idx, i*e + c] = int(Q[i, a, a])
        elif b == c:
            for i in range(e):
                C_block[row_idx, i*e + b] = (2 * int(Q[i, a, b])) % p
                C_block[row_idx, i*e + a] = int(Q[i, b, b])
        else:
            for i in range(e):
                C_block[row_idx, i*e + a] = (2 * int(Q[i, b, c])) % p
                C_block[row_idx, i*e + b] = (2 * int(Q[i, a, c])) % p
                C_block[row_idx, i*e + c] = (2 * int(Q[i, a, b])) % p
    
    return C_block

def compute_gram_rank(Q, e, p, block_size=2000):
    """Compute rank of constraint matrix C using Gram matrix approach."""
    n_cols = e * e
    cubic_mons = list(combinations_with_replacement(range(e), 3))
    n_mons = len(cubic_mons)
    
    print(f"  C: {n_mons} rows x {n_cols} cols. Building Gram matrix G = C^T @ C ({n_cols} x {n_cols})")
    
    # Accumulate Gram matrix
    G = np.zeros((n_cols, n_cols), dtype=np.int64)
    
    n_blocks = (n_mons + block_size - 1) // block_size
    
    for block_idx in range(n_blocks):
        start = block_idx * block_size
        end = min(start + block_size, n_mons)
        mons = cubic_mons[start:end]
        
        C_block = build_C_block(Q, e, p, mons)
        # G += C_block^T @ C_block (mod p)
        G = (G + C_block.T @ C_block) % p
        
        elapsed = time.time() - t_start
        print(f"    Block {block_idx+1}/{n_blocks}: rows {start}-{end}, "
              f"G nnz={np.count_nonzero(G)}, time={elapsed:.1f}s")
    
    # Compute rank of G mod p
    print(f"  Computing rank of G ({n_cols} x {n_cols})...")
    rank = gauss_elim_rank(G.astype(np.int32), p)
    return rank, n_cols

def gauss_elim_rank(M, p):
    """Compute rank of M mod p."""
    M = M.copy().astype(np.int64) % p
    n_rows, n_cols = M.shape
    rank = 0
    
    for col in range(min(n_rows, n_cols)):
        if rank >= n_rows:
            break
        col_slice = M[rank:, col] % p
        nonzero = np.where(col_slice != 0)[0]
        if len(nonzero) == 0:
            continue
        pivot_idx = nonzero[0] + rank
        if pivot_idx != rank:
            M[[rank, pivot_idx]] = M[[pivot_idx, rank]]
        inv_val = pow(int(M[rank, col]), p-2, p)
        M[rank] = (M[rank] * inv_val) % p
        factors = M[:, col].copy()
        factors[rank] = 0
        mask = factors != 0
        if np.any(mask):
            M[mask] = (M[mask] - factors[mask, np.newaxis] * M[rank]) % p
        rank += 1
    
    return rank

# === Validation: e=7, p=31, consecutive ===
print("="*80)
print("VALIDATION: e=7, p=31, consecutive schedule")
print("="*80)

p, e = 31, 7
GF = galois.GF(p**e)
schedule = [(0,1),(1,2),(2,3),(3,4),(4,5)]
cancel = (0, 1)
residual = [schedule[k] for k in range(5) if k not in cancel]

rng = random.Random(42)
x0_int = rng.randint(1, p**e - 1)
x0 = GF(x0_int)
rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
terms = []
for a, b in residual:
    c_int = int(GF(rng_c.randint(1, p**e - 1)))
    terms.append((a, b, c_int))

t_start = time.time()
Q = build_Q(GF, p, e, terms)
print(f"Q built in {time.time()-t_start:.1f}s")

# Also build full C and compute rank directly (for validation)
C_full = build_C_block(Q, e, p, list(combinations_with_replacement(range(e), 3)))
print(f"C shape: {C_full.shape}, nnz: {np.count_nonzero(C_full)}")

t1 = time.time()
rank_direct = gauss_elim_rank(C_full.astype(np.int32), p)
print(f"Direct rank: {rank_direct}/{e*e} ({time.time()-t1:.1f}s)")

# Gram matrix approach
t2 = time.time()
rank_gram, n_cols = compute_gram_rank(Q, e, p)
print(f"Gram rank: {rank_gram}/{n_cols} ({time.time()-t2:.1f}s)")
print(f"Match: {rank_direct == rank_gram}")
print(f"D_lin@3: {'YES' if rank_gram < e*e else 'no'}")

# === Real UFOs Level I: p=31, e=61 ===
print("\n" + "="*80)
print("REAL UFOs Level I: p=31, e=61")
print("="*80)

p, e = 31, 61
ufos_schedule = [(0,9),(7,54),(13,29),(15,37),(35,47)]
GF = galois.GF(p**e)

pairs = list(combinations(range(5), 2))
all_results = []

for cancel in pairs:
    residual = [ufos_schedule[k] for k in range(5) if k not in cancel]
    
    rng = random.Random(42)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
    terms = []
    for a, b in residual:
        c_int = int(GF(rng_c.randint(1, p**e - 1)))
        terms.append((a, b, c_int))
    
    t_start = time.time()
    Q = build_Q(GF, p, e, terms)
    t_q = time.time() - t_start
    print(f"\nCancel {cancel}: Q built in {t_q:.1f}s")
    
    rank, n_cols = compute_gram_rank(Q, e, p, block_size=2000)
    t_total = time.time() - t_start
    
    syz_dim = n_cols - rank
    dlin = rank < n_cols
    
    print(f"  C rank={rank}/{n_cols}, syz={syz_dim}, D_lin@3={'YES' if dlin else 'no'}, time={t_total:.1f}s")
    all_results.append((cancel, rank, syz_dim, dlin))

print(f"\n{'='*80}")
print("SUMMARY: UFOs Level I (p=31, e=61)")
print(f"{'='*80}")
dlin_count = sum(1 for r in all_results if r[3])
for cancel, rank, syz, dlin in all_results:
    print(f"  Cancel {cancel}: rank={rank}/{e*e}, syz={syz}, D_lin@3={'YES' if dlin else 'no'}")
print(f"\nD_lin@3 found for {dlin_count}/10 triplets")
