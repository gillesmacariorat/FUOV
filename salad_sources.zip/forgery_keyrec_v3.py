#!/usr/bin/env python3
"""
Fixed: handle F_q coefficients for key recovery (planted instances).
Forgery uses F_p coefficients (valid since F_p ⊂ F_q).
"""

import numpy as np
from math import comb
import time
import galois

def setup_field(p, e):
    GF = galois.GF(p**e)
    alpha = GF.primitive_element
    def frob_matrix(a):
        F = np.zeros((e, e), dtype=np.int64)
        for j in range(e):
            val = alpha ** (j * (p ** a))
            vec = np.array(val.vector(), dtype=np.int64)[::-1]
            F[:, j] = vec
        return F % p
    mu = np.zeros((e, e, e), dtype=np.int64)
    for i in range(e):
        for j in range(e):
            prod = (alpha ** i) * (alpha ** j)
            vec = np.array(prod.vector(), dtype=np.int64)[::-1]
            mu[i, j, :] = vec
    return GF, alpha, mu, frob_matrix

def mult_matrix(c_vec, mu, p):
    """Multiplication matrix M_c: (M_c)[m,n] = sum_r c_r * mu[r,n,m]. 
    So (c * v)_m = sum_n M_c[m,n] * v_n."""
    # M_c[m,n] = sum_r c_vec[r] * mu[r,n,m]
    M = np.einsum('r,rnm->mn', c_vec, mu) % p
    return M

def build_forgery_system(p, e, schedule, cancel_pair, coeffs, diagonal, mu, frob_fn):
    """Build forgery system: e eqs in 5e vars. Coeffs are F_p scalars."""
    residual = [k for k in range(5) if k not in cancel_pair]
    n_vars = 5 * e
    n_eqs = e
    Q = np.zeros((n_eqs, n_vars, n_vars), dtype=np.int64)
    L = np.zeros((n_eqs, n_vars), dtype=np.int64)
    c_const = np.zeros(n_eqs, dtype=np.int64)
    
    for k in residual:
        a_k, b_k = schedule[k]
        Fa = frob_fn(a_k)
        Fb = frob_fn(b_k)
        # Quadratic form tensor: T[m,j,l] = sum_{r,s} mu[r,s,m] * Fa[r,j] * Fb[s,l]
        T = np.einsum('rsm,rp,sl->mpl', mu, Fa, Fb) % p
        
        if diagonal:
            for i in range(5):
                ci = int(coeffs[k, i]) % p
                if ci == 0: continue
                idx = i * e
                Q[:, idx:idx+e, idx:idx+e] = (Q[:, idx:idx+e, idx:idx+e] + ci * T) % p
        else:
            for i in range(5):
                for j in range(5):
                    aij = int(coeffs[k, i, j]) % p
                    if aij == 0: continue
                    Q[:, i*e:(i+1)*e, j*e:(j+1)*e] = (Q[:, i*e:(i+1)*e, j*e:(j+1)*e] + aij * T) % p
    
    return Q, L, c_const

def build_keyrecovery_system(p, e, schedule, coeffs_fq, diagonal, mu, frob_fn):
    """Build key recovery system: 5e eqs in 4e vars (X_0=1).
    coeffs_fq: list of 5 arrays, each (5,) or (5,5) of GF elements.
    For F_q coefficients, we need the multiplication matrix M_c."""
    n_vars = 4 * e
    n_eqs = 5 * e
    Q = np.zeros((n_eqs, n_vars, n_vars), dtype=np.int64)
    L = np.zeros((n_eqs, n_vars), dtype=np.int64)
    c_const = np.zeros(n_eqs, dtype=np.int64)
    
    for k in range(5):
        a_k, b_k = schedule[k]
        Fa = frob_fn(a_k)
        Fb = frob_fn(b_k)
        eq_off = k * e
        
        # Base tensor: T[m,j,l] = sum_{r,s} mu[r,s,m] * Fa[r,j] * Fb[s,l]
        T = np.einsum('rsm,rp,sl->mpl', mu, Fa, Fb) % p
        
        if diagonal:
            # c_{k,i} is in F_q. Get its coordinate vector.
            for i in range(5):
                c_vec = np.array(coeffs_fq[k][i].vector(), dtype=np.int64)[::-1] % p
                if np.max(c_vec) == 0: continue
                
                if i == 0:
                    # X_0 = 1: constant term c_{k,0} * 1 (scalar in F_q, gives e equations)
                    # The m-th equation gets: (c_{k,0})_m (the m-th coordinate)
                    c_const[eq_off:eq_off+e] = (c_const[eq_off:eq_off+e] + c_vec) % p
                else:
                    var_off = (i - 1) * e
                    # c_{k,i} * X_i^{p^a} * X_i^{p^b}: multiply T by M_c
                    M_c = mult_matrix(c_vec, mu, p)
                    # Q_block[m,p,l] = sum_n M_c[m,n] * T[n,j,l]
                    Q_block = np.einsum('mn,npl->mpl', M_c, T) % p
                    Q[eq_off:eq_off+e, var_off:var_off+e, var_off:var_off+e] = (
                        Q[eq_off:eq_off+e, var_off:var_off+e, var_off:var_off+e] + Q_block
                    ) % p
        else:
            for i in range(5):
                for j in range(5):
                    c_vec = np.array(coeffs_fq[k][i][j].vector(), dtype=np.int64)[::-1] % p
                    if np.max(c_vec) == 0: continue
                    M_c = mult_matrix(c_vec, mu, p)
                    Q_block = np.einsum('mn,npl->mpl', M_c, T) % p
                    
                    if i == 0 and j == 0:
                        c_const[eq_off:eq_off+e] = (c_const[eq_off:eq_off+e] + c_vec) % p
                    elif i == 0:
                        var_off = (j - 1) * e
                        # Linear term: c * X_j^{p^b} (since X_0=1, X_0^{p^a}=1)
                        # L[m,l] = sum_n M_c[m,n] * sum_{r,s} mu[r,s,n] * Fa[r,0] * Fb[s,l]
                        lin = np.einsum('mn,nrl,mr->ml', M_c, mu, Fb)  # wrong, let me think
                        # Actually: (c * (1 * X_j^{p^b}))_m = sum_n M_c[m,n] * (X_j^{p^b})_n
                        # (X_j^{p^b})_n = sum_s Fb[s,n] * x_{j,s} ... wait, X_j^{p^b} = Fb @ x_j
                        # So (c * (Fb @ x_j))_m = sum_n M_c[m,n] * (Fb @ x_j)_n = sum_{n,s} M_c[m,n] * Fb[n,s] * x_{j,s}
                        lin = np.einsum('mn,ns->ms', M_c, Fb) % p
                        L[eq_off:eq_off+e, var_off:var_off+e] = (
                            L[eq_off:eq_off+e, var_off:var_off+e] + lin
                        ) % p
                    elif j == 0:
                        var_off = (i - 1) * e
                        lin = np.einsum('mn,nr->mr', M_c, Fa) % p
                        L[eq_off:eq_off+e, var_off:var_off+e] = (
                            L[eq_off:eq_off+e, var_off:var_off+e] + lin
                        ) % p
                    else:
                        vi = (i - 1) * e
                        vj = (j - 1) * e
                        Q[eq_off:eq_off+e, vi:vi+e, vj:vj+e] = (
                            Q[eq_off:eq_off+e, vi:vi+e, vj:vj+e] + Q_block
                        ) % p
    
    return Q, L, c_const

def generate_monomials(n, max_deg):
    monos = []
    def gen(idx, remaining, current):
        if idx == n:
            monos.append(tuple(current))
            return
        for d in range(remaining + 1):
            current.append(d)
            gen(idx + 1, remaining - d, current)
            current.pop()
    gen(0, max_deg, [])
    return monos

def build_macaulay_and_rank(Q, L, c, n_vars, n_eqs, p, degree, col_limit=6000):
    t0 = time.time()
    all_monos = generate_monomials(n_vars, degree)
    n_cols = len(all_monos)
    mono_to_idx = {m: i for i, m in enumerate(all_monos)}
    if degree < 2:
        multipliers = [tuple([0] * n_vars)]
    else:
        multipliers = generate_monomials(n_vars, degree - 2)
    n_rows = n_eqs * len(multipliers)
    print(f"  d={degree}: {n_rows}x{n_cols}", end="", flush=True)
    
    if n_cols > col_limit:
        print(f" -> SKIP", flush=True)
        return n_rows, n_cols, -1, -1
    
    rows_list, cols_list, vals_list = [], [], []
    for eq_idx in range(n_eqs):
        if c[eq_idx] != 0:
            for m_idx, m_mono in enumerate(multipliers):
                rows_list.append(eq_idx * len(multipliers) + m_idx)
                cols_list.append(mono_to_idx[m_mono])
                vals_list.append(int(c[eq_idx]) % p)
        for j in range(n_vars):
            if L[eq_idx, j] != 0:
                for m_idx, m_mono in enumerate(multipliers):
                    nm = list(m_mono); nm[j] += 1; nm = tuple(nm)
                    col = mono_to_idx.get(nm)
                    if col is not None:
                        rows_list.append(eq_idx * len(multipliers) + m_idx)
                        cols_list.append(col)
                        vals_list.append(int(L[eq_idx, j]) % p)
        for j in range(n_vars):
            for l in range(j, n_vars):
                qval = int(Q[eq_idx, j, l] % p)
                if qval == 0: continue
                for m_idx, m_mono in enumerate(multipliers):
                    nm = list(m_mono); nm[j] += 1; nm[l] += 1; nm = tuple(nm)
                    col = mono_to_idx.get(nm)
                    if col is not None:
                        rows_list.append(eq_idx * len(multipliers) + m_idx)
                        cols_list.append(col)
                        vals_list.append(qval)
    
    M = np.zeros((n_rows, n_cols), dtype=np.int64)
    for r, col, v in zip(rows_list, cols_list, vals_list):
        M[r, col] = (M[r, col] + v) % p
    
    t0 = time.time()
    rank = rank_mod_p_fast(M, p)
    elapsed = time.time() - t0
    expected = min(n_rows, n_cols)
    defic = expected - rank
    print(f" rank={rank}/{expected} def={defic} [{elapsed:.1f}s]", flush=True)
    return n_rows, n_cols, rank, defic

def rank_mod_p_fast(M, p):
    M = M.copy().astype(np.int64) % p
    rows, cols = M.shape
    rank = 0
    for col in range(cols):
        pivot = -1
        for row in range(rank, rows):
            if M[row, col] % p != 0:
                pivot = row
                break
        if pivot == -1: continue
        if pivot != rank:
            M[[rank, pivot]] = M[[pivot, rank]]
        inv_val = pow(int(M[rank, col]), p - 2, p)
        M[rank] = (M[rank] * inv_val) % p
        mask = (M[:, col] % p != 0)
        mask[rank] = False
        if mask.any():
            M[mask] = (M[mask] - M[mask, col:col+1] * M[rank:rank+1]) % p
        rank += 1
        if rank >= rows: break
    return rank

def gen_forgery_coeffs(p, diagonal, seed=42):
    import random
    rng = random.Random(seed)
    if diagonal:
        return np.array([[rng.randrange(1, p) for _ in range(5)] for _ in range(5)], dtype=np.int64)
    else:
        return np.array([[[rng.randrange(1, p) for _ in range(5)] for _ in range(5)] for _ in range(5)], dtype=np.int64)

def gen_keyrecovery_coeffs(GF, alpha, p, e, schedule, diagonal, seed=42):
    """Generate planted key recovery instance. Returns F_q coefficients as GF elements."""
    import random
    rng = random.Random(seed)
    Lambda = [GF(1)] + [GF(rng.randrange(1, p**e)) for _ in range(4)]
    
    if diagonal:
        coeffs = []
        for k in range(5):
            a_k, b_k = schedule[k]
            row = []
            total = GF(0)
            for i in range(1, 5):
                ci = GF(rng.randrange(1, p**e))
                row.append(ci)
                val = Lambda[i] ** (p ** a_k) * Lambda[i] ** (p ** b_k)
                total += ci * val
            row.insert(0, GF(0) - total)  # c_{k,0} = -total
            coeffs.append(row)
        return coeffs, Lambda
    else:
        coeffs = []
        for k in range(5):
            a_k, b_k = schedule[k]
            mat = []
            total = GF(0)
            for i in range(5):
                mat_row = []
                for j in range(5):
                    if i == 0 and j == 0:
                        mat_row.append(GF(0))
                    else:
                        aij = GF(rng.randrange(1, p**e))
                        mat_row.append(aij)
                        val = Lambda[i] ** (p ** a_k) * Lambda[j] ** (p ** b_k)
                        total += aij * val
                mat.append(mat_row)
            mat[0][0] = GF(0) - total
            coeffs.append(mat)
        return coeffs, Lambda

if __name__ == "__main__":
    SCHED_MOD5 = [(0,1), (1,2), (2,3), (3,4), (4,0)]
    SCHED_MOD7 = [(0,1), (1,3), (2,5), (3,0), (4,2)]
    cancel_pair = (0, 1)
    all_results = {}
    
    configs = [(3, 5, SCHED_MOD5, "mod5"), (3, 7, SCHED_MOD7, "mod7"),
               (31, 5, SCHED_MOD5, "mod5"), (31, 7, SCHED_MOD7, "mod7")]
    
    # === FORGERY ===
    for p, e, sched, label in configs:
        GF, alpha, mu, frob_fn = setup_field(p, e)
        for diagonal in [True, False]:
            dlabel = "diag" if diagonal else "dense"
            key = f"forgery_p{p}_e{e}_{dlabel}"
            print(f"\nFORGERY: p={p} e={e} {dlabel} ({e}x{5*e})")
            try:
                coeffs = gen_forgery_coeffs(p, diagonal, seed=42)
                Q, L, c = build_forgery_system(p, e, sched, cancel_pair, coeffs, diagonal, mu, frob_fn)
                results = {}
                for d in range(2, 5):
                    n_r, n_c, rank, defic = build_macaulay_and_rank(Q, L, c, 5*e, e, p, d)
                    results[d] = (n_r, n_c, rank, defic)
                all_results[key] = results
            except Exception as ex:
                import traceback; traceback.print_exc()
                all_results[key] = f"ERROR: {ex}"
    
    # === KEY RECOVERY ===
    for p, e, sched, label in configs:
        GF, alpha, mu, frob_fn = setup_field(p, e)
        for diagonal in [True, False]:
            dlabel = "diag" if diagonal else "dense"
            key = f"keyrec_p{p}_e{e}_{dlabel}"
            print(f"\nKEY RECOVERY: p={p} e={e} {dlabel} ({5*e}x{4*e})")
            try:
                coeffs_fq, Lambda = gen_keyrecovery_coeffs(GF, alpha, p, e, sched, diagonal, seed=42)
                Q, L, c = build_keyrecovery_system(p, e, sched, coeffs_fq, diagonal, mu, frob_fn)
                
                # Verify planted solution
                lambda_vec = np.zeros(4*e, dtype=np.int64)
                for i in range(1, 5):
                    vec = np.array(Lambda[i].vector(), dtype=np.int64)[::-1]
                    lambda_vec[(i-1)*e:i*e] = vec
                # Check: Q(lambda) + L(lambda) + c should be 0
                check = c.copy()
                check = (check + L @ lambda_vec) % p
                for eq in range(5*e):
                    check[eq] = (check[eq] + lambda_vec @ Q[eq] @ lambda_vec) % p
                print(f"  Planted check: max={np.max(check)}")
                
                results = {}
                for d in range(2, 5):
                    n_r, n_c, rank, defic = build_macaulay_and_rank(Q, L, c, 4*e, 5*e, p, d, col_limit=8000)
                    results[d] = (n_r, n_c, rank, defic)
                all_results[key] = results
            except Exception as ex:
                import traceback; traceback.print_exc()
                all_results[key] = f"ERROR: {ex}"
    
    # === SUMMARY ===
    print(f"\n\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    
    for prefix, desc in [("forgery", "FORGERY (e eqs x 5e vars)"), ("keyrec", "KEY RECOVERY (5e eqs x 4e vars)")]:
        print(f"\n--- {desc} ---")
        print(f"{'Config':<35} {'d=2':>15} {'d=3':>15} {'d=4':>15}")
        for p, e in [(3,5), (3,7), (31,5), (31,7)]:
            for dlabel in ["diag", "dense"]:
                key = f"{prefix}_p{p}_e{e}_{dlabel}"
                if key not in all_results: continue
                results = all_results[key]
                if isinstance(results, str):
                    print(f"  p={p} e={e} {dlabel:<6} {results}")
                    continue
                row = f"  p={p} e={e} {dlabel:<6}"
                for d in [2, 3, 4]:
                    if d in results:
                        n_r, n_c, rank, defic = results[d]
                        if rank >= 0:
                            row += f" {rank}/{min(n_r,n_c)}(d={defic})".rjust(15)
                        else:
                            row += f" {'SKIP':>15}"
                    else:
                        row += f" {'N/A':>15}"
                print(row)
        
        print(f"\n  Diagonal vs Dense:")
        for p, e in [(3,5), (3,7), (31,5), (31,7)]:
            dk = f"{prefix}_p{p}_e{e}_diag"
            nk = f"{prefix}_p{p}_e{e}_dense"
            if dk in all_results and nk in all_results and not isinstance(all_results[dk], str) and not isinstance(all_results[nk], str):
                for d in [2, 3, 4]:
                    if d in all_results[dk] and d in all_results[nk]:
                        _, _, rd, dd = all_results[dk][d]
                        _, _, rn, dn = all_results[nk][d]
                        if rd >= 0 and rn >= 0:
                            m = "MATCH" if dd == dn else "DIFFER"
                            print(f"    p={p} e={e} d={d}: diag def={dd}, dense def={dn} -> {m}")
