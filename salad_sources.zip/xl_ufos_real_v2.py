"""
Optimized constraint matrix rank computation for UFOs Level I: p=31, e=61.

Key optimizations:
1. Build Q using Frobenius vectors (reuses precomputed alpha^(p^a) powers)
2. Build constraint matrix C as a dense numpy array (39711 x 3721)
3. Perform Gaussian elimination using fully vectorized numpy operations
4. Each elimination step uses broadcasting: M[mask] -= factors * pivot_row
"""

import numpy as np
import galois
from itertools import combinations, combinations_with_replacement
import random, time
from math import comb

def compute_frobenius_vectors(GF, p, e, a):
    frob_exp = pow(p, a, p**e - 1)
    prim = GF.primitive_element
    alpha_frob = prim ** frob_exp
    vectors = []
    current = GF(1)
    for j in range(e):
        vectors.append(current)
        current = current * alpha_frob
    return vectors

def build_Q(GF, p, e, terms):
    """Build Q[i,j,k] tensor using Frobenius vectors."""
    frob_a_vecs = []
    frob_b_vecs = []
    for a, b, c_int in terms:
        fa = compute_frobenius_vectors(GF, p, e, a)
        fb = compute_frobenius_vectors(GF, p, e, b)
        frob_a_vecs.append(fa)
        frob_b_vecs.append(fb)
    
    n_pairs = e * (e + 1) // 2
    U = np.zeros((e, n_pairs), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            field_elem = GF(0)
            for r, (a, b, c_int) in enumerate(terms):
                product = frob_a_vecs[r][k] * frob_b_vecs[r][l]
                field_elem = field_elem + GF(c_int) * product
            vec = np.array(field_elem.vector(), dtype=np.int64)
            U[:, idx] = vec[::-1]
            idx += 1
    
    Q = np.zeros((e, e, e), dtype=np.int64)
    idx = 0
    for k in range(e):
        for l in range(k, e):
            Q[:, k, l] = U[:, idx]
            Q[:, l, k] = U[:, idx]
            idx += 1
    return Q

def build_constraint_matrix(Q, e, p):
    """Build constraint matrix C (n_cubic_monomials x e^2)."""
    inv2 = pow(2, p-2, p)
    n_cols = e * e
    
    cubic_mons = list(combinations_with_replacement(range(e), 3))
    n_rows = len(cubic_mons)
    
    C = np.zeros((n_rows, n_cols), dtype=np.int32)
    
    for row_idx, (a, b, c) in enumerate(cubic_mons):
        if a == b == c:
            # x_a^3: C[row, i*e+a] = Q[i,a,a]
            for i in range(e):
                C[row_idx, i*e + a] = int(Q[i, a, a])
        elif a == b:
            # x_a^2 * x_c: C[row, i*e+a] = 2*Q[i,a,c], C[row, i*e+c] = Q[i,a,a]
            for i in range(e):
                C[row_idx, i*e + a] = (2 * int(Q[i, a, c])) % p
                C[row_idx, i*e + c] = int(Q[i, a, a])
        elif b == c:
            # x_a * x_b^2: C[row, i*e+b] = 2*Q[i,a,b], C[row, i*e+a] = Q[i,b,b]
            for i in range(e):
                C[row_idx, i*e + b] = (2 * int(Q[i, a, b])) % p
                C[row_idx, i*e + a] = int(Q[i, b, b])
        else:
            # a < b < c: C[row, i*e+a] = 2*Q[i,b,c], etc.
            for i in range(e):
                C[row_idx, i*e + a] = (2 * int(Q[i, b, c])) % p
                C[row_idx, i*e + b] = (2 * int(Q[i, a, c])) % p
                C[row_idx, i*e + c] = (2 * int(Q[i, a, b])) % p
    
    return C

def gauss_elim_rank(M, p):
    """Compute rank of M mod p using vectorized Gaussian elimination."""
    M = M.copy().astype(np.int64) % p
    n_rows, n_cols = M.shape
    rank = 0
    
    for col in range(min(n_rows, n_cols)):
        if rank >= n_rows:
            break
        # Find pivot
        col_slice = M[rank:, col] % p
        nonzero = np.where(col_slice != 0)[0]
        if len(nonzero) == 0:
            continue
        pivot_idx = nonzero[0] + rank
        # Swap rows
        if pivot_idx != rank:
            M[[rank, pivot_idx]] = M[[pivot_idx, rank]]
        # Normalize pivot row
        inv_val = pow(int(M[rank, col]), p-2, p)
        M[rank] = (M[rank] * inv_val) % p
        # Eliminate all other rows (vectorized)
        factors = M[:, col].copy()
        factors[rank] = 0
        mask = factors != 0
        if np.any(mask):
            M[mask] = (M[mask] - factors[mask, np.newaxis] * M[rank]) % p
        rank += 1
    
    return rank

# === Validation: e=7, p=31, consecutive ===
print("="*80)
print("VALIDATION: e=7, p=31, consecutive schedule")
print("="*80)

p, e = 31, 7
GF = galois.GF(p**e)
schedule = [(0,1),(1,2),(2,3),(3,4),(4,5)]
cancel = (0, 1)
residual = [schedule[k] for k in range(5) if k not in cancel]

rng = random.Random(42)
x0_int = rng.randint(1, p**e - 1)
x0 = GF(x0_int)
rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
terms = []
for a, b in residual:
    c_int = int(GF(rng_c.randint(1, p**e - 1)))
    terms.append((a, b, c_int))

h_val = GF(0)
for a, b, c_int in terms:
    h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)

t0 = time.time()
Q = build_Q(GF, p, e, terms)
print(f"Q built in {time.time()-t0:.1f}s")

C = build_constraint_matrix(Q, e, p)
print(f"C shape: {C.shape}, nnz: {np.count_nonzero(C)}")

t1 = time.time()
rank = gauss_elim_rank(C, p)
print(f"Rank computation: {time.time()-t1:.1f}s")
print(f"C rank: {rank}/{e*e}")
print(f"Syzygy dim: {e*e - rank}")
print(f"D_lin@3: {'YES' if rank < e*e else 'no'}")

# === Real UFOs Level I: p=31, e=61 ===
print("\n" + "="*80)
print("REAL UFOs Level I: p=31, e=61")
print("="*80)

p, e = 31, 61
ufos_schedule = [(0,9),(7,54),(13,29),(15,37),(35,47)]
GF = galois.GF(p**e)

pairs = list(combinations(range(5), 2))
all_results = []

for cancel in pairs:
    residual = [ufos_schedule[k] for k in range(5) if k not in cancel]
    
    rng = random.Random(42)
    x0_int = rng.randint(1, p**e - 1)
    x0 = GF(x0_int)
    rng_c = random.Random(hash(cancel) % 2**32 + 42 * 7919)
    terms = []
    for a, b in residual:
        c_int = int(GF(rng_c.randint(1, p**e - 1)))
        terms.append((a, b, c_int))
    
    h_val = GF(0)
    for a, b, c_int in terms:
        h_val = h_val + GF(c_int) * x0 ** (p**a + p**b)
    
    t0 = time.time()
    Q = build_Q(GF, p, e, terms)
    t_q = time.time() - t0
    
    C = build_constraint_matrix(Q, e, p)
    t_c = time.time() - t0 - t_q
    
    n_rows_c, n_cols_c = C.shape
    print(f"\nCancel {cancel}: C is {n_rows_c} x {n_cols_c}, nnz={np.count_nonzero(C)}")
    print(f"  Q: {t_q:.1f}s, C build: {t_c:.1f}s")
    
    t1 = time.time()
    rank = gauss_elim_rank(C, p)
    t_rank = time.time() - t1
    
    syz_dim = n_cols_c - rank
    dlin = rank < n_cols_c
    
    print(f"  Rank: {t_rank:.1f}s, C rank={rank}/{n_cols_c}, syz={syz_dim}, D_lin@3={'YES' if dlin else 'no'}")
    all_results.append((cancel, rank, syz_dim, dlin))
    
    total = time.time() - t0
    if total > 100:
        print(f"  WARNING: total time {total:.1f}s")

print(f"\n{'='*80}")
print("SUMMARY: UFOs Level I (p=31, e=61)")
print(f"{'='*80}")
dlin_count = sum(1 for r in all_results if r[3])
for cancel, rank, syz, dlin in all_results:
    print(f"  Cancel {cancel}: rank={rank}/{e*e}, syz={syz}, D_lin@3={'YES' if dlin else 'no'}")
print(f"\nD_lin@3 found for {dlin_count}/10 triplets")
