#!/usr/bin/env python3
"""
deltas_points_2.py — Stage 2: Shift optimization to maximize the linear span L.

Given the best quintuplets of deltas from Stage 1 (compute_all_w3.py),
this script optimizes the Frobenius shifts (anchor positions) to maximize
the worst-case linear span L over all 10 cancellation pairs.

The linear span L is the length of the shortest cyclic interval containing
all 6 residual Frobenius endpoints {a_i, b_i, a_j, b_j, a_t, b_t} on Z/eZ,
minimized over all C(5,3) = 10 choices of 3 residual blocks.  A larger L
means the univariate polynomial after two-block cancellation has higher
degree, making root-finding more expensive.

The optimization is embarrassingly parallel: each quintuplet is processed
independently.  For each quintuplet, we enumerate all e^2 shift pairs
(i1, i2) and precompute the univariate span for each of the 10 residual
triplets, then search for the combination of 5 shifts that maximizes the
minimum span across all triplets.

Output: JSON file of optimal schedules (5 pairs of endpoints) with the
achieved linear span score.

Usage:
    python deltas_points_2.py

Input:  deltas_wt_{e}.json   (from compute_all_w3.py)
Output: quintuplets_L_{e}.json
"""

import itertools
import json
import os
import sys
import time
from multiprocessing import Pool, cpu_count

# =====================================================================
# Configuration
# =====================================================================

UFO_E = 127          # Extension degree
JSON_INPUT_FILE = f"deltas_wt_{UFO_E}.json"
JSON_OUTPUT_FILE = f"quintuplets_L_{UFO_E}.json"


# =====================================================================
# Linear span computation
# =====================================================================

def compute_univariate_span(residual_indices, e):
    """
    Compute the linear span L for a set of residual Frobenius endpoints.

    Given the 6 endpoints {a_i, b_i, a_j, b_j, a_t, b_t} of a 3-block
    residual equation, the linear span is the length of the shortest
    cyclic interval on Z/eZ that contains all 6 points.  Equivalently,
    it is e minus the largest gap between consecutive sorted endpoints.

    Parameters
    ----------
    residual_indices : iterable of (int, int)
        The (a_k, b_k) pairs of the 3 residual blocks.
    e : int
        Extension degree.

    Returns
    -------
    int
        The linear span L.
    """
    sorted_idx = sorted(i % e for pair in residual_indices for i in pair)
    n = len(sorted_idx)
    max_gap = 0
    for i in range(n):
        gap = (sorted_idx[(i + 1) % n] - sorted_idx[i]) % e
        if gap > max_gap:
            max_gap = gap
    return e - max_gap


# =====================================================================
# Schedule normalization (Bariant canonical form)
# =====================================================================

def normalize_schedule(schedule, e):
    """
    Normalize a 5-block schedule to Bariant canonical form.

    Each block (a, b) is reduced so that the delta (b - a) mod e is in
    [0, e/2].  Blocks are sorted by delta, and the origin is shifted to
    the start of the block with smallest delta.

    Parameters
    ----------
    schedule : list[(int, int)]
        List of 5 (a_k, b_k) pairs.
    e : int
        Extension degree.

    Returns
    -------
    list[(int, int)]
        Normalized schedule.
    """
    normalized = []
    for a, b in schedule:
        a_mod, b_mod = a % e, b % e
        delta = (b_mod - a_mod) % e
        if delta > (e - 1) // 2:
            normalized.append((b_mod, a_mod, e - delta))
        else:
            normalized.append((a_mod, b_mod, delta))

    normalized.sort(key=lambda x: x[2])  # Sort by delta

    shift = normalized[0][0]
    return [(a - shift) % e, (b - shift) % e for a, b, _ in normalized]


# =====================================================================
# Parallel worker: optimize shifts for one quintuplet
# =====================================================================

def worker_optimize_deltas(args):
    """
    Optimize Frobenius shifts for a single quintuplet of deltas.

    Given 5 delta values, enumerate all e^2 pairs of shifts (i1, i2) and
    precompute the univariate span for each of the 10 residual triplets.
    Then search for the combination of 5 shifts (s0=0, s1=i1, s2=i2, s3, s4)
    that maximizes the minimum span across all triplets.

    The search is pruned: for each target score (from high to low), check
    whether there exist shifts i3, i4 such that all 10 triplet spans
    exceed the target.  The first target that yields a solution is optimal.

    Parameters
    ----------
    args : tuple
        (idx, deltas, e) where deltas is a list of 5 delta values.

    Returns
    -------
    dict
        Dictionary with original deltas, optimal shifts, and best score.
    """
    idx, deltas, e = args
    d0, d1, d2, d3, d4 = deltas

    # Precompute coordinates for each block at each shift
    coords = [
        [(i, (i + d) % e) for i in range(e)]
        for d in [d0, d1, d2, d3, d4]
    ]

    # Precompute all 10 triplet spans for each (i1, i2) shift pair
    # Key: (triplet_id, i1, i2) -> span value
    scores = {}
    for i1, i2 in itertools.product(range(e), repeat=2):
        p0 = coords[0][0]
        p1 = coords[1][i1]
        p2 = coords[2][i2]
        p3 = coords[3][i2]
        p4 = coords[4][i2]

        scores[(0, 1, 2, i1, i2)] = compute_univariate_span((p0, p1, p2), e)
        scores[(0, 1, 3, i1, i2)] = compute_univariate_span((p0, p1, p3), e)
        scores[(0, 1, 4, i1, i2)] = compute_univariate_span((p0, p1, p4), e)

        p2_alt = coords[2][i1]
        p3_alt = coords[3][i2]
        p4_alt = coords[4][i2]

        scores[(0, 2, 3, i1, i2)] = compute_univariate_span((p0, p2_alt, p3_alt), e)
        scores[(0, 2, 4, i1, i2)] = compute_univariate_span((p0, p2_alt, p4_alt), e)

        p3_alt2 = coords[3][i1]
        p4_alt2 = coords[4][i2]
        scores[(0, 3, 4, i1, i2)] = compute_univariate_span((p0, p3_alt2, p4_alt2), e)

        p1_base = coords[1][0]
        scores[(1, 2, 3, i1, i2)] = compute_univariate_span((p1_base, p2_alt, p3_alt), e)
        scores[(1, 2, 4, i1, i2)] = compute_univariate_span((p1_base, p2_alt, p4_alt), e)

        p3_alt3 = coords[3][i1]
        scores[(1, 3, 4, i1, i2)] = compute_univariate_span((p1_base, p3_alt3, p4_alt2), e)

        p2_base = coords[2][0]
        scores[(2, 3, 4, i1, i2)] = compute_univariate_span((p2_base, p3_alt2, p4_alt2), e)

    max_score = max(scores.values()) if scores else 0
    print(f"[Worker {idx + 1}] Precomputation done. Max span = {max_score}")

    # Search for the best shift combination (s0=0, s1=i1, s2=i2, s3, s4)
    solutions = set()
    best_score = -1

    for target in reversed(range(1, max_score + 1)):
        if solutions:
            best_score = target + 1
            break

        for i1, i2 in itertools.product(range(e), repeat=2):
            if scores[(0, 1, 2, i1, i2)] < target:
                continue

            for i3 in range(e):
                if min(
                    scores[(0, 1, 3, i1, i3)],
                    scores[(0, 2, 3, i2, i3)],
                    scores[(1, 2, 3, (i2 - i1) % e, (i3 - i1) % e)],
                ) < target:
                    continue

                for i4 in range(e):
                    if min(
                        scores[(0, 3, 4, i3, i4)],
                        scores[(1, 3, 4, (i3 - i1) % e, (i4 - i1) % e)],
                        scores[(2, 3, 4, (i3 - i2) % e, (i4 - i2) % e)],
                        scores[(0, 2, 4, i2, i4)],
                        scores[(1, 2, 4, (i2 - i1) % e, (i4 - i1) % e)],
                        scores[(0, 1, 4, i1, i4)],
                    ) < target:
                        continue

                    solutions.add((0, i1, i2, i3, i4))

    print(f"[Worker {idx + 1}] Best score = {best_score}, {len(solutions)} solutions")

    return {
        "deltas_originaux": deltas,
        "shifts_optimaux": list(solutions),
        "meilleur_score": best_score,
    }


# =====================================================================
# Main controller
# =====================================================================

if __name__ == "__main__":
    # 1. Load quintuplets from Stage 1
    if not os.path.exists(JSON_INPUT_FILE):
        print(f"[ERROR] Input file {JSON_INPUT_FILE} not found.")
        sys.exit(1)

    with open(JSON_INPUT_FILE, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    deltas_list = []
    for item in raw_data:
        d = item.get("quintuplet", item)
        if d and len(d) == 5:
            deltas_list.append(d)

    print(f"[INFO] Loaded {len(deltas_list)} quintuplet(s).")

    # 2. Parallel optimization
    num_cores = cpu_count()
    print(f"[START] Running on {num_cores} cores...")

    tasks = [(i, deltas, UFO_E) for i, deltas in enumerate(deltas_list)]
    start_time = time.time()

    with Pool(processes=num_cores) as pool:
        results = pool.map(worker_optimize_deltas, tasks)

    # 3. Collect best schedules
    max_score = max(r["meilleur_score"] for r in results)
    print(f"\n[INFO] Best linear span L = {max_score}")

    schedules = set()
    for r in results:
        if r["meilleur_score"] != max_score:
            continue
        deltas = r["deltas_originaux"]
        for shifts in r["shifts_optimaux"]:
            schedule = tuple(
                (shifts[k], (shifts[k] + deltas[k]) % UFO_E)
                for k in range(5)
            )
            schedules.add(schedule)

    # 4. Save
    schedules_json = [[list(pair) for pair in s] for s in schedules]
    with open(JSON_OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(schedules_json, f, indent=4)

    print(f"[INFO] {len(schedules_json)} schedule(s) saved to {JSON_OUTPUT_FILE}")
    print(f"[SUCCESS] Completed in {time.time() - start_time:.1f}s")
